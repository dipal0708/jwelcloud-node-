﻿const request = require('request');
var rp = require('request-promise');
var Redshift = require('node-redshift');
var cassandra = require('cassandra-driver');
var contactPoints = ['127.0.0.1'];
var client = new cassandra.Client({ contactPoints: contactPoints, localDataCenter: 'datacenter1' });
var clientConfiguration = {
    user: "jewelcloudrs",
    database: "jewelcloud",
    password: "7pUHm2Qa9YsnFUV",
    port: 5439,
    host: "jewelcloud-rs.cvjykrynhxhb.us-east-1.redshift.amazonaws.com",///"jdbc:redshift://jewelcloud-rs.cvjykrynhxhb.us-east-1.redshift.amazonaws.com:5439/jewelcloud?ssl=true&sslfactory=com.amazon.redshift.ssl.NonValidatingFactory",
};
var redshift = new Redshift(clientConfiguration);



async function queryCassandra(query) {  
    return await client.execute(query, [], function (err, result) {
        if (err) {
            console.log('file upload: add err:', err);
            return err;
        } else {
            console.log('query execute success:');
            return result;
        }
    });
}
async function readFiles(filePath) {
    ///const files = await getFilePaths();
    await Promise.all(filePath.map(async (file) => {
        const contents = await fs.readFile(file, 'utf8');
        console.log(contents)
        return contents;
    }));
}

async function pentahoApiCall(options) {
    await rp(options)
        .then(function (response) {
            return response;
        })
        .catch(function (err) {
            // rejected
        });
}

async function redshiftQuery(query) {
    await redshift.connect(function (err) {
        redshift.query(query, { raw: true }, function (err, data) {
            if (err) { console.log(err); }
            else {
                return data;
            }
        });
    });
}

module.exports = {
    queryCassandra,
    readFiles,
    pentahoApiCall,
    redshiftQuery
}