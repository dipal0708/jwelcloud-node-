﻿const nodemailer = require("nodemailer");
var cassandra = require('cassandra-driver');

var contactPoints = ['127.0.0.1'];
var client = new cassandra.Client({ contactPoints: contactPoints, localDataCenter: 'datacenter1' });
client.connect(function (err, result) {
    console.log('Email template : cassandra connected');
});

var transporter = nodemailer.createTransport({
    service: 'gmail',
    auth: {
        user: 'gemfindtest@gmail.com',
        pass: 'Test@123'
    }
});

console.log('created');
exports.sendMail = function (req, res) {
    var mailOptions = {
        from: 'gemfindtest@gmail.com', // sender address
        to: req.email, // list of receivers
        subject: req.subject, // Subject line
        html: req.body, // email body part
        attachments:req.attachments
    };
    transporter.sendMail(mailOptions, function (error, info) {
        if (error) {
            console.log("1");
            console.log(error);
        } else {
            console.log('Email sent: ' + info.response);
        }
    });
};
////-----------------------------------------------------------------------------------------Email template Insert
exports.addEmailTemplate = function (req, res) {
    console.log(req.body);
    var input = req.body;
    client.execute("INSERT INTO key_gemfind.email_template (pk_id, email_body,email_subject,email_type,en_english,es_spenish,created_by,created_date,updated_by,updated_date,is_deleted,deleted_by) VALUES (now(), '" + input.email_body + "', '" + input.email_subject + "','" + input.email_type + "','" + input.en_english + "', '" + input.es_spenish + "'," + input.created_by + ",'" + input.created_date + "', " + input.updated_by + ",'" + input.updated_date + "',false,'" + input.deleted_by + "')", [], function (err, result) {
        if (err) {
            console.log('users: add err:', err);
            res.status(404).send({ msg: err });
        } else {
            console.log('users: add succ:');
            //res.status(404).send({ msg: 'users: add succ:' });
            res.send({ status: 200, data: result.rows })
            //res.redirect('/users');
        }
    });
};

////-----------------------------------------------------------------------------------------Email template get

exports.emailTemplateedit = function (req, res) {
    console.log(req.params);
    console.log(req.originalUrl);
    var str = req.originalUrl;
    var str2 = str.split("?");
    var str3 = str2[1];
    console.log(str3);
    client.execute("SELECT * from key_gemfind.email_template WHERE pk_id=" + str3, [], function (err, result) {
        if (err) {
            console.log('users: add err:', err);
            res.status(404).send({ msg: err });
        } else {
            console.log('users: add succ:');
            //res.status(404).send({ msg: 'users: add succ:' });
            res.send({ status: 200, data: result.rows });
            //res.redirect('/users');
        }
    });
};
////-----------------------------------------------------------------------------------------Email template Update
exports.emailTemplateupdate = function (req, res) {
    console.log(req.body);
    var input = (req.body);
    var id = req.body.pk_id;
    client.execute("UPDATE key_gemfind.email_template set email_body='" + input.email_body + "', email_subject='" + input.email_subject + "',email_type='" + input.email_type + "',en_english='" + input.en_english + "',es_spenish='" + input.es_spenish + "',created_by=" + input.created_by + ",created_date='" + input.created_date + "',updated_by=" + input.updated_by + ",updated_date='" + input.updated_date + "',is_deleted= false ,deleted_by='" + input.deleted_by + "' WHERE pk_id = " + id, [], function (err, result) {
        if (err) {
            console.log('users: add err:', err);
            res.status(404).send({ msg: err });
        } else {
            console.log('users: add succ:');
            //res.status(404).send({ msg: 'users: add succ:' });
            res.send({ status: 200, data: result.rows });
            //res.redirect('/users');
        }
    });
};
////-----------------------------------------------------------------------------------------Email template Delete
exports.emailTemplatedelete = function (req, res) {
    console.log(req.params);
    console.log(req.originalUrl);
    var str = req.originalUrl;
    var str2 = str.split("?");
    console.log(req.str2);
    var str3 = str2[1];

    console.log(str3);
    client.execute("update key_gemfind.email_template set is_deleted = true  WHERE pk_id=" + str3, [], function (err, result) {
        if (err) {
            console.log('users: add err:', err);
            res.status(404).send({ msg: err });
        } else {
            console.log('users: add succ:');
            //res.status(404).send({ msg: 'users: add succ:' });
            res.send({ status: 200, data: result.rows });
            //res.redirect('/users');
        }
    });
};
//////-----------------------------------------------------------------------------------------Email template Getall
exports.emailTemplategetall = function (req, res) {
    console.log(req.params);
    console.log(req.originalUrl);
    var str = req.originalUrl;

    var str2 = str.split("?");
    console.log(str2);
    var id = str2[1];
    console.log(id);

    client.execute("select * FROM key_gemfind.user_registration WHERE pk_id =" + id, [], function (err, result, fields) {
        if (err) {
            console.log('users: add err:', err);
            res.status(404).send({ msg: err });
        } else {
            var role = result.rows[0].roles;
            if (role === '2') {
                client.execute("select * from key_gemfind.email_template WHERE is_deleted = false ALLOW FILTERING", [], function (err, result) {
                    if (err) {
                        console.log('users: add err:', err);
                        res.status(404).send({ msg: err });
                    } else {
                        console.log("Data by Admin");
                        console.log('Admin:Get all');
                        res.send({ status: 200, data: result.rows });
                    }
                });
            }
            else {
                client.execute("select * from key_gemfind.email_template WHERE is_deleted = false AND created_by = " + id + " ALLOW FILTERING", [], function (err, result) {
                    if (err) {
                        console.log('users: add err:', err);
                        res.status(404).send({ msg: err });
                    } else {
                        console.log("Data by pkid");
                        console.log('users: Get all');
                        res.send({ status: 200, data: result.rows });
                    }
                });
            }

        }
    });


    //client.execute("select * from key_gemfind.email_template WHERE is_deleted = false ALLOW FILTERING", [], function (err, result) {
    //    if (err) {
    //        console.log('users: add err:', err);
    //        res.status(404).send({ msg: err });
    //    } else {
    //        console.log('users: add succ:');
    //        res.send({ status: 200, data: result.rows });
    //    }
    //});
};
