﻿var cassandra = require('cassandra-driver');
var contactPoints = ['127.0.0.1'];
var clientCas = new cassandra.Client({ contactPoints: contactPoints, localDataCenter: 'datacenter1' });
clientCas.connect(function (err, result) {
    console.log('user detail: cassandra connected');
});

let redis = require('redis'),
    /* Values are hard-coded for this example, it's usually best to bring these in via file or environment variable for production */
    client = redis.createClient({
        port: 6379,               // replace with your port
        host: '3.91.3.6',        // replace with your hostanme or IP address
        //password: 'your password',    // replace with your password
        // optional, if using SSL
        // use `fs.readFile[Sync]` or another method to bring these values in
        //tls: {
        //    key: stringValueOfKeyFile,
        //    cert: stringValueOfCertFile,
        //    ca: [stringValueOfCaCertFile]
        //}
    });

client.on('connect', function () {
    console.log('Redis client connected');
});




client.get('jewel', function (err, value) {
    //console.log('Here i am.', value);
    if (err) {
        throw err;
    } else {
        ///console.log(value);
        let userList = JSON.parse(value);
        if (userList) {
            console.log('Get value from redis');
            try {
                clientCas.execute('SELECT * FROM key_gemfind.user_Registration', [], function (err, result) {
                    if (err) {
                        console.log('users: list err:', err);
                        res.status(404).send({ msg: err });
                    } else {
                        //console.log('users: list succ:', result.rows);                        
                        //res.render('users', { page_title: "users - Node.js", data: result.rows })
                        ///res.send({ status: 200, data: result.rows });
                        client.set('jewel', JSON.stringify(result.rows), function (err) {
                            if (err) {
                                throw err; /* in production, handle errors more gracefully */
                            } else {
                                //console.log('users: list succ:', result.rows); 
                            }
                        });
                    }
                });
            } catch (e) {
                console.log(e);
            }
           
        }
    }
});