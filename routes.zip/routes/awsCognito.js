﻿const AmazonCognitoIdentity = require('amazon-cognito-identity-js');
const CognitoUserPool = AmazonCognitoIdentity.CognitoUserPool;
const AWS = require('aws-sdk');
const request = require('request');
const jwkToPem = require('jwk-to-pem');
const jwt = require('jsonwebtoken');
var filessystem = require('fs');
global.fetch = require('node-fetch');
var cassandra = require('cassandra-driver');

var contactPoints = ['127.0.0.1'];
var client = new cassandra.Client({ contactPoints: contactPoints, localDataCenter: 'datacenter1' });
client.connect(function(err, result){
	console.log('aws js: cassandra connected');
});

const poolData = {
    UserPoolId: "us-east-1_UZ3sIxwTX", // Your user pool id here    
    ClientId: "6or956c7uloo3t8nl89u9ac2rt" // Your client id here
};
const pool_region = 'us-east-1';

const userPool = new AmazonCognitoIdentity.CognitoUserPool(poolData);


//// Code for login to aws cognito ///////////
exports.Login = function (req, res) {
///function Login() {
    var input = req.body;
    var authenticationDetails = new AmazonCognitoIdentity.AuthenticationDetails({
        Username: input.email,
        Password: input.password,
    });

    var userData = {
        Username: input.email,
        Pool: userPool
    };
    var cognitoUser = new AmazonCognitoIdentity.CognitoUser(userData);
    cognitoUser.authenticateUser(authenticationDetails, {
        onSuccess: function (result) {
            client.execute("SELECT * from key_gemfind.user_Registration WHERE email='" + input.email + "'  ALLOW FILTERING", [], function (err, result) {
                if (err) {
                    console.log('users: add err:', err);
                    res.send({ status: 400, data: err });
                } else {
                    console.log('users: add succ:');
                    //res.status(404).send({ msg: 'users: add succ:' });
                    res.send({ status: 200, data: result.rows });
                    //res.redirect('/users');
                }
            });
            ///res.send({ status: 200, data: result });
            //console.log('access token + ' + result.getAccessToken().getJwtToken());
            //console.log('id token + ' + result.getIdToken().getJwtToken());
            //console.log('refresh token + ' + result.getRefreshToken().getToken());
        },
        onFailure: function (err) {
            res.send({ status: 400, data: err });
            console.log(err);
        },
    });
}

///////// End //////////////////////////

/// Sign up into aws cognito ////////////
//function RegisterUser() {
exports.RegisterUser = function (req, res) {
	console.log('aws: register');
    var attributeList = [];
    var input = req.body;
    attributeList.push(new AmazonCognitoIdentity.CognitoUserAttribute({ Name: "email", Value: input.email }));
    userPool.signUp(input.email, input.password, attributeList, null, function (err, result) {
		console.log('aws: register',err);
        if (err) {
            console.log(err);
            res.send({ status: 400, data: err })
        }
        cognitoUser = result;
        console.log('users: add err:', result);
        res.send({ status: 200, data: cognitoUser })
    });
    
}

/// ---------------------- Function to verify code and confirm registration ----------------------///
exports.ConfirmRegistrationCode = function (req, res) {
    const Uuid = require('cassandra-driver').types.Uuid;
    const id = Uuid.random();
    const id2 = Uuid.random();

    var input = req.body;
    console.log(input);
    var userData = {
        Username: input.email,
        Pool: userPool
    };
    var cognitoUser = new AmazonCognitoIdentity.CognitoUser(userData);
    cognitoUser.confirmRegistration(req.params.confirmationCode, true, function (err, result) {
        debugger
        if (err) {
            console.log('users: error on confirmation:', err);
            res.send({ status: 400, data: err })
        } else {
            // ----------------- Code to insert in cassandra database --------------------------///
            client.execute("INSERT INTO key_gemfind.user_Registration (pk_id, accesstoken, account_type, address,city,company_name,contact_no,country,created_date,currency,email,is_deleted,is_emailverify,is_enable,language,name,password,refreshtoken,roles,state,updated_date,user_name,zip_code,firstname,lastname) VALUES (" + id + ", '" + input.accesstoken + "', '" + input.account_type + "', '" + input.address + "','" + input.city + "', '" + input.company_name + "', '" + input.contact_no + "','" + input.country + "', '" + input.created_date + "', '" + input.currency + "','" + input.email + "', false, true,true, '" + input.language + "', '" + input.name + "','" + input.password + "', '" + input.refreshtoken + "', '" + input.roles + "','" + input.state + "', '" + input.updated_date + "','" + input.user_name + "','" + input.zip_code + "','" + input.firstname + "','" + input.lastname + "')", [], function (err, result) {
                debugger
                if (err) {
                    console.log('users: add err:', err);
                    res.send({ status: 400, data: err })
                } else {
                    {
                        var dealerId;
                        client.execute("SELECT MAX(dealerid) AS LargestDealerid from key_gemfind.company_detail", [], function (err, result) {
                            if (err) {
                                err;
                            } else {
                                result = result.rows[0].largestdealerid + 1;
                                if (result === 1 || result <1000) {
                                    dealerId = 1000;
                                } else {
                                    dealerId = result;
                                }
                                if (dealerId >= 1000) {
                                    console.log("inserted id", id);
                                    console.log(result);
                                    client.execute("INSERT INTO key_gemfind.company_detail (pk_id,account_type,address,city,company_name,contact_no,country,created_date,currency,email,is_deleted,is_enable,language,name,state,updated_date,zip_code,created_by,dealerid,invite) VALUES (" + id2 + ", '" + input.account_type + "', '" + input.address + "', '" + input.city + "', '" + input.company_name + "', '" + input.contact_no + "', '" + input.country + "','" + input.created_date + "','" + input.currency + "','" + input.email + "', false, false, '" + input.language + "', '" + input.name + "', '" + input.state + "','" + input.updated_date + "','" + input.zip_code + "'," + id + "," + dealerId + ",false) ", [], function (err, result) {
                                        console.log("1");
                                        if (err) {
                                            console.log('users: add err:', err);
                                            res.status(404).send({ msg: err });
                                        } else {
                                            var dir = './uploads/' + dealerId;

                                            if (!filessystem.existsSync(dir)) {
                                                filessystem.mkdirSync(dir);

                                            } else {
                                                console.log("Directory already exist");
                                            }
                                            client.execute("INSERT INTO key_gemfind.companyuser_mapping (pk_id,company_id,user_id) VALUES (now(), " + id2 + ", " + id + ") ", [], function (err, result) {
                                                if (err) {
                                                    console.log('users: add err:', err);
                                                    res.status(404).send({ msg: err });
                                                } else {
                                                    console.log(result);
                                                    res.send({ status: 200, data: result.rows });
                                                }
                                            });
                                        }
                                    });

                                }
                            };
                        });
                    }
                }
            });
            ///res.status(404).send({ msg: err });
            console.log('user name is ' + cognitoUser.getUsername());
            ///////////// ------------------------ End -------------------------------------///
        }

        ///res.send({ status: 200, data: result.rows })
    });
}
//// ------------------------- End -------------------------------------------///

/// ---------------------- Function to resend verify code and confirm registration ----------------------///
exports.ResendCode = function (req, res) {
    var input = req.params.email;
    var userData = {
        Username: req.params.email,
        Pool: userPool
    };
    var cognitoUser = new AmazonCognitoIdentity.CognitoUser(userData);
    cognitoUser.resendConfirmationCode(function (err, result) {
        if (err) {
            console.log('users: error:', err);
            res.send({ status: 400, data: err })
        }
        ////////// End ///////////////
        res.send({ status: 200, data: result.rows })
    });
}
//// ------------------------- End -------------------------------------------///

/// ---------------------- Function to send verification code for forgot password ----------------------///
exports.ForgotPassword = function (req, res) {   
    
    var userData = {
        Username: req.params.email,
        Pool: userPool
    };
    var cognitoUser = new AmazonCognitoIdentity.CognitoUser(userData);
    cognitoUser.forgotPassword({
        onSuccess: function (result) {
            console.log('call result: ' + result);
            res.send({ status: 200, data: result })
        },
        onFailure: function (err) {
            res.send({ status: 400, data: err })
        }        
    }); 
}
//// ------------------------- End -------------------------------------------///

/// ---------------------- Function to confirm varification code and confirm password ----------------------///
exports.ConfirmPassword = function (req, res) {
    var email = req.body.email;
    var verificationCode = req.body.verificationCode;
    var newPassword = req.body.newPassword;
    console.log('call result: ' + email);
    var userData = {
        Username: email,
        Pool: userPool
    };
    console.log("data:" + userData.Username + ":pool :"+ userData.Pool);
    var cognitoUser = new AmazonCognitoIdentity.CognitoUser(userData);
    cognitoUser.confirmPassword(verificationCode, newPassword, {
        onSuccess: function (result) {
            console.log('call result: ' + result);
            res.send({ status: 200, data: result });
        },
        onFailure: function (err) {
            console.log('users: error:', err);
            res.send({ status: 400, data: err })
        }         
    });
    //cognitoUser.confirmPassword(verificationCode, newPassword,function (err, result) {
    //    if (err) {
    //        console.log('users: error:', err);
    //        res.status(404).send({ msg: err });
    //    }
    //    ////////// End ///////////////
    //    res.send({ status: 200, data: result.rows })
    //});
}
//// ------------------------- End -------------------------------------------///


/// ---------------------- Function to Change password ----------------------///
exports.ChangePassword = function (req, res) {
    var email = req.body.email;
    console.log('users: change password:', email);
    var pk_id = req.body.pk_id;
    var oldPassword = req.body.oldPassword;
    var newPassword = req.body.newPassword;
    console.log('users: change password:');
    var userData = {
        Username: email,
        Pool: userPool
    };
    var cognitoUser = new AmazonCognitoIdentity.CognitoUser(userData);
    cognitoUser.changePassword(oldPassword, newPassword, function (err, result) {
        if (err) {
            console.log('users: error:', err);
            res.send({ status: 400, data: err })
        } else {
            client.execute("UPDATE key_gemfind.user_registration set password='" + newPassword + "' WHERE pk_id in ( " + pk_id + ")", [], function (err, result) {
                if (err) {
                    console.log('customers: save_edit err:', err);
                    res.status(404).send({ msg: err });
                } else {
                    console.log('customers: save_edit succ:');
                    res.send({ status: 200, data: result.rows })
                    //res.redirect('/customers');
                }
            });
            console.log('call result: ' + result);
        }
        console.log('call result: ' + result);
    });
}
//// ------------------------- End -------------------------------------------///


//////// Function to validate token 
//function ValidateToken(token) {
exports.ValidateToken = function (req, res) {
    request({
        url: `https://cognito-idp.${pool_region}.amazonaws.com/${poolData.UserPoolId}/.well-known/jwks.json`,
        json: true
    }, function (error, response, body) {
        if (!error && response.statusCode === 200) {
            pems = {};
            var keys = body['keys'];
            for (var i = 0; i < keys.length; i++) {
                //Convert each key to PEM
                var key_id = keys[i].kid;
                var modulus = keys[i].n;
                var exponent = keys[i].e;
                var key_type = keys[i].kty;
                var jwk = { kty: key_type, n: modulus, e: exponent };
                var pem = jwkToPem(jwk);
                pems[key_id] = pem;
            }
            //validate the token
            var decodedJwt = jwt.decode(token, { complete: true });
            if (!decodedJwt) {
                console.log("Not a valid JWT token");
                return;
            }

            var kid = decodedJwt.header.kid;
            var pems = pems[kid];
            if (!pems) {
                console.log('Invalid token');
                return;
            }

            jwt.verify(token, pems, function (err, payload) {
                if (err) {
                    console.log("Invalid Token.");
                } else {
                    console.log("Valid Token.");
                    console.log(payload);
                }
            });
        } else {
            console.log("Error! Unable to download JWKs");
        }
    });
}

////////// End //////////////////

/// Refersh token /////////////////
//function renew() {
exports.renew = function (req, res) {
    const RefreshToken = new AmazonCognitoIdentity.CognitoRefreshToken({ RefreshToken: "your_refresh_token_from_a_previous_login" });

    const userPool = new AmazonCognitoIdentity.CognitoUserPool(poolData);

    const userData = {
        Username: "sample@gmail.com",
        Pool: userPool
    };

    const cognitoUser = new AmazonCognitoIdentity.CognitoUser(userData);

    cognitoUser.refreshSession(RefreshToken, (err, session) => {
        if (err) {
            console.log(err);
        } else {
            let retObj = {
                "access_token": session.accessToken.jwtToken,
                "id_token": session.idToken.jwtToken,
                "refresh_token": session.refreshToken.token,
            }
            console.log(retObj);
        }
    })
}

////////  End /////////////////

////  Delete aws  User //////////
////function DeleteUser() {
exports.DeleteUser = function (req, res) {
    var authenticationDetails = new AmazonCognitoIdentity.AuthenticationDetails({
        Username: username,
        Password: password,
    });

    var userData = {
        Username: username,
        Pool: userPool
    };
    var cognitoUser = new AmazonCognitoIdentity.CognitoUser(userData);

    cognitoUser.authenticateUser(authenticationDetails, {
        onSuccess: function (result) {
            cognitoUser.deleteUser((err, result) => {
                if (err) {
                    console.log(err);
                } else {
                    console.log("Successfully deleted the user.");
                    console.log(result);
                }
            });
        },
        onFailure: function (err) {
            console.log(err);
        },
    });
}

////// End ///////////

/// Change password of aws cognito user ///////



