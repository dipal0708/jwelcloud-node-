var cassandra = require('cassandra-driver');
const util = require('util');
const cron = require('node-cron');

//var ftpClient = require('ftp-client'), config = {
//    host: '10.1.1.111',
//    port: 21,
//    user: 'nayan',
//    password: 'Admin@1234'
//}, options = {
//    logging: 'basic'
//    }, clientftp = new ftpClient(config, options);
//clientftp.connect(function () {});

//var client = new cassandra.Client({contactPoints: [process.env.CASSANDRA_IP || 'cassandra']});
var contactPoints = ['127.0.0.1'];
var client = new cassandra.Client({ contactPoints: contactPoints, localDataCenter: 'datacenter1' });
client.connect(function(err, result){
	console.log('customers: cassandra connected');
});



var task = cron.schedule('00 00 00 * * *', () => {
    var Request = require("request");
    Request.get("http://openexchangerates.org/api/latest.json?app_id=92202dbcfbbb4e5492236b36991e8d4a", (error, response, result) => {
        if (error) {
            return console.dir(error);
        }
        var dataRates = [];
        var excRates = [];
        dataRates = JSON.parse(result);
        excRates = dataRates.rates;
        //console.log(excRates);
        client.execute("truncate table key_gemfind.exchangerates", [], function (err, result) {
            if (err) {
                console.log('customers: add err:', err);
                res.status(404).send({ msg: err });
            } else {                
                for (const [key, value] of Object.entries(excRates)) {                    
                    client.execute("insert into key_gemfind.exchangerates(pk_id, code, rate) values (now(), '" + key + "', '" + value + "')", [], function (err, result) {
                        if (err) {
                            console.log('customers: add err:', err);
                            res.status(404).send({ msg: err });
                        } else {             
                            console.log('customers: add succ:');
                        }
                    });
                }
            }
        });
        //res.send({ status: 200, data: result.rows });
    });    
});



//var taskProcessDiamondFile = cron.schedule('*/1 * * * *', () => {
//    client.execute("select * from key_gemfind.diamondFileUpload where status='pending' allow filtering", [], function (err, result) {
//        if (err) {
//            console.log('File upload: Diamond ', err);
//            res.status(404).send({ msg: err });
//        } else {
//           /// console.log('Process diamond file:', result.rows);
//            /// code to download file from ftp
//            for (var i = 0; i < result.rows.length; i++) {
//                console.log(result.rows[i].file_path);///'/root/inventoryFile/1000/' +
//                clientftp.download('/root/inventoryFile/1000', 'D:/upload', {
//                    overwrite: 'all'
//                }, function (result) {
//                    console.log(result);
//                });
//            }
            
//        }
//    }); 
//    console.log('Printing this line every minute in the terminal');
//});

exports.listExcRates = function (req, res) {
    //console.log('customers: list');
    client.execute('SELECT * FROM key_gemfind.exchangerates', [], function (err, result) {
        if (err) {
            console.log('customers: list err:', err);
            res.status(404).send({ msg: err });
        } else {
            //console.log('customers: list succ:', result.rows);                        
            //res.render('customers', { page_title: "Customers - Node.js", data: result.rows })
            res.send({ status: 200, data: result.rows });
        }
    });
};