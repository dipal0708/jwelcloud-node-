﻿var fs = require('fs'),
    xml2js = require('xml2js'),
    util = require('util');

var parser = new xml2js.Parser(),
    xmlBuilder = new xml2js.Builder();
var configFile = 'D:/Nayan/API_Jewelcloud/uploads/File_Format.ktr';

let cutField = ['CUT', 'SHAPE', 'CUT(SHAPE)', 'CUTSHAPE', 'SHP', 'CUTShape'];
let colorField = ['COLOR', 'COLR'];
let clarityField = ['CLARITY', 'CLARITYID', 'CLAR'];
let cutgradeField = ['CUT GRADE', 'CUTGRADE'];
let costpercaratField = ['COSTPERCARAT', 'PRICE PER CARAT', 'PRICEPERCARAT', 'COST PER CARAT', 'PRICE', 'ASKINGPRICE', 'PRICE CT', 'PRICE CARAT', 'COST CARAT', 'PRICECARAT', 'COSTCARAT', 'PRICE/CT', '$CT', '$/CT', '$/CT', 'PRICE/CARAT', 'COST/' ];
let depthField = ['DEPTH', 'DEPTH %', 'DEPTH%', 'DEPT', 'DEPTHPERCENT', 'DEPTH %' , 'DPTH'];
let tableField = ['TABLE %', 'TABLE %', 'TABLE', 'TBLE', 'TABLEPERCENT'];
let sizeField = ['WEIGHT', 'SIZE', 'CARAT WEIGHT', 'CARATWEIGHT', 'CARAT', 'CT'];
let stockNumberField = ['STOCK #', 'STOCK#', 'STOCKNUMBER', 'STOCK NUMBER', 'VENDOR STOCK #', 'VENDORSTOCK', 'INVENTORY STOCK #', 'INVENTORYSTOCK', 'STOCK NO', 'VENDOR STOCK NO', 'INVENTORY STOCK NO', 'STOCKNO', 'SKU #', 'STOCK', 'VENDORSTOCKNO', 'VENDORSTOCKNUMBER', 'VENDOR STOCK NUMBER', 'INVENTORYSTOCKNO', 'INVENTORY STOCK NUMBER', 'INVENTORYSTOCKNUMBER', 'INVENTORYNO', 'RAPNETLOT', 'STOCL_NO'];
let polishField = ['POLISH', 'POL'];
let symmetryField = ['SYMMETRY', 'SYM'];
let fluorescenceField = ['FLUORESCENCE', 'FL', 'FLUORESCENCEINTENSITY', 'FLUORESCENCE INTENSITY', 'FLUOR INTENSITY', 'FLUORINTENSITY', 'FLR', 'FLUOR', 'FLO'];
let fluorescencecolorField = ['FLUORESCENCECOLOR', 'FLUORESCENCE COLOR', 'FLUOR COLOR', 'FLUORCOLOR', 'FLRCOLOR'];
let certificateField = ['LAB', 'CERT', 'CERTIFICATE', 'CERTIFICATE TYPE', 'CERTIFICATETYPE', 'CERT TYPE', 'CERTTYPE', 'ONL. CERT'];
let certificatenoField = ['CERTIFICATE NO', 'CER NUMBER', 'CERTIFICATE #', 'CERTIFICATE#', 'CERT #', 'CERT#', 'CERTIFICATENO', 'CERTIFICATE ID', 'CERTNO', 'CERT.NO', 'CERTIFICATE NUMBER'];
let measurementsField = ['DIMENSIONS', 'MEASUREMENTS', 'MEASUREMENT', 'MEAS'];
let measlengthField = ['MEASLENGTH', 'M1', 'MAX', 'LENGTH'];
let measheightField = ['MEASHEIGHT', 'M3', 'HGT'];
let measwidthField = ['MEASWIDTH', 'M2', 'MIN', 'WIDTH'];
let girdleField = ['GIRDLE', 'GIRDLEMIN', 'GIRDLETHIN', 'GIRDLE THIN', 'GIRDLE(THINNEST)', 'GIRDLETHINNEST'];
let girdlethickField = ['GIRDLETHICK', 'GIRDLEMAX', 'GIRDLE THICK', 'GIRDLE(THICKEST)', 'GIRDLETHICKEST', 'GIRDLE(THICKNEST)', 'GIRDLETHICKNEST'];
let girdlepercentField = ['GIRDLE %', 'GIRDLEPERCENT'];
let pavilionField = ['PAVILION', 'PAVILION %', 'AVILION %', 'PAVILLION'];
let pavillionheightField = ['PAVILLION HEIGHT', 'PAVILIONDEPTH', 'PAVILION DEPTH', 'PAVILLIONDEPTH', 'PAVILION HEIGHT', 'PAVILLIONHEIGHT', 'PAVILIONHEIGHT', 'PAV HEIGHT'];
let pavilionangelField = ['PAVILION ANGEL', 'PAVILION ANGLE', 'PAVILIONANGEL', 'PAVILIONANGLE', 'PAVILLION ANGEL', 'PAVILLION ANGLE', 'PAVILLIONANGEL', 'PAVILLIONANGLE', 'PAV ANG'];
let crownangleField = ['CROWN ANGLE', 'CROWN ANGLE', 'CROWNANGLE', 'CROWNANGEL', 'CROWN ANG'];
let crownheightField = ['CROWNHEIGHT', 'CROWN HEIGHT'];
let crownField = ['CROWN', 'CROWN %'];
let culetField = ['CULET', 'CUL', 'CULETSIZE', 'CULET SIZE'];



fs.readFile(configFile, function (err, data) {
    
    parser.parseString(data, function (err, result) {        
       /// var rs = result.transformation.step;
        //if (result.transformation.step.name == 'Change Columns') {        
        //console.log("rsultt:", result.transformation.step[0].fields[0].field.length);
        console.log("filter row  index:", result.transformation.step[2].compare[0].condition[0].conditions[0].condition[1].leftvalue); //
        for (var i = 0; i < result.transformation.step[0].fields[0].field.length; i++) {            
            //console.log(cutShape);
            //console.log(result.transformation.step[0].fields[0].field[i].name);
            //console.log(cutShape.includes(result.transformation.step[0].fields[0].field[i].name+''));
            
            if (cutField.includes(result.transformation.step[0].fields[0].field[i].name + '')) {  
                result.transformation.step[0].fields[0].field[i].name = 'Shape';
            }
            if (colorField.includes(result.transformation.step[0].fields[0].field[i].name + '')) {
                result.transformation.step[0].fields[0].field[i].name = 'COLOR';
            }
            if (clarityField.includes(result.transformation.step[0].fields[0].field[i].name + '')) {
                result.transformation.step[0].fields[0].field[i].name = 'CLARITY';
            }
            if (cutgradeField.includes(result.transformation.step[0].fields[0].field[i].name + '')) {
                result.transformation.step[0].fields[0].field[i].name = 'CUTGRADE';
            }
            if (costpercaratField.includes(result.transformation.step[0].fields[0].field[i].name + '')) {
                result.transformation.step[0].fields[0].field[i].name = 'COSTPERCARAT';
            }
            if (depthField.includes(result.transformation.step[0].fields[0].field[i].name + '')) {
                result.transformation.step[0].fields[0].field[i].name = 'DEPTH';
            }
            if (tableField.includes(result.transformation.step[0].fields[0].field[i].name + '')) {
                result.transformation.step[0].fields[0].field[i].name = 'TABLE';
            }
            if (sizeField.includes(result.transformation.step[0].fields[0].field[i].name + '')) {
                result.transformation.step[0].fields[0].field[i].name = 'SIZE';
            }
            if (stockNumberField.includes(result.transformation.step[0].fields[0].field[i].name + '')) {
                result.transformation.step[0].fields[0].field[i].name = 'STOCKNUMBER';
            }
        }
        //}
        
        //result.widget= ['step'];
        
        var xml = xmlBuilder.buildObject(result);
        xml = "<transformation_configuration>" + xml + "<transformation_execution_configuration></transformation_execution_configuration></transformation_configuration>";
        console.log('Done', result);
        ///console.log("updated",xml);
        ///fs.writeFile(configFile, xml);
        //fs.writeFile(configFile, xml, function (err, result) {
        //    if (err) console.log('error', err);
        //});
    });
});
