﻿const AWS = require('aws-sdk');

//AWS.config.update({
//    region: "us-east-1",
//    endpoint: "http://localhost:3000"
//});
AWS.config.update({
    accessKeyId: '6or956c7uloo3t8nl89u9ac2rt',
    secretAccessKey: 'us-east-1:602888449674:userpool/us-east-1_UZ3sIxwTX',
    region: "us-east-1",
});
var dynamodb = new AWS.DynamoDB();

var params = {
    TableName: "Diamonds",
    KeySchema: [
        { AttributeName: "pk_id", KeyType: "HASH" },  //Partition key
        { AttributeName: "title", KeyType: "RANGE" }  //Sort key
    ],
    AttributeDefinitions: [
        { AttributeName: "pk_id", AttributeType: "N" },
        { AttributeName: "title", AttributeType: "S" }
    ],
    ProvisionedThroughput: {
        ReadCapacityUnits: 10,
        WriteCapacityUnits: 10
    }
};

dynamodb.createTable(params, function (err, data) {
    if (err) {
        console.error("Unable to create table. Error JSON:", JSON.stringify(err, null, 2));
    } else {
        console.log("Created table. Table description JSON:", JSON.stringify(data, null, 2));
    }
});
