﻿
const nodemailer = require("nodemailer");
var Redshift = require('node-redshift');
var cassandra = require('cassandra-driver');
var common = require("./common");

var csv = require('csv-parser');
var fs = require('fs');
///var json2csv = require('json2csv').parse;
const createCsvWriter = require('csv-writer').createObjectCsvWriter;
const multipart = require('connect-multiparty');
const multipartMiddleware = multipart({ uploadDir: 'C:/Hardeep/gemfind/NodeAPI/uploads/1004/' });
var contactPoints = ['127.0.0.1'];
var client = new cassandra.Client({ contactPoints: contactPoints, localDataCenter: 'datacenter1' });
client.connect(function (err, result) {
    console.log('user detail: cassandra connected');
});
var clientConfiguration = {
    user: "jewelcloudrs",
    database: "jewelcloud",
    password: "7pUHm2Qa9YsnFUV",
    port: 5439,
    host: "jewelcloud-rs.cvjykrynhxhb.us-east-1.redshift.amazonaws.com",///"jdbc:redshift://jewelcloud-rs.cvjykrynhxhb.us-east-1.redshift.amazonaws.com:5439/jewelcloud?ssl=true&sslfactory=com.amazon.redshift.ssl.NonValidatingFactory",
};
var transporter = nodemailer.createTransport({
    service: 'gmail',
    auth: {
        user: 'gemfindtest@gmail.com',
        pass: 'Test@123'
    }
});
var redshift = new Redshift(clientConfiguration);
//----------------------new code --------------start---------------------------
exports.getAlldiamond = function (req, res) {
    try {
        var query = "select  top 10 * from Diamonds";///"select count(*) from TempDiamonds"   var query = "select  top 100 * from TempDiamonds"; /// 
        var query2 = "select  COUNT(*) FROM Diamonds";
        redshift.connect(function (err) {
            redshift.query(query, { raw: true }, function (err, data) {
                redshift.query(query2, { raw: true }, function (err, data2) {
                    if (err) throw err;
                    else {

                        res.send({ status: 200, data: data, data2 });
                        // redshift.close();
                    }
                });
            });
        });
    } catch (e) {
        console.log(e);
    }
};

exports.getsearchValue = function (req, res) {
    try {
        console.log(req.body);
        var query = "select  top 10 * from Diamonds where dealerinventoryno LIKE  '" + req.body.searchvalue + "%'";
        redshift.connect(function (err) {
            redshift.query(query, { raw: true }, function (err, data) {
                if (err) throw err;
                else {
                    res.send({ status: 200, data: data });
                }
            });
        });
    } catch (e) {
        console.log(e);
    }
}
//-------------------------------------Delete Code


exports.delete_diamond = function (req, res) {
    try {
        var deletecount = 0;

        for (var i = 0; i < req.body.length; i++) {
            var id = req.body[i];
            var query = "DELETE FROM Diamonds WHERE dinventoryid = '" + id + "'";///"select count(*) from TempDiamonds"  /// 
            redshift.connect(function (err) {
                redshift.query(query, { raw: true }, function (err, data) {
                    if (err) throw err;
                    else {
                        deletecount++;
                    }
                });
            });
        }
        if (deletecount > 0) {
            res.send({ status: 200, data: 'Delete Dats Successfully' });
        }
        else {
            res.send({ status: 200, data: 'There is no Row Found To delete' });
        }
    }
    catch (e) {
        console.log(e);
    }
};
exports.addnewDiamond = function (req, res) {
    try {
        console.log(req.body);
        var input = req.body;

        var query = "INSERT INTO Diamonds (additionalimage,blackinclusion,centralinclusion,certificate,certificateimage,certificateno,city,clarity,clarityid,color,comments,costpercarat,country,crown,crownheight,crownpercentage,culet,culetcondition,customfield1,customfield1name,customfield2,customfield2name,customfield3,customfield3name,customfield4,customfield4name,customfield5,customfield5name,cut,cutgrade,dealerid,dealerinventoryno,depth,enhancements,eyecleaninclusion,fancycolorintensity,fancycolormainbody,fancycolorovertone,flourescence,flourescencecolor,girdle,girdlepercentage,girdlethickest,imagefilename,inventoryregion,isactive,keytosymbol,laserincription,lotnumber,measurements,measurementsheight,measurementslength,measurementswidth,milkyinclusion,modified,offrapaport,origin, outonmemo,pairseparable,pairstocknumber,pavillion,pavillionheight,pavillionpercentage,polish,price1,price2,ratio,shade,size,state,stones,symmetry,tablemeasure,thirdpartysellername,totalprice,treatment,videofilename,islabcreated) VALUES ('" + input.additionalimage + "', '" + input.blackinclusion + "', '" + input.centralinclusion + "', '" + input.certificate + "', '" + input.certificateimage + "', '" + input.certificateno + "', '" + input.city + "', '" + input.clarity + "', '" + input.clarityid + "', '" + input.color + "', '" + input.comments + "', " + input.costpercarat + ", '" + input.country + "', '" + input.crown + "', '" + input.crownheight + "', '" + input.crownpercentage + "','" + input.culet + "', '" + input.culetcondition + "', '" + input.customfield1 + "', '" + input.customfield1name + "', '" + input.customfield2 + "', '" + input.customfield2name + "', '" + input.customfield3 + "', '" + input.customfield3name + "', '" + input.customfield4 + "', '" + input.customfield4name + "', '" + input.customfield5 + "', '" + input.customfield5name + "', '" + input.cut + "','" + input.cutgrade + "', " + input.dealerid + ", '" + input.dealerinventoryno + "', " + input.depth + ", '" + input.enhancements + "', '" + input.eyecleaninclusion + "', '" + input.fancycolorintensity + "', '" + input.fancycolormainbody + "', '" + input.fancycolorovertone + "', '" + input.flourescence + "', '" + input.flourescencecolor + "', '" + input.girdle + "', '" + input.girdlepercentage + "', '" + input.girdlethickest + "', '" + input.imagefilename + "', '" + input.inventoryregion + "', '" + input.isactive + "', '" + input.keytosymbol + "', '" + input.laserincription + "', '" + input.lotnumber + "', '" + input.measurements + "', '" + input.measurementsheight + "', '" + input.measurementslength + "', '" + input.measurementswidth + "', '" + input.milkyinclusion + "', '" + input.modified + "', '" + input.offrapaport + "', '" + input.origin + "', '" + input.outonmemo + "', '" + input.pairseparable + "', '" + input.pairstocknumber + "', '" + input.pavillion + "', '" + input.pavillionheight + "', '" + input.pavillionpercentage + "', '" + input.polish + "', " + input.price1 + ", " + input.price2 + ", '" + input.ratio + "', '" + input.shade + "', " + input.size + ", '" + input.state + "', " + input.stones + ", '" + input.symmetry + "', " + input.tablemeasure + ", '" + input.thirdpartysellername + "', " + input.totalprice + ", '" + input.treatment + "','" + input.videofilename + "','" + input.islabcreated +"') ";
        var query2 = "select  COUNT(*) FROM Diamonds WHERE Dealerid = '" + input.dealerid + "'";
        //var query = "select * from TempDiamonds where certificateno = '123456789'";
        redshift.connect(function (err) {
            redshift.query(query, { raw: true }, function (err, data) {
                redshift.query(query2, { raw: true }, function (err, data2) {
                    if (err) throw err;
                    else {
                        console.log(data);
                        res.send({ status: 200, data: data, data2: data2 });
                    }
                });
            });
        });
    } catch (e) {
        console.log(e);
    }
};



exports.getDealerUploadDiamondColumn = function (req, res) {
    try {
        var dealerid = req.body.dealerid;
        console.log(req.body);
        client.execute("select * from key_gemfind.DealerUploadedColumn where dealerid ='" + dealerid + "' and status=0 ALLOW FILTERING;", [], function (err, result) {
            if (err) {
                console.log(err);
                res.status(404).send({ msg: err });
            } else {
                res.send({ status: 200, data: result.rows });
            }
        });
    } catch (e) {
        console.log(e);
    }
}
//----------End-----------------------



exports.getalldropdownValue = function (req, res) {
    client.execute("select * from key_gemfind.diamondculet", [], function (err, result1) {
        client.execute("select * from key_gemfind.diamondclarity", [], function (err, result2) {
            client.execute("select * from key_gemfind.diamondshape", [], function (err, result3) {
                client.execute("select * from key_gemfind.diamondpolish", [], function (err, result4) {
                    client.execute("select * from key_gemfind.diamondsymmetry", [], function (err, result5) {
                        client.execute("select * from key_gemfind.diamondfluorescence", [], function (err, result6) {
                            client.execute("select * from key_gemfind.diamondculetcondition", [], function (err, result7) {
                                client.execute("select * from key_gemfind.diamondgirdle", [], function (err, result8) {
                                    client.execute("select * from key_gemfind.diamondcutgrade", [], function (err, result9) {
                                        client.execute("select * from key_gemfind.diamondfancycolor", [], function (err, result10) {
                                            client.execute("select * from key_gemfind.diamondintensity", [], function (err, result11) {
                                                client.execute("select * from key_gemfind. diamond_certificate", [], function (err, result12) {
                                                    if (err) {
                                                        console.log('users: add err:', err);
                                                        res.status(404).send({ msg: err });
                                                    } else {
                                                        res.send({ status: 200, diamondculet: result1.rows, diamondclarity: result2.rows, diamondshape: result3.rows, diamondpolish: result4.rows, diamondsymmetry: result5.rows, diamondfluorescence: result6.rows, diamondculetcondition: result7.rows, diamondgirdle: result8.rows, diamondcutgrade: result9.rows, diamondfancycolor: result10.rows, diamondintensity: result11.rows, diamond_certificate: result12.rows });
                                                    }
                                                });
                                            });
                                        });
                                    });
                                });
                            });
                        });
                    });
                });
            });
        });
    });
};
//----------------------------- Set Email
exports.sendDiamondEmail = function (req, res) {
    var transporter = nodemailer.createTransport({
        service: 'gmail',
        auth: {
            user: 'gemfindtest@gmail.com',
            pass: 'Test@123'
        }
    });
    var input = req.body;
    try {
        client.execute("select * FROM key_gemfind.email_template where email_type='DiamondSend' allow filtering", [], function (err, result, fields) {
            if (err) {
                console.log('users: add err:', err);
                //res.status(404).send({ msg: err });
            } else {
                //console.log(result.rows[0]);
                var data2 = result.rows[0].email_body;
                var finalMail = data2.replace(/#name#/g, input.name);
                finalMail = finalMail.replace(/#markup#/g, input.markup);
                ///var finalMail2 = finalMail1.replace(/#description#/g, input.message);
                //console.log(input.EmailDiamond);
                var DiamondTable = "<table  width='100%' cellspacing='0' cellpadding='2' style='border: 1 solid;'> ";
                DiamondTable += " <tr align='center' style='font-weight: bold;'> <td style='border: 1 solid;'>Stock # </td> <td style='border: 1 solid;'>Shape </td> <td style='border: 1 solid;'>Size </td> <td style='border: 1 solid;'>Clarity </td> <td style='border: 1 solid;'>Color </td> <td style='border: 1 solid;'>Cut </td> <td style='border: 1 solid;'>Depth </td> <td style='border: 1 solid;'>Table </td> <td style='border: 1 solid;'>Polish </td> <td style='border: 1 solid;'>Sym. </td> <td style='border: 1 solid;'>Measure. </td> <td style='border: 1 solid;'>Cert. </td> <td style='border: 1 solid;'>Fluor. </td> <td style='border: 1 solid;'>Price($)</td> </tr > ";
                for (var i = 0; i < input.EmailDiamond.length; i++) {
                    DiamondTable += "<tr align='center'><td style='border: 1 solid;'>" + input.EmailDiamond[i].dealerinventoryno + "</td><td style='border: 1 solid;'>" + input.EmailDiamond[i].cut + "</td><td style='border: 1 solid;'>" + input.EmailDiamond[i].size + "</td><td style='border: 1 solid;'>" + input.EmailDiamond[i].clarity + "</td><td style='border: 1 solid;'>" + input.EmailDiamond[i].color + "</td><td style='border: 1 solid;'>" + input.EmailDiamond[i].cutgrade + "</td><td style='border: 1 solid;'>" + input.EmailDiamond[i].depth + "</td><td style='border: 1 solid;'>" + input.EmailDiamond[i].tablemeasure + "</td><td style='border: 1 solid;'>" + input.EmailDiamond[i].polish + "</td><td style='border: 1 solid;'>" + input.EmailDiamond[i].symmetry + "</td><td style='border: 1 solid;'>" + input.EmailDiamond[i].measurements + "</td><td style='border: 1 solid;'>" + input.EmailDiamond[i].certificate + "</td><td style='border: 1 solid;'>" + input.EmailDiamond[i].flourescence + "</td><td style='border: 1 solid;'>" + (input.EmailDiamond[i].totalprice + ((input.EmailDiamond[i].totalprice * input.markup) / 100)) + "</td></tr>";
                };
                DiamondTable += "</table>";
                input.message = input.message + "" + DiamondTable;
                //console.log(DiamondTable);
                finalMail = finalMail.replace(/#description#/g, input.message);

                var mailOptions = {
                    from: 'gemfindtest@gmail.com', // sender address
                    //cc: 'hardeep.yadav@rigelnetworks.com', // list of receivers
                    to: input.email, // list of receivers
                    subject: "Diamond Send      ", // Subject line
                    html: finalMail,
                };
                transporter.sendMail(mailOptions, function (error, info) {
                    if (error) {
                        console.log("1");
                        console.log(error);
                    } else {
                        console.log('Email sent: ' + info.response);
                    }
                });
                res.send({ status: 200, data: result.rows });
            }
        });
    } catch (e) {
        console.log(e)
    }
};
exports.getfiltredDiamond = function (req, res) {
    //try {
    //    console.log(req.body);
    //    var input = req.body;
    //    var query = "select top 10 * from TempDiamonds ";
    //    var polishQuery = "polish='" + input.polishStart + "'";
    //    var clarityQuery = "clarity='" + input.clarityStart + "'";
    //    var colorQuery = "color='" + input.colorStart + "'";
    //    var girdelQuery = "girdle='" + input.gridelStart + "'";
    //    var culetQuery = "culet='" + input.culetStart + "'";
    //    var culetConditionQuery = "culetcondition='" + input.culetConditionStart + "'";
    //    var flourescenceQuery = "flourescence='" + input.fluorescenceStart + "'";
    //    var tableQuery = "tablemeasure BETWEEN '" + input.tableStart + "' AND  '" + input.tableEnd + "'";
    //    var depthQuery = "depth BETWEEN '" + input.depthStart + "' AND  '" + input.depthEnd + "'";
    //    var priceQuery = "price1 BETWEEN '" + input.priceStart + "' AND  '" + input.priceEnd + "'";
    //    var costQuery = "costpercarat BETWEEN '" + input.priceCaretStart + "' AND  '" + input.priceCaretEnd + "'";
    //    var symmetryQuery = "symmetry='" + input.symmetryStart + "'";
    //    var cutQuery = "cutgrade='" + input.cutStart + "'";
    //    var shapeQuery = "cut IN ('" + input.shape + "')";

    //    if (input.polishStart !== "") {
    //        query = query + (query.includes('where') ? ' and ' + polishQuery : 'where ' + polishQuery);
    //        //redshift.connect(function (err) {

    //    }
    //    if (input.clarityStart !== "") {
    //        query = query + (query.includes('where') ? ' and ' + clarityQuery : 'where ' + clarityQuery);
    //        //redshift.connect(function (err) {

    //    }
    //    if (input.colorStart !== "") {
    //        query = query + (query.includes('where') ? 'and ' + colorQuery : 'where ' + colorQuery);

    //    }
    //    if (input.gridelStart !== "") {
    //        query = query + (query.includes('where') ? 'and ' + girdelQuery : 'where ' + girdelQuery);

    //    }

    //    if (input.culetStart !== "") {
    //        query = query + (query.includes('where') ? 'and ' + culetQuery : 'where ' + culetQuery);

    //    }
    //    if (input.fluorescenceStart !== "") {
    //        query = query + (query.includes('where') ? 'and ' + flourescenceQuery : 'where ' + flourescenceQuery);

    //    }
    //    if (input.tableStart !== "") {
    //        query = query + (query.includes('where') ? 'and ' + tableQuery : 'where ' + tableQuery);

    //    }
    //    if (input.depthStart !== "") {
    //        query = query + (query.includes('where') ? 'and ' + depthQuery : 'where ' + depthQuery);

    //    }
    //    if (input.priceStart !== "") {
    //        query = query + (query.includes('where') ? 'and ' + priceQuery : 'where ' + priceQuery);

    //    }
    //    if (input.priceCaretStart !== "") {
    //        query = query + (query.includes('where') ? 'and ' + costQuery : 'where ' + costQuery);

    //    }
    //    if (input.culetConditionStart !== "") {
    //        query = query + (query.includes('where') ? 'and ' + culetConditionQuery : 'where ' + culetConditionQuery);

    //    }
    //    if (input.symmetryStart !== "") {
    //        query = query + (query.includes('where') ? 'and ' + symmetryQuery : 'where ' + symmetryQuery);

    //    }
    //    if (input.cutStart !== "") {
    //        query = query + (query.includes('where') ? 'and ' + cutQuery : 'where ' + cutQuery);

    //    }
    //    if (input.shape !== "") {
    //        query = query + (query.includes('where') ? 'and ' + shapeQuery : 'where ' + shapeQuery);

    //    }



    //    redshift.query(query, { raw: true }, function (err, data) {
    //        if (err) throw err;
    //        else {
    //            res.send({ status: 200, data: data });
    //        }
    //    });

    //} catch (e) {
    //    console.log(e);
    //}
};
exports.getAlldiamonddemo = function (req, res) {
    try {
        var skip = req.body.skip;
        var take = req.body.take;

        var input = req.body.filter;
        var query = "select * from Diamonds ";       
        //var query = "select DealerInventoryNo ,Cut , Color,  Clarity, ClarityID, CutGrade, CostPerCarat, TotalPrice, Depth, TableMeasure, Size, Dealerid, DInventoryID, Polish, Symmetry, Flourescence, FlourescenceColor, Certificate, CertificateNo, Measurements, MeasurementsLength, MeasurementsHeight, MeasurementsWidth, Girdle, GirdleThickest, GirdlePercentage, Pavillion, PavillionHeight, PavillionPercentage, Crown, CrownHeight, CrownPercentage, Culet, CuletCondition, FancyColorMainBody, FancyColorintensity, FancyColorOvertone , PairStockNumber, PairSeparable, CertificateImage, AdditionalImage, ImageFileName, VideoFileName, LotNumber, OutOnMemo, Stones, InventoryRegion, City, State, Country, Origin, OffRapaport, Enhancements, LaserIncription, Shade, Treatment, KeyToSymbol, BlackInclusion, CentralInclusion, MilkyInclusion, EyeCleanInclusion, Comments, Modified, IsActive, Price1, Price2, Ratio, ThirdPartySellerName, CustomField1Name, CustomField1, CustomField2Name, CustomField2, CustomField3Name, CustomField3, CustomField4Name, CustomField4, CustomField5Name, CustomField5 from TempDiamonds ";
        

        if (input) {
            if (input) {
                if (req.body.filter.searchvalue) {
                    skip = 0;
                    query = query + "where dealerinventoryno LIKE  '%" + req.body.filter.searchvalue + "%' and dealerid = '" + req.body.filter.dealerid + "'";
                    //query = query + "where dealerinventoryno LIKE  '%" + req.body.filter.searchvalue + "%' or dinventoryid LIKE  '%" + req.body.filter.searchvalue + "%'";
                }
                else if(req.body.filter.dealerid) {
                    query = query + "where dealerid = '" + req.body.filter.dealerid + "'";
                }
            }
            if (req.body.diamondType) {
                if (req.body.diamondType === 'natural') {
                    query = query + (query.includes('where') ? ' and ' + " IsLabCreated != '1' and  fancycolormainbody = '' and fancycolorintensity = '' and fancycolorovertone = ''" : 'where ' +" IsLabCreated != '1' and  fancycolormainbody = '' and fancycolorintensity = '' and fancycolorovertone = ''");
                }
                if (req.body.diamondType === 'labDiamond') {
                    query = query + (query.includes('where') ? ' and ' + " IsLabCreated = '1'" : 'where ' + " IsLabCreated = '1'");
                }
                if (req.body.diamondType === 'colorDiamond') {
                    query = query + (query.includes('where') ? ' and ' + " (fancycolormainbody !='' or fancycolorintensity !='' or fancycolorovertone != '')" : 'where ' + "(fancycolormainbody !='' or fancycolorintensity !='' or fancycolorovertone != '')");
                }
            }
            if (req.body.filter.caretEnd) {
                //var polishQuery = "polish='" + input.polishStart + "'";
                var polishQuery = "polish IN ('" + input.polishStart + "')";
                //var clarityQuery = "clarity='" + input.clarityStart + "'";
                var clarityQuery = "clarity IN ('" + input.clarityStart + "')";
                //var colorQuery = "color='" + input.colorStart + "'";
                var colorQuery = "color IN ('" + input.colorStart + "')";
                var girdelQuery = "girdle='" + input.gridelStart + "'";
                var culetQuery = "culet='" + input.culetStart + "'";
                var culetConditionQuery = "culetcondition='" + input.culetConditionStart + "'";
                var flourescenceQuery = "flourescence='" + input.fluorescenceStart + "'";
                var tableQuery = "tablemeasure BETWEEN '" + input.tableStart + "' AND  '" + input.tableEnd + "'";
                var depthQuery = "depth BETWEEN '" + input.depthStart + "' AND  '" + input.depthEnd + "'";
                var priceQuery = "totalprice BETWEEN '" + input.priceStart + "' AND  '" + input.priceEnd + "'";
                var costQuery = "costpercarat BETWEEN '" + input.priceCaretStart + "' AND  '" + input.priceCaretEnd + "'";
                var symmetryQuery = "symmetry='" + input.symmetryStart + "'";
                //var cutQuery = "cutgrade='" + input.cutStart + "'";
                var cutQuery = "cutgrade IN ('" + input.cutStart + "')";
                var shapeQuery = "cut IN ('" + input.shape + "')";
                var certificateQuery = "certificate='" + input.certificate + "'";
                var dialeridQuery = "dealerid='" + input.dialerid + "'";

                if (input.polishStart !== "") {
                    query = query + (query.includes('where') ? ' and ' + polishQuery : 'where ' + polishQuery);
                    //redshift.connect(function (err) {
                }
                if (input.clarityStart !== "") {
                    query = query + (query.includes('where') ? ' and ' + clarityQuery : 'where ' + clarityQuery);
                    //redshift.connect(function (err) {
                }
                if (input.colorStart !== "") {
                    query = query + (query.includes('where') ? 'and ' + colorQuery : 'where ' + colorQuery);
                }
                if (input.gridelStart !== "") {
                    query = query + (query.includes('where') ? 'and ' + girdelQuery : 'where ' + girdelQuery);
                }
                if (input.culetStart !== "") {
                    query = query + (query.includes('where') ? 'and ' + culetQuery : 'where ' + culetQuery);
                }
                if (input.fluorescenceStart !== "") {
                    query = query + (query.includes('where') ? 'and ' + flourescenceQuery : 'where ' + flourescenceQuery);

                }
                if (input.tableStart !== "") {
                    query = query + (query.includes('where') ? 'and ' + tableQuery : 'where ' + tableQuery);

                }
                if (input.depthStart !== "") {
                    query = query + (query.includes('where') ? 'and ' + depthQuery : 'where ' + depthQuery);

                }
                if (input.priceStart !== "") {
                    query = query + (query.includes('where') ? 'and ' + priceQuery : 'where ' + priceQuery);

                }
                if (input.priceCaretStart !== "") {
                    query = query + (query.includes('where') ? 'and ' + costQuery : 'where ' + costQuery);

                }
                if (input.culetConditionStart !== "") {
                    query = query + (query.includes('where') ? 'and ' + culetConditionQuery : 'where ' + culetConditionQuery);
                }
                if (input.symmetryStart !== "") {
                    query = query + (query.includes('where') ? 'and ' + symmetryQuery : 'where ' + symmetryQuery);
                }
                if (input.cutStart !== "") {
                    query = query + (query.includes('where') ? 'and ' + cutQuery : 'where ' + cutQuery);
                }
                if (input.shape !== "") {
                    query = query + (query.includes('where') ? 'and ' + shapeQuery : 'where ' + shapeQuery);
                }
                if (input.certificate !== "") {
                    query = query + (query.includes('where') ? 'and ' + certificateQuery : 'where ' + certificateQuery);
                }
                if (input.dialerid !== "") {
                    query = query + (query.includes('where') ? 'and ' + dialeridQuery : 'where ' + certificateQuery);
                }
            }
        }
        var query3 = query;
        var query2 = query3.replace("*", "COUNT(*)");
        query = query + " ORDER BY DinventoryID  OFFSET " + skip + " LIMIT " + take;
        //var query2 = "select  COUNT(*) FROM TempDiamonds";

        redshift.connect(function (err) {
            redshift.query(query, { raw: true }, function (err, data) {
                redshift.query(query2, { raw: true }, function (err, data2) {
                    console.log(data2);
                    if (err) {
                        console.log(err);
                    }
                    else {
                        res.send({ status: 200, data: data,data2});
                        // redshift.close();
                    }
                });
            });
        });

    } catch (e) {

        console.log(e);

    }

};
exports.getAlldiamondAlluser = function (req, res) {
    try {
        var skip = req.body.skip;
        var take = req.body.take;

        var input = req.body.filter;
        var query = "select * from Diamonds ";
        if (req.body.diamondType) {
            if (req.body.diamondType === 'allNaturalDiamond') {
                query = query + (query.includes('where') ? ' and ' + " (IsLabCreated ='' or IsLabCreated is null) and (fancycolormainbody ='' or fancycolormainbody is null) and (fancycolorintensity ='' or fancycolorintensity is null) and (fancycolorovertone ='' or fancycolorovertone is null)" : 'where ' + " (IsLabCreated ='' or IsLabCreated is null) and (fancycolormainbody ='' or fancycolormainbody is null) and (fancycolorintensity ='' or fancycolorintensity is null) and (fancycolorovertone ='' or fancycolorovertone is null)");
            }
            if (req.body.diamondType === 'allLabDiamond') {
                query = query + (query.includes('where') ? ' and ' + " (IsLabCreated ='1' )" : 'where ' + "  (IsLabCreated ='1' ) ");
            }
            if (req.body.diamondType === 'allColorDiamond') {
                query = query + (query.includes('where') ? ' and ' : 'where ' + "(fancycolormainbody !='' or fancycolorintensity !='' or fancycolorovertone != '') ");
            }
        }
        if (input) {
            if (req.body.filter.searchvalue) {
                skip = 0;
                query = query + (query.includes('where') ? ' and ' : 'where ') + " dealerinventoryno LIKE  '%" + req.body.filter.searchvalue + "%'";
                //query = query + "where dealerinventoryno LIKE  '%" + req.body.filter.searchvalue + "%' or dinventoryid LIKE  '%" + req.body.filter.searchvalue + "%'";
            }
           
            else if (req.body.filter.searchvalue === "") {
                query;
            }
            else {
                //var polishQuery = "polish='" + input.polishStart + "'";
                var polishQuery = "polish IN ('" + input.polishStart + "')";
                //var clarityQuery = "clarity='" + input.clarityStart + "'";
                var clarityQuery = "clarity IN ('" + input.clarityStart + "')";
                //var colorQuery = "color='" + input.colorStart + "'";
                var colorQuery = "color IN ('" + input.colorStart + "')";
                var girdelQuery = "girdle='" + input.gridelStart + "'";
                var culetQuery = "culet='" + input.culetStart + "'";
                var culetConditionQuery = "culetcondition='" + input.culetConditionStart + "'";
                var flourescenceQuery = "flourescence='" + input.fluorescenceStart + "'";
                var tableQuery = "tablemeasure BETWEEN '" + input.tableStart + "' AND  '" + input.tableEnd + "'";
                var depthQuery = "depth BETWEEN '" + input.depthStart + "' AND  '" + input.depthEnd + "'";
                var priceQuery = "totalprice BETWEEN '" + input.priceStart + "' AND  '" + input.priceEnd + "'";
                var costQuery = "costpercarat BETWEEN '" + input.priceCaretStart + "' AND  '" + input.priceCaretEnd + "'";
                var symmetryQuery = "symmetry='" + input.symmetryStart + "'";
                //var cutQuery = "cutgrade='" + input.cutStart + "'";
                var cutQuery = "cutgrade IN ('" + input.cutStart + "')";
                var shapeQuery = "cut IN ('" + input.shape + "')";
                var certificateQuery = "certificate='" + input.certificate + "'";
                var sizeQuery = "size BETWEEN '" + input.caretStart + "' AND  '" + input.caretEnd + "'";
                
                //var dialeridQuery = "dealerid='" + input.dialerid + "'";

                if (input.polishStart !== "") {
                    query = query + (query.includes('where') ? ' and ' + polishQuery : 'where ' + polishQuery);
                    //redshift.connect(function (err) {
                }
                if (input.clarityStart !== "") {
                    query = query + (query.includes('where') ? ' and ' + clarityQuery : 'where ' + clarityQuery);
                    //redshift.connect(function (err) {
                }
                if (input.colorStart !== "") {  
                    query = query + (query.includes('where') ? 'and ' + colorQuery : 'where ' + colorQuery);
                }
                if (input.gridelStart !== "") {
                    query = query + (query.includes('where') ? 'and ' + girdelQuery : 'where ' + girdelQuery);
                }
                if (input.culetStart !== "") {
                    query = query + (query.includes('where') ? 'and ' + culetQuery : 'where ' + culetQuery);
                }
                if (input.fluorescenceStart !== "") {
                    query = query + (query.includes('where') ? 'and ' + flourescenceQuery : 'where ' + flourescenceQuery);

                }
                if (input.tableStart !== "") {
                    query = query + (query.includes('where') ? 'and ' + tableQuery : 'where ' + tableQuery);

                }
                if (input.depthStart !== "") {
                    query = query + (query.includes('where') ? 'and ' + depthQuery : 'where ' + depthQuery);

                }
                if (input.priceStart !== "") {
                    query = query + (query.includes('where') ? 'and ' + priceQuery : 'where ' + priceQuery);

                }
                if (input.priceCaretStart !== "") {
                    query = query + (query.includes('where') ? 'and ' + costQuery : 'where ' + costQuery);

                }
                if (input.culetConditionStart !== "") {
                    query = query + (query.includes('where') ? 'and ' + culetConditionQuery : 'where ' + culetConditionQuery);
                }
                if (input.symmetryStart !== "") {
                    query = query + (query.includes('where') ? 'and ' + symmetryQuery : 'where ' + symmetryQuery);
                }
                if (input.cutStart !== "") {
                    query = query + (query.includes('where') ? 'and ' + cutQuery : 'where ' + cutQuery);
                }
                if (input.shape !== "") {
                    query = query + (query.includes('where') ? 'and ' + shapeQuery : 'where ' + shapeQuery);
                }
                if (input.certificate !== "") {
                    query = query + (query.includes('where') ? 'and ' + certificateQuery : 'where ' + certificateQuery);
                }
                if (input.caretStart !== "") {
                    query = query + (query.includes('where') ? 'and ' + sizeQuery : 'where ' + sizeQuery);
                }
                
                //if (input.dialerid !== "") {
                //    query = query + (query.includes('where') ? 'and ' + dialeridQuery : 'where ' + certificateQuery);
                //}
            }
        }
        var query3 = query;
        var query2 = query3.replace("*", "COUNT(*)");
        query = query + " ORDER BY DinventoryID  OFFSET " + skip + " LIMIT " + take;
        //var query2 = "select  COUNT(*) FROM TempDiamonds";

        redshift.connect(function (err) {
            redshift.query(query, { raw: true }, function (err, data) {
                redshift.query(query2, { raw: true }, function (err, data2) {
                    console.log(data2);
                    if (err) {
                        console.log(err);
                    }
                    else {
                        res.send({ status: 200, data: data, data2 });
                        // redshift.close();
                    }
                });
            });
        });

    } catch (e) {

        console.log(e);

    }

};

exports.getTotalDiamonds = function (req, res) {
    try {
        console.log("Test");
        var queryNaturaldiamond = "select count(*) as totaldiamond from Diamonds where Dealerid='" + req.body.dealerid +"' and IsLabCreated != '1' and  fancycolormainbody = '' and fancycolorintensity = '' and fancycolorovertone = ''";
        var queryLabdiamond = "select count(*) as totaldiamond from Diamonds where Dealerid='" + req.body.dealerid + "' and IsLabCreated = '1'";
        var queryColordiamond = "select count(*) as totaldiamond from Diamonds where Dealerid='" + req.body.dealerid + "' and (fancycolormainbody !='' or fancycolorintensity !='' or fancycolorovertone != '')";
        console.log(queryNaturaldiamond);
        redshift.connect(function (err) {
            redshift.query(queryNaturaldiamond, { raw: true }, function (err, data) {
                redshift.query(queryLabdiamond, { raw: true }, function (err, labdiamond) {
                    redshift.query(queryColordiamond, { raw: true }, function (err, colordiamond) {
                        if (!err)
                            res.send({ status: 200, data: data, labdiamond, colordiamond });
                
                    });
                });
            });
        });
    } catch (e) {
        console.log(e);
    }
};

//------------Mapping Section ------------///
exports.addDealerUploadedDiamondColumns = function (req, res) {
    try {
        var input = req.body.columnList;
        var dealerid = req.body.dealerid;
        var ids = "";
        client.execute("select id from key_gemfind.DealerUploadedColumn where dealerid='" + dealerid + "' ALLOW FILTERING;", function (err, result) {
            if (err) {
                console.log(err);
            } else {
                
                if (result.rows.length > 0) {
                    query2 = "";
                    for (var j = 0; j < result.rows.length; j++) {
                        query2 = "delete from key_gemfind.DealerUploadedColumn where id = " + result.rows[j].id +"";
                        var ddd = common.queryCassandra(query2);
                        //client.execute("delete from key_gemfind.DealerUploadedColumn where dealerid='" + dealerid + "' and id = " + result.rows[j].id + " IF EXISIT", function (err, result) {
                        //    if (result) {
                        //        Console.log('successs');
                        //    }
                        //});
                        //ids += result.rows[j].id + ",";
                    }
                    client.execute(query, function (err, result) {
                        if (err) {
                            console.log(err);
                            //res.status(404).send({ msg: err });
                        } else {
                            console.log("done");
                            //res.send({ status: 200, data: null });
                        }
                    });
                    //ids = ids.replace(/,\s*$/, "");
                    //client.execute("delete from key_gemfind.DealerUploadedColumn where dealerid='" + dealerid + "' and id in (" + ids + ") IF EXISIT", function (err, result) {
                    //    if (result) {
                    //        Console.log('successs');
                    //    }
                    //});
                }
            }
        });


        var query = "";
        for (var i = 0; i < input.length; i++) {
            input[i] = input[i].toString().replace(/"/g, "", '');
            query = "insert into key_gemfind.DealerUploadedColumn(id,columnname,dealerid,status) values(now(),\'" + input[i] + "\',\'" + dealerid + "\',0);";
            var ddd = common.queryCassandra(query);
        }
        console.log(query);
        client.execute(query, function (err, result) {
            if (err) {
                console.log(err);
                res.status(404).send({ msg: err });
            } else {
                console.log("done");
                res.send({ status: 200, data: null });
            }
        });
    } catch (e) {
        console.log(e);
    }
}

//exports.addDealerUploadedDiamondColumns = function (req, res) {
//    try {
//        var input = req.body.columnList;
//        var dealerid = req.body.dealerid;
//        var ids = "";
//        client.execute("select id from key_gemfind.DealerUploadedColumn where dealerid='" + dealerid + "' ALLOW FILTERING;", function (err, result) {
//            if (err) {
//            } else {
//                
//                if (result.rows.length > 0) {
//                    for (var j = 0; j < result.rows.length; j++) {
//                        ids += result.rows[i].id + ",";
//                    }
//                    ids = ids.replace(/,\s*$/, "");
//                    client.execute("DELETE From key_gemfind.DealerUploadedColumn where dealerid='" + dealerid + "' and id in (" + ids + ") IF EXISIT", function (err, result) {
//                    })
//                }
//            }
//        });


//        var query = "";
//        for (var i = 0; i < input.length; i++) {
//            input[i] = input[i].toString().replace(/"/g, "", '');
//            query = "insert into key_gemfind.DealerUploadedColumn(id,columnname,dealerid,status) values(now(),\'" + input[i] + "\',\'" + dealerid + "\',0);";
//            var ddd = common.queryCassandra(query);
//        }
//        console.log(query);
//        client.execute(query, function (err, result) {
//            if (err) {
//                console.log(err);
//                res.status(404).send({ msg: err });
//            } else {
//                console.log("done");
//                res.send({ status: 200, data: null });
//            }
//        });
//    } catch (e) {
//        console.log(e);
//    }
//}
//exports.getDiamondmappingData = function (req, res) {
//    try {
//        client.execute("select * from key_gemfind.jewelclouddiamondcoulmns", [], function (err, result) {
//            if (err) {
//                console.log('users: add err:', err);
//                res.status(404).send({ msg: err });
//            } else {
//                res.send({ status: 200, data: result.rows });
//            }
//        });
//    } catch (e) {
//        console.log(e);
//    }
//};
exports.getDiamondmappingData = function (req, res) {
    var diamondColumnRight;
    var diamondMappingColumn;
    try {
        client.execute("select * from key_gemfind.jewelclouddiamondcoulmns", [], function (err, result) {
            if (err) {
                console.log('users: add err:', err);
                res.status(404).send({ msg: err });
            } else {
                if (result.rows.length !== 0) {
                    diamondColumnRight = result.rows;
                    try {
                        client.execute("select * from key_gemfind.dealerdiamondcolumns where dealerid='" + req.body.dealerid + "' ALLOW FILTERING;", [], function (err, result) {
                            if (err) {
                                console.log('users: add err:', err);
                                res.status(404).send({ msg: err });
                            } else {
                                console.log(result.rows);
                                if (result.rows.length !== 0) {
                                    diamondMappingColumn = result.rows;
                                    for (var i = 0; i < diamondColumnRight.length; i++) {
                                        var data = diamondColumnRight[i];

                                        for (var j = 0; j < diamondMappingColumn.length; j++) {
                                            var data2 = diamondMappingColumn[j];
                                            if (diamondColumnRight[i].id.toString() === data2.jewelcloudcolumnid.toString()) {
                                                diamondColumnRight[i].Mapptingvalue = data2.columnname;
                                                diamondColumnRight[i].MapptingvaluePk_Id = data2.id;
                                                diamondColumnRight[i].dealerid = data2.dealerid;
                                                diamondColumnRight[i].columnid = data2.columnid;
                                                break;
                                            }
                                            else {
                                                diamondColumnRight[i].Mapptingvalue = "";
                                            }
                                        }
                                    }
                                    //res.send({ status: 200, data: diamondColumnRight });
                                }
                                res.send({ status: 200, data: diamondColumnRight });
                            }
                        });
                    } catch (e) {
                        console.log(e);
                    }
                }

            }
        });
    } catch (e) {
        console.log(e);
    }
};
exports.getDealerDiamondmappingData = function (req, res) {
    try {

        client.execute("select * from key_gemfind.dealerdiamondcolumns where dealerid='" + req.body.dealerid + "' ALLOW FILTERING;", [], function (err, result) {
            if (err) {
                console.log('users: add err:', err);
                res.status(404).send({ msg: err });
            } else {
                console.log(result.rows);
                res.send({ status: 200, data: result.rows });
            }
        });
    } catch (e) {
        console.log(e);
    }
};
exports.savemappedData = function (req, res) {
    try {
        console.log(req.body);
        //for (var i = 0; i < req.body.length; i++) {getDiamondmappingData
        var input = req.body;

        client.execute("insert into key_gemfind.dealerdiamondcolumns (id, columnname, dealerid, jewelcloudcolumnid,columnId) values (now(), '" + input.Mapptingvalue + "', '" + input.dealerid + "', " + input.id + ", " + input.columnid + ")", [], function (err, result) {
            if (err) {
                console.log('customers: save_edit err:', err);
                //res.status(404).send({ msg: err });
            } else {
            }
        });
        console.log("update key_gemfind.dealeruploadedcolumn set status = 1  WHERE id =" + input.columnid + "and dealerid='" + req.body.dealerid + "'");
        client.execute("update key_gemfind.dealeruploadedcolumn set status = 1  WHERE id =" + input.columnid + "and dealerid='" + req.body.dealerid + "'", [], function (err, result) {
            if (err) {
                console.log('customers: save_edit err:', err);
            } else {
            }
        });
        //}
        res.send({ status: 200, data: "Save Successfully.." });
    } catch (e) {
        console.log(e);
    }


};
exports.removeMapping = function (req, res) {
    var input = req;

    try {
        client.execute("update key_gemfind.dealeruploadedcolumn set status = 0 WHERE id =" + req.body.columnid + "and dealerid='" + req.body.dealerid + "'", [], function (err, result) {
            if (err) {
                console.log('users: add err:', err);
                //res.status(404).send({ msg: err });
            } else {
                console.log(result.rows);
                //res.send({ status: 200, data: result.rows });
            }
        });
        console.log("delete from key_gemfind.dealerdiamondcolumns where id =" + req.body.id);
        client.execute("delete from key_gemfind.dealerdiamondcolumns where id =" + req.body.id, [], function (err, result) {
            if (err) {
                console.log('users: add err:', err);
                ///res.status(404).send({ msg: err });
            } else {
                console.log(result.rows);
                res.send({ status: 200, data: result.rows });
            }
        });
    } catch (e) {
        console.log(e);
    }
};

//----------Mapping Section ---------//

//----------Retailer Section ---------//
exports.AllConnectedRetailers = function (req, res) {
    try {
        var dealerid = req.body.dealerid;
        console.log(dealerid);
        var query = "select id,VendorDealerID, RetailerDealerID, CompanyName, CompanyCity, CompanyState, Companycountry, CompanyEmail, RequestedDate, ApprovedDate, IsDiamond, IsFancyDiamond, IsLabGrownDiamond, IsApproved from key_gemfind.VendorDiamondConnectedRetailers where vendordealerid='" + dealerid + "' and isapproved=1 ALLOW FILTERING;";
        console.log(query);
        client.execute(query, [], function (err, result) {
            if (err) {
                res.status(404).send({ msg: err });
                console.log(err);
            } else {
                //console.log(result.rows);
                res.send({ status: 200, data: result.rows });
            }
        });
    }
    catch (e) {
        console.log(e);
    }

};
exports.AllRetailersRequest = function (req, res) {
    try {
        var dealerid = req.body.dealerid;
        var query = "select id,VendorDealerID, RetailerDealerID, CompanyName, CompanyCity, CompanyState, Companycountry, CompanyEmail, RequestedDate, ApprovedDate, IsDiamond, IsFancyDiamond, IsLabGrownDiamond, IsApproved from key_gemfind.VendorDiamondConnectedRetailers where vendordealerid='" + dealerid + "' and isapproved=0 ALLOW FILTERING;";
        client.execute(query, [], function (err, result) {
            if (err) {
                res.status(404).send({ msg: err });
                console.log(err);
            } else {
                //console.log(result.rows);
                res.send({ status: 200, data: result.rows });
            }
        });
    }
    catch (e) {
        console.log(e);
    }

};
exports.AcceptRetailerRequeset = function (req, res) {
    try {
        console.log(req.body);
        var id = req.body.id;

        var query = "update key_gemfind.VendorDiamondConnectedRetailers set isapproved = 1, isdiamond = 1  where id=" + id + ";";
        //console.log(query);
        client.execute(query, [], function (err, result) {
            if (err) {
                res.status(404).send({ msg: err });
            } else {
                console.log(result.rows);
                res.send({ status: 200, data: result.rows });
            }
        });
    }
    catch (e) {
        console.log(e);
    }
};
exports.DeclineRetailerRequeset = function (req, res) {
    try {
        console.log(req.body);
        var id = req.body.id;

        var query = "delete from key_gemfind.VendorDiamondConnectedRetailers where id=" + id;
        client.execute(query, [], function (err, result) {
            if (err) {
                res.status(404).send({ msg: err });
            } else {
                console.log(result.rows);
                res.send({ status: 200, data: result.rows });
            }
        });
    }
    catch (e) {
        console.log(e);
    }
};
exports.ChangeRetailerDiamondAccess = function (req, res) {
    try {
        console.log(req.body);
        var id = req.body.id;
        var type = req.body.type;
        var status = req.body.status;
        var query = "";
        if (type === "Diamond")
            query = "update key_gemfind.VendorDiamondConnectedRetailers set IsDiamond=" + status + " where id =" + id;
        else if (type === "FancyColorDiamond")
            query = "update key_gemfind.VendorDiamondConnectedRetailers set IsFancyDiamond=" + status + " where id =" + id;
        else if (type === "LabGrownDiamond")
            query = "update key_gemfind.VendorDiamondConnectedRetailers set IsLabGrownDiamond=" + status + " where id =" + id;
        client.execute(query, [], function (err, result) {
            if (err) {
                res.status(404).send({ msg: err });
                console.log(err);
            } else {
                //console.log(result.rows);
                res.send({ status: 200, data: result.rows });
            }
        });
    }
    catch (e) {
        console.log(e);
    }
};
//------Retailer section --------//


exports.getfileData = function (req, res) {

    var newLine = "\r\n";
    var FileName = req.file_name;
    var uploadedRecords = req.numrecords;
    var status = req.status;
    var DateTime = req.updated_date
    var lstCsvData = [];
    var finalOutputFile = './FinalOutputFiles/error_' + FileName;
    var finalInputFile = './FinalOutputFiles/UploadReport1_' + FileName;

    var toCsv = [
        { id: 'STOCKNUMBER', title: 'Diamond File Upload' },
        { id: 'ERRORDESCRIPTION', title: '' },
        { id: 'ERRORCODE', title: '' },
    ];

    try {
        if (fs.existsSync(finalInputFile)) {
            //file exists
        } else {
            fs.writeFile(finalInputFile, 'Diamond file upload', function (err) {
                if (err) throw err;
                console.log('Saved!');
            });
        }
    } catch (err) {
        console.error(err)
    }

    const csvWriter = createCsvWriter({
        path: finalOutputFile,
        header: toCsv
    });

    fs.stat(finalInputFile, function (err, stat) {
        lstCsvData = [];
        if (err == null) {
            fs.createReadStream(finalInputFile)
                .pipe(csv())
                .on('data', (row) => {

                    if (row.STOCKNUMBER || row.ERRORDESCRIPTION || row.ERRORCODE)
                        lstCsvData.push({ 'STOCKNUMBER': row.STOCKNUMBER, 'ERRORDESCRIPTION': row.ERRORDESCRIPTION }); //, 'ERRORCODE': row.ERRORCODE 
                    else
                        lstCsvData.push({ 'STOCKNUMBER': '', 'ERRORDESCRIPTION': 'File header does not contain required fields : No diamond uploaded. Cut(Shape), Size, Color, Clarity, CostPerCarat, Inventory Stock No  cannot be empty (null) otherwise line will be rejected.', 'ERRORCODE': '' });
                })
                .on('end', () => {
                    console.log('CSV file successfully processed');

                    //[{ 'File Name', FileName, '', ''}, { 'status', status, '', ''}, { 'Records', uploadedRecords, '', ''}, { 'Date', DateTime, '', '' }]
                    var lstData = [
                        { 'STOCKNUMBER': 'File Name', 'ERRORDESCRIPTION': FileName, 'ERRORCODE': '' },
                        { 'STOCKNUMBER': 'Status', 'ERRORDESCRIPTION': status, 'ERRORCODE': '' },
                        { 'STOCKNUMBER': 'Added Records', 'ERRORDESCRIPTION': uploadedRecords, 'ERRORCODE': '' }, //, 'DateTime': ''
                        { 'STOCKNUMBER': 'Date Time', 'ERRORDESCRIPTION': DateTime, 'ERRORCODE': '' },
                        { 'STOCKNUMBER': '', 'ERRORDESCRIPTION': '', 'ERRORCODE': '' },
                        { 'STOCKNUMBER': 'STOCKNUMBER', 'ERRORDESCRIPTION': 'ERRORDESCRIPTION', 'ERRORCODE': 'ERRORCODE' }
                    ];

                    ///console.log(lstData);
                    for (var i = 0; i < lstCsvData.length; i++) {
                        lstData.push(lstCsvData[i]);
                    }

                    //[{ FileName, status, uploadedRecords, DateTime }]
                    csvWriter
                        .writeRecords(lstData)
                        .then(() => console.log('successfully write.'));
                    //res.send({ status: 200, data: stat })
                    //csvWriter
                    //    .writeRecords(lstCsvData)
                    //    .then(() => console.log('The CSV file was written successfully'));
                });

        } else {
            var lstData = [
                { 'STOCKNUMBER': 'File Name', 'ERRORDESCRIPTION': FileName, 'ERRORCODE': '' },
                { 'STOCKNUMBER': 'Status', 'ERRORDESCRIPTION': status, 'ERRORCODE': '' },
                { 'STOCKNUMBER': 'Upload Records', 'ERRORDESCRIPTION': uploadedRecords, 'ERRORCODE': '' }, //, 'DateTime': ''
                { 'STOCKNUMBER': 'Date Time', 'ERRORDESCRIPTION': DateTime, 'ERRORCODE': '' },
                { 'STOCKNUMBER': '', 'ERRORDESCRIPTION': '', 'ERRORCODE': '' },
                { 'STOCKNUMBER': 'STOCKNUMBER', 'ERRORDESCRIPTION': 'ERRORDESCRIPTION', 'ERRORCODE': 'ERRORCODE' }
            ];
            fs.writeFile('./FinalOutputFiles/error_' + FileName, lstData, function (err, stat) {
                if (err) throw err;
                console.log('file saved');
                //res.send({ status: 200, data: stat });
            });
        }

    });

    //fs.stat(finalPathFile, function (err, stat) {
    //    if (err == null) {
    //        console.log('File exists');
    //        //write the actual data and end with newline
    //        var csv = newLine + json2csv(toCsv) + newLine;
    //        fs.appendFile(finalPathFile, csv, function (err) {
    //            if (err) throw err;
    //            console.log('The "data to append" was appended to file!');
    //        });
    //    }
    //    else {
    //        //write the headers and newline
    //        console.log('New file, just writing headers');
    //        fs.writeFile('./FinalOutputFiles/error_' + FileName, toCsv, function (err, stat) {
    //            if (err) throw err;
    //            console.log('file saved');
    //        });
    //    }
    //    res.send({ status: 200, data: stat });
    //});

};
exports.getcolordiamond = function (req, res) {
    try {
        var dealerid = req.body.dealerid;
        var query = "select id,VendorDealerID, RetailerDealerID, CompanyName, CompanyCity, CompanyState, Companycountry, CompanyEmail, RequestedDate, ApprovedDate, IsDiamond, IsFancyDiamond, IsLabGrownDiamond, IsApproved from key_gemfind.VendorDiamondConnectedRetailers where vendordealerid='" + dealerid + "' and isapproved=0 ALLOW FILTERING;";
        client.execute(query, [], function (err, result) {
            if (err) {
                res.status(404).send({ msg: err });
                console.log(err);
            } else {
                //console.log(result.rows);
                res.send({ status: 200, data: result.rows });
            }
        });
    }
    catch (e) {
        console.log(e);
    }

};
exports.getlabiamond = function (req, res) {
    try {
        var dealerid = req.body.dealerid;
        var query = "select id,VendorDealerID, RetailerDealerID, CompanyName, CompanyCity, CompanyState, Companycountry, CompanyEmail, RequestedDate, ApprovedDate, IsDiamond, IsFancyDiamond, IsLabGrownDiamond, IsApproved from key_gemfind.VendorDiamondConnectedRetailers where vendordealerid='" + dealerid + "' and isapproved=0 ALLOW FILTERING;";
        client.execute(query, [], function (err, result) {
            if (err) {
                res.status(404).send({ msg: err });
                console.log(err);
            } else {
                //console.log(result.rows);
                res.send({ status: 200, data: result.rows });
            }
        });
    }
    catch (e) {
        console.log(e);
    }

};

exports.diamondDownload = function (req, res) {
    try {
        var input = req.body;
        client.execute("insert into key_gemfind.tblDiamondDownload (pk_id, dealerid, enabled, linkurl,password,type,usenewservice,username) values (now(), " + input.dealerid + ",1, '" + input.linkurl + "', '" + input.password + "','" + input.type + "',1,'" + input.username+"')", [], function (err, result) {
            if (err) {
                console.log('customers: save_edit err:', err);
                //res.status(404).send({ msg: err });
            } else {
                res.send({ status: 200, data: null });
            }
        });
    }
    catch (e) {
        console.log(e);
    }

};
exports.getAllDiamondExport = function (req, res) {
    try {
        var query;
        var dealerid = req.body.dealerid;

        if (req.body.diamondType === 'natural') {
            query = "select * from Diamonds where Dealerid='" + req.body.dealerid + "' and IsLabCreated != '1' and  fancycolormainbody = '' and fancycolorintensity = '' and fancycolorovertone = ''";
        }
        if (req.body.diamondType === 'colorDiamond') {
            query = "select * from Diamonds where Dealerid='" + req.body.dealerid + "' and (fancycolormainbody !='' or fancycolorintensity !='' or fancycolorovertone != '')";
        }
        if (req.body.diamondType === 'labDiamond') {
            query = "select * from Diamonds where Dealerid='" + req.body.dealerid + "' and IsLabCreated = '1'";
        }
        if (req.body.subject === 'ExportAll') {
            query = "select * from Diamonds where Dealerid='" + req.body.dealerid + "'";
        }
        
        
        redshift.connect(function (err) {
            redshift.query(query, { raw: true }, function (err, data) {
                    if (err) throw err;
                    else {

                        res.send({ status: 200, data: data });
                        // redshift.close();
                    }
            });
        });
    }
    catch (e) {
        console.log(e);
    }

};

exports.getAllRetailer = function (req, res) {
    try {
        var dealerid = req.body.dealerid;
        var query = "select * from key_gemfind.company_detail where account_type = 'Retailer' ALLOW FILTERING";
        client.execute(query, [], function (err, result) {
            if (err) {
                res.status(404).send({ msg: err });
                console.log(err);
            } else {
                //console.log(result.rows);
                res.send({ status: 200, data: result.rows });
            }
        });
    }
    catch (e) {
        console.log(e);
    }
};

exports.inviteretailerEmail = function (req, res) {
    var input = req.body;
        client.execute("UPDATE key_gemfind.company_detail set invite = true where pk_id = " + input.pk_id + "", [], function (err, result) {
            if (err) {
                res.status(404).send({ msg: err });
            } else {
                var mailOptions = {
                    from: 'gemfindtest@gmail.com',
                    cc: 'hardeep.yadav@rigelnetworks.com',
                    to: input.EmailId,
                    subject: input.Subject,
                    html: input.EmailFormate,
                };
                transporter.sendMail(mailOptions, function (error, info) {
                    if (error) {
                        console.log("1");
                        console.log(error);
                    } else {
                        console.log('Email sent: ' + info.response);
                        res.send({ status: 200, data: result.rows[0] });
                    }
                });

            };
        });
    };



exports.getDiamondDashboard = function (req, res) {
    try {
        var dealerid = req.body.dealerid;
        var queryTotalDiamond = "select COUNT(*) from Diamonds where Dealerid=" + req.body.dealerid;
        var queryConnectedRetailers = "select count(*)from key_gemfind.VendorDiamondConnectedRetailers where vendordealerid='720' ALLOW FILTERING";
        var queryLastUpdate = "select * from key_gemfind.company_detail where account_type = 'Retailer' ALLOW FILTERING";
        redshift.connect(function (err) {
            redshift.query(queryTotalDiamond, { raw: true }, function (err, result) {
            if (err) {
                res.status(404).send({ msg: err });
                console.log(err);
            } else {
                client.execute(queryConnectedRetailers, [], function (err, result2) {
                    client.execute(queryLastUpdate, [], function (err, result3) {
                    if (err) {
                        console.log('users: add err:', err);
                        res.status(404).send({ msg: err });
                    } else {
                        res.send({ status: 200, totalDiamond: result, connectedRetailers: result2, LastUpdates: '2019-07-02 05:53:11+0000' });
                    }
                    });
                });
            }
            });
        });
    }
    catch (e) {
        console.log(e);
    }
};

exports.getconversation = function (req, res) {
    try {
        var dealerid = req.body.dealerid;
        var query = "select * from key_gemfind.ConversationList where isdeleted = false and vendordealerid = " + dealerid +" ALLOW FILTERING";
        client.execute(query, [], function (err, result) {
            if (err) {
                res.status(404).send({ msg: err });
                console.log(err);
            } else {
                if (result.rows.length != 0) {
                    try {
                        var query = "select * from key_gemfind.ConversationList where isdeleted = false and retailerdealerid = " + dealerid + " ALLOW FILTERING";
                        client.execute(query, [], function (err, result) {
                            if (err) {
                                res.status(404).send({ msg: err });
                                console.log(err);
                            } else {
                                //console.log(result.rows);
                                res.send({ status: 200, data: result.rows });
                            }
                        });
                    }
                    catch (e) {
                        console.log(e);
                    }
                } 
            }
        });
    }
    catch (e) {
        console.log(e);
    }
};
exports.deleteconversation = function (req, res) {
    try {
        var input = req.body;
        var dealerid = req.body.dealerid;
        //var query = "delete from key_gemfind.ConversationList where conversationid =" + input.coversationId +"";
        var query = "update key_gemfind.ConversationList set isdeleted = true where conversationid =" + input.coversationId + "";
        client.execute(query, [], function (err, result) {
            if (err) {
                res.status(404).send({ msg: err });
                console.log(err);
            } else {
                //console.log(result.rows);
                res.send({ status: 200, data: result.rows });
            }
        });
    }
    catch (e) {
        console.log(e);
    }
};
exports.getconversationDetail = function (req, res) {
    try {
        var input = req.body;
        var dealerid = req.body.dealerid;
        var query = "select * from key_gemfind.ConversationList where conversationid =" + input.conversationId + "";
        var query2 = "update key_gemfind.ConversationList set isread = true where conversationid =" + input.conversationId + "";
        var query3 = "select * from key_gemfind.ConversationDetail where conversationid =" + input.conversationId + " ALLOW FILTERING ";
        client.execute(query, [], function (err, result) {
            client.execute(query2, [], function (err, Isread) {
                    client.execute(query3, [], function (err, conversation) {
                        if (err) {
                            res.status(404).send({ msg: err });
                            console.log(err);
                        } else {
                            //console.log(result.rows);
                            res.send({ status: 200, conversationDetail: result.rows, Isread: 'Status Set Is Read Successfully', Conversation: conversation.rows});
                        }
                    });
                });
            });
        }
    catch (e) {
        console.log(e);
    }
};
exports.insertConversation = function (req, res) {
    try {
        var input = req.body;
        var dealerid = req.body.dealerid;
        var query = "insert into key_gemfind.ConversationDetail (id,conversationid,dealerid,message,modifieddate) values (now()," + input.conversationid + "," + input.dealerid + ",'" + input.EmailFormate + "',toTimeStamp(now()))";
        var query2 = "update key_gemfind.ConversationList set isread = false where conversationid =" + input.conversationid + "";
        client.execute(query ,[], function (err, result) {
            client.execute(query2, [], function (err, result2) {
                if (err) {
                    res.status(404).send({ msg: err });
                    console.log(err);
                } else {
                    var mailOptions = {
                        from: 'gemfindtest@gmail.com',
                        cc: 'hardeep.yadav@rigelnetworks.com',
                        to: input.EmailId,
                        subject: input.Subject,
                        html: input.EmailFormate,
                    };
                    transporter.sendMail(mailOptions, function (error, info) {
                        if (error) {
                            console.log("1");
                            console.log(error);
                        } else {
                            console.log('Email sent: ' + info.response);
                            res.send({ status: 200, data: "Email Sent Successfully.." });
                        }
                    });
                    //res.send({ status: 200, data: result.rows });
                }
            });
        });
    }
    catch (e) {
        console.log(e);
    }
};
exports.insertRetailerGroupDiscount = function (req, res) {
    try {
        var input = req.body;
        var query;
        if (!input.pkId) {
            query = "insert into key_gemfind.RetailerGroupDiscount (pk_id,groupdiscountname,discountvalue,dealerid,startDate,endDate,allowadditionaldiscount) values (now(),'" + input.name + "'," + input.value + "," + input.dealerid + ",'" + input.startdate + "','" + input.enddate + "'," + input.aditionaldiscount + ")";
        }
        else if (input.pkId) {
            query = "update key_gemfind.RetailerGroupDiscount set groupdiscountname = '" + input.name + "',discountvalue = " + input.value + ",dealerid = " + input.dealerid + ",startDate = '" + input.startdate + "',endDate = '" + input.enddate + "',allowadditionaldiscount = " + input.aditionaldiscount + " where pk_id = " + input.pkId + "";
        }
        console.log(query);
        client.execute(query, [], function (err, result) {
            if (err) {
                res.status(404).send({ msg: err });
                console.log(err);
            } else {
                //console.log(result.rows);
                res.send({ status: 200, data: result.rows });
            }
        });
    }
    catch (e) {
        console.log(e);
    }
};
exports.getAllRetailerGroupDiscount = function (req, res) {
    try {
        var input = req.body;
        var query = "select * from key_gemfind.RetailerGroupDiscount where dealerid = " + input.dealerid + "  ALLOW FILTERING";
      
       
        
        client.execute(query, [], function (err, result) {
            if (err) {
                res.status(404).send({ msg: err });
                console.log(err);
            } else {
                //console.log(result.rows);
                res.send({ status: 200, data: result.rows });
            }
        });
    }
    catch (e) {
        console.log(e);
    }
};
exports.UploadFile = multipartMiddleware,function (req, res){
    try {
        var input = req.body;
        
    }
    catch (e) {
        console.log(e);
    }
};
exports.getRetailerGroupDiscountValues = function (req, res) {
    try {
        var dealerid = req.body.dealerid;
        console.log(dealerid);
        var query = "select * from key_gemfind.VendorDiamondConnectedRetailers where vendordealerid='" + dealerid + "' ALLOW FILTERING";
        var query2 = "select * from key_gemfind.RetailerGroupDiscount where dealerid=" + dealerid + " ALLOW FILTERING";
        console.log(query);
        client.execute(query, [], function (err, result) {
            client.execute(query2, [], function (err, result2) {
            if (err) {
                res.status(404).send({ msg: err });
                console.log(err);
            } else {
                //console.log(result.rows);
                res.send({ status: 200, data: result.rows, data2: result2.rows});
            }
            });
        });
    }
    catch (e) {
        console.log(e);
    }
};
exports.addRetailerGroupDiscount = function (req, res) {
    try {
        var query;
        var input = req.body;
        var dealerid = req.body.dealerid;
        console.log(dealerid);
        if (input.id) {
            query = "update key_gemfind.retailer_group_discount set dealerid =" + input.dealerid + ",groupid = " + input.group + ",retailerid =" + input.retailer + " where id =" + input.id;
        }
        else {
            query = "insert into key_gemfind.retailer_group_discount (id,dealerid,groupid,retailerid) values (now(), " + input.dealerid + "," + input.group + "," + input.retailer + ")";
        }
        
       
        console.log(query);
        client.execute(query, [], function (err, result) {
                if (err) {
                    res.status(404).send({ msg: err });
                    console.log(err);
                } else {
                    //console.log(result.rows);
                    res.send({ status: 200, data: result.rows});
                }
        });
    }
    catch (e) {
        console.log(e);
    }
};
exports.getRetailerGroupDiscountData = function (req, res) {
    let FinalArray = [];
    let AllTableData = [];
    try {
        var input = req.body;
        var retailerGroupdiscountQuery = "select * from  key_gemfind.retailer_group_discount where dealerid = " + input.dealerid + "  ALLOW FILTERING";
        var connectedRetailersQuery = "select * from key_gemfind.VendorDiamondConnectedRetailers where vendordealerid='" + input.dealerid + "' ALLOW FILTERING";
        var diamondGroupdiscountQuery = "select * from key_gemfind.RetailerGroupDiscount where dealerid=" + input.dealerid + " ALLOW FILTERING";
        client.execute(retailerGroupdiscountQuery, [], function (err, retailerGroupdiscount) {
            client.execute(connectedRetailersQuery, [], function (err, connectedRetailers) {
                client.execute(diamondGroupdiscountQuery, [], function (err, diamondGroupdiscount) {
            if (err) {
                res.status(404).send({ msg: err });
                console.log(err);
            } else {
                if (retailerGroupdiscount.rows) {
                    for (var i = 0; i < retailerGroupdiscount.rows.length; i++) {
                        var data = retailerGroupdiscount.rows[i];
                        var data2 = connectedRetailers.rows.filter(element => element.id.toString() === data.retailerid.toString());
                        var data3 = diamondGroupdiscount.rows.filter(element => element.pk_id.toString() === data.groupid.toString());

                        //retailerGroupdiscount.rows[i].comapnyName = data2[0].companyname;
                        //retailerGroupdiscount.rows[i].groupName = data3[0].groupdiscountname;

                        data.groupName = data3[0].groupdiscountname;
                        data.comapnyName = data2[0].companyname;
                        FinalArray.push(data);
                    }
                    res.send({ status: 200, data: FinalArray });
                }
            }
            });
            });
            });
    }
    catch (e) {
        console.log(e);
    }
};
exports.deleteRetailerGroupDiscountData = function (req, res) {
    try {
        var input = req.body;
        var query = "delete from key_gemfind.retailer_group_discount where id=" + input.id;

        console.log(query);
        client.execute(query, [], function (err, result) {
            if (err) {
                res.status(404).send({ msg: err });
                console.log(err);
            } else {
                //console.log(result.rows);
                res.send({ status: 200, data: result.rows });
            }
        });
    }
    catch (e) {
        console.log(e);
    }
};


//All Natural Diamond, Color And Lab






