﻿
const nodemailer = require("nodemailer");
var Redshift = require('node-redshift');
var cassandra = require('cassandra-driver');
var common = require("./common");
const multer = require('multer');
var csv = require('csv-parser');
var fs = require('fs');
///var json2csv = require('json2csv').parse;
const createCsvWriter = require('csv-writer').createObjectCsvWriter;
var contactPoints = ['127.0.0.1'];
var client = new cassandra.Client({ contactPoints: contactPoints, localDataCenter: 'datacenter1' });
client.connect(function (err, result) {
    console.log('user detail: cassandra connected');
});
var clientConfiguration = {
    user: "jewelcloudrs",
    database: "jewelcloud",
    password: "7pUHm2Qa9YsnFUV",
    port: 5439,
    host: "jewelcloud-rs.cvjykrynhxhb.us-east-1.redshift.amazonaws.com",///"jdbc:redshift://jewelcloud-rs.cvjykrynhxhb.us-east-1.redshift.amazonaws.com:5439/jewelcloud?ssl=true&sslfactory=com.amazon.redshift.ssl.NonValidatingFactory",
};
var redshift = new Redshift(clientConfiguration);

exports.addDealerUploadedJewelryColumns = function (req, res) {
    try {
        var input = req.body.columnList;
        var dealerid = req.body.dealerid;
        var ids = "";
        client.execute("select dealercolumnid from key_gemfind.DealerUploadJewelryColumn where dealerid='" + dealerid + "' ALLOW FILTERING;", function (err, result) {
            if (err) {
                console.log(err);
            } else {

                if (result.rows.length > 0) {
                    query2 = "";
                    for (var j = 0; j < result.rows.length; j++) {
                        query2 = "delete from key_gemfind.DealerUploadJewelryColumn where dealercolumnid = " + result.rows[j].dealercolumnid + "";
                        var ddd = common.queryCassandra(query2);
                        //client.execute("delete from key_gemfind.DealerUploadedColumn where dealerid='" + dealerid + "' and id = " + result.rows[j].id + " IF EXISIT", function (err, result) {
                        //    if (result) {
                        //        Console.log('successs');
                        //    }
                        //});
                        //ids += result.rows[j].id + ",";
                    }
                    client.execute(query, function (err, result) {
                        if (err) {
                            console.log(err);
                            //res.status(404).send({ msg: err });
                        } else {
                            console.log("done");
                            //res.send({ status: 200, data: null });
                        }
                    });
                    //ids = ids.replace(/,\s*$/, "");
                    //client.execute("delete from key_gemfind.DealerUploadedColumn where dealerid='" + dealerid + "' and id in (" + ids + ") IF EXISIT", function (err, result) {
                    //    if (result) {
                    //        Console.log('successs');
                    //    }
                    //});
                }
            }
        });


        var query = "";
        for (var i = 0; i < input.length; i++) {
            input[i] = input[i].toString().replace(/"/g, "", '');
            query = "insert into key_gemfind.DealerUploadJewelryColumn(id,ColumnName,Dealerid,status) values(now(),\'" + input[i] + "\',\'" + dealerid + "\',0);";
            var ddd = common.queryCassandra(query);
        }
        console.log(query);
        client.execute(query, function (err, result) {
            if (err) {
                console.log(err);
                res.status(404).send({ msg: err });
            } else {
                console.log("done");
                res.send({ status: 200, data: null });
            }
        });
    } catch (e) {
        console.log(e);
    }
}
exports.getDealerUploadJewelryColumn = function (req, res) {
    try {
        var dealerid = req.body.dealerid;
        console.log(req.body);
        client.execute("select * from key_gemfind.DealerUploadJewelryColumn where dealerid ='" + dealerid + "' and status=0 ALLOW FILTERING;", [], function (err, result) {
            if (err) {
                console.log(err);
                res.status(404).send({ msg: err });
            } else {
                res.send({ status: 200, data: result.rows });
            }
        });
    } catch (e) {
        console.log(e);
    }
};

exports.getJewelrymapping = function (req, res) {
    var diamondColumnRight;
    var diamondMappingColumn;
    try {
        client.execute("select * from key_gemfind.GemfindJewelryColumn", [], function (err, result) {
            if (err) {
                console.log('users: add err:', err);
                res.status(404).send({ msg: err });
            } else {
                if (result.rows.length !== 0) {
                    diamondColumnRight = result.rows;
                    try {
                        client.execute("select * from key_gemfind.dealerjewelrycolumns where dealerid='" + req.body.dealerid + "' ALLOW FILTERING;", [], function (err, result) {
                            if (err) {
                                console.log('users: add err:', err);
                                res.status(404).send({ msg: err });
                            } else {
                                console.log(result.rows);
                                if (result.rows.length !== 0) {
                                    diamondMappingColumn = result.rows;
                                    for (var i = 0; i < diamondColumnRight.length; i++) {
                                        var data = diamondColumnRight[i];

                                        for (var j = 0; j < diamondMappingColumn.length; j++) {
                                            var data2 = diamondMappingColumn[j];
                                            if (diamondColumnRight[i].id.toString() === data2.jewelcloudcolumnid.toString()) {
                                                diamondColumnRight[i].Mapptingvalue = data2.columnname;
                                                diamondColumnRight[i].MapptingvaluePk_Id = data2.id;
                                                diamondColumnRight[i].dealerid = data2.dealerid;
                                                diamondColumnRight[i].columnid = data2.columnid;
                                                break;
                                            }
                                            else {
                                                diamondColumnRight[i].Mapptingvalue = "";
                                            }
                                        }
                                    }
                                }
                                res.send({ status: 200, data: diamondColumnRight });
                            }
                        });
                    }
                    catch (e) {
                        console.log(e);
                    }
                }

            }
        });
    } catch (e) {
        console.log(e);
    }
};

exports.savemappedjewelryData = function (req, res) {
    try {
        console.log(req.body);
        //for (var i = 0; i < req.body.length; i++) {getDiamondmappingData
        var input = req.body;

        client.execute("insert into key_gemfind.dealerjewelrycolumns (id, columnname, dealerid, jewelcloudcolumnid,columnId) values (now(), '" + input.Mapptingvalue + "', '" + input.dealerid + "', " + input.id + ", " + input.columnid + ")", [], function (err, result) {
            if (err) {
                console.log('customers: save_edit err:', err);
                //res.status(404).send({ msg: err });
            } else {
            }
        });
        console.log("update key_gemfind.DealerUploadJewelryColumn set status = 1  WHERE id =" + input.columnid + " and dealerid='" + req.body.dealerid + "'");
        //client.execute("update key_gemfind.DealerUploadJewelryColumn set status = 1  WHERE id =" + input.columnid + " and dealerid='" + req.body.dealerid + "'", [], function (err, result) {
        client.execute("update key_gemfind.DealerUploadJewelryColumn set status = 1  WHERE id =" + input.columnid + "", [], function (err, result) {
            if (err) {
                console.log('customers: save_edit err:', err);
            } else {
            }
        });
        //}
        res.send({ status: 200, data: "Save Successfully.." });
    } catch (e) {
        console.log(e);
    }


};
exports.removeJewelryMapping = function (req, res) {
    var input = req;

    try {
        //client.execute("update key_gemfind.dealeruploadedcolumn set status = 0 WHERE id =" + req.body.columnid + " and dealerid='" + req.body.dealerid + "'", [], function (err, result) {
        client.execute("update key_gemfind.DealerUploadJewelryColumn set status = 0 WHERE id =" + req.body.columnid + "", [], function (err, result) {
            if (err) {
                console.log('users: add err:', err);
                //res.status(404).send({ msg: err });
            } else {
                console.log(result.rows);
                //res.send({ status: 200, data: result.rows });
            }
        });
        console.log("delete from key_gemfind.dealerjewelrycolumns where id =" + req.body.id);
        client.execute("delete from key_gemfind.dealerjewelrycolumns where id =" + req.body.id, [], function (err, result) {
            if (err) {
                console.log('users: add err:', err);
                ///res.status(404).send({ msg: err });
            } else {
                console.log(result.rows);
                res.send({ status: 200, data: result.rows });
            }
        });
    } catch (e) {
        console.log(e);
    }
};

exports.addJewelleryManageCollection = function (req, res) {
    // redshift.connect
    console.log(req.body);
    try {
        console.log(req.body);
        var input = req.body;
        var query = "insert into JewelryCollection (DealerID,CollectionName,IsEnabled,Description,CollectionImage,DesginerID,CollectionCategory,DisplayOrder,BrandID,ModifiedDate ,CreatedDate)values(" + input.DealerID + ",'" + input.CollectionName + "'," + input.IsEnabled + ",'" + input.Description + "','" + input.CollectionName + '.jpg' + "'," + input.DesginerID + ",'" + input.CollectionCategory + "'," + input.DisplayOrder + "," + input.BrandID + ", GETDATE() , GETDATE() )";
        // var query = "insert into JewelryCollection (DealerID,CollectionName,IsEnabled,Description,CollectionImage,DesginerID,CollectionCategory,DisplayOrder,BrandID,ModifiedDate ,CreatedDate)values(" + input.DealerID + ",'" + input.CollectionName + "'," + input.IsEnabled + ",'" + input.Description + "','" + input.CollectionImage + "'," + input.DesginerID + ",'" + input.CollectionCategory + "'," + input.DisplayOrder + "," + input.BrandID + ", GETDATE() , GETDATE() )";
        redshift.connect(function (err) {
            redshift.query(query, { raw: true }, function (err, data) {
                if (err) {
                    console.log(err);
                }
                else {
                    res.send({ status: 200, data: "Insert Successfully" });
                }
            });
        });

    } catch (e) {
        console.log(e);
    }

};

exports.getAllJewelleryManageCollection = function (req, res) {
    var skip = req.body.skip;
    var take = req.body.take;
    var query;
    console.log(req.body);
    var input = req.body;
    try {
        console.log(req.body);
        query = "select * from JewelryCollection where DealerID=" + input.obj.DealerID + " ";
        if (req.body.obj.searchItem) {
            query = query + " and CollectionName= '" + input.obj.searchItem + "' ";
        }
        var count = 0;
        var query3 = query;
        query = query + " OFFSET " + skip + " LIMIT " + take;
        var query2 = query3.replace("*", "COUNT(*)");
        redshift.connect(function (err) {
            redshift.query(query, { raw: true }, function (err, data) {
                redshift.query(query2, { raw: true }, function (err, data2) {
                    if (err) {
                        console.log(err);
                    }
                    else {
                        res.send({ status: 200, data: data, data2 });
                        //if (data) {
                        //    for (var i = 0; i < data.length; i++) {
                        //        redshift.connect(function (err) {
                        //            var newquery = "select count(*) from jewelry where collectionid=" + data[i].collectionid;
                        //            redshift.query(newquery, { raw: true }, function (err, collectiocount) {
                        //                if (err) {
                        //                    console.log(err);
                        //                }
                        //                else {
                        //                    data[i].totalcount = collectiocount[0].count;
                        //                    count = i++;
                        //                    if (count <= data.length) {
                        //                        res.send({ status: 200, data: data });
                        //                    }

                        //                }
                        //            });
                        //        });
                        //    }

                        //}
                    }
                });
            });
        });



    } catch (e) {
        console.log(e);
    }


    //console.log(req.body);
    //try {
    //    console.log(req.body);
    //    var input = req.body;
    //    var query = "select * from JewelryCollection where DealerID=" + input.DealerID + " ";
    //    redshift.connect(function (err) {
    //        redshift.query(query, { raw: true }, function (err, data) {
    //            if (err) {
    //                console.log(err);
    //            }
    //            else {
    //                res.send({ status: 200, data: data });
    //            }
    //        });
    //    });

    //} catch (e) {
    //    console.log(e);
    //}

};


exports.getupdateJewelleryManageCollection = function (req, res) {
    // redshift.connect
    console.log(req.body);
    try {
        console.log(req.body);
        var input = req.body;
        var query = "select * from JewelryCollection where collectionid=" + input.forcollectionid + " ";
        redshift.connect(function (err) {
            redshift.query(query, { raw: true }, function (err, data) {
                if (err) {
                    console.log(err);
                }
                else {
                    res.send({ status: 200, data: data });
                }
            });
        });

    } catch (e) {
        console.log(e);
    }

};

exports.updateJewelleryManageCollection = function (req, res) {
    // redshift.connect
    console.log(req.body);
    try {
        console.log(req.body);
        var input = req.body;
        var query = "update JewelryCollection set CollectionName= '" + input.CollectionName + "',Description='" + input.Description + "',CollectionImage='" + input.CollectionName + '.jpg' + "'  where collectionid=" + input.collectionid + " ";
        /// var query = "update JewelryCollection set CollectionName= '" + input.CollectionName + "',Description='" + input.Description + "'  where collectionid=" + input.collectionid + " ";
        redshift.connect(function (err) {
            redshift.query(query, { raw: true }, function (err, data) {
                if (err) {
                    console.log(err);
                }
                else {
                    res.send({ status: 200, data: data });
                }
            });
        });

    } catch (e) {
        console.log(e);
    }

};


exports.deleteJewelleryManageCollection = function (req, res) {
    // redshift.connect
    console.log(req.body);
    try {
        console.log(req.body);
        var input = req.body;
        var query = "delete from JewelryCollection where collectionid=" + input.forcollectionid + " ";
        redshift.connect(function (err) {
            redshift.query(query, { raw: true }, function (err, data) {
                if (err) {
                    console.log(err);
                }
                else {
                    res.send({ status: 200, data: data });
                }
            });
        });

    } catch (e) {
        console.log(e);
    }

};

exports.addJewelryProduct = function (req, res) {
    console.log(req.body);
    try {
        console.log(req.body);
        var input = req.body;
        var query = "insert into Jewelry(DealerID,StyleNumber,DealerStockNumber,ProductName,ShortDescription,ProductDescription,DisplayOrder,StatusID,MetalTypeID,MetalColorID,WholeSalePrice,Terms,IsStockBalancing,RetailPriceCodeID,RetailPrice,IsCalculatedRetailPrice,MSRP,MSRP2,MSRPTypeID,IsCalculatedMSRP,ImagePath,VideoURL,AdditionalInformation,AdditionalInformation2,BrandName,GenderID,PrimaryDiamondShape,NumberOfPrimaryDiamond,PrimaryDiamondTotalWeight,PrimaryDiamondClarity,PrimaryDiamondColor,PrimaryDiamondSecondaryColor,PrimaryDiamondSaturation,PrimaryDiamondCertificateType,PrimaryDiamondCertificateNo,SecondaryDiamondShape,NumberOfSecondaryDiamonds,SecondaryDiamondTotalWeight,SecondaryDiamondClarity,SecondaryDiamondColor,SecondaryDiamondSecondaryColor,SecondaryDiamondSaturation,OtherDiamondInfo,OtherDiamondTotalWeight,TotalDiamondWeight,PrimaryGemstoneType,PrimaryGemstoneShape,NumberOfPrimaryGemstones,PrimaryGemstoneCaratWeight,PrimaryGemstoneDimensions,PrimaryGemstoneOrigin,PrimaryGemstoneQuality,SecondaryGemstoneType,SecondaryGemstoneShape,NumberOfSecondaryGemstones,SecondaryGemstoneCaratWeight,SecondaryGemstoneDimensions,SecondaryGemstoneOrigin,SecondaryGemstoneQuality,OtherGemstoneInfo,OtherGemstoneCaratWeight,OtherGemstoneQuality,TotalGemstoneWeight,Width_mm,Thickness_mm,Length_in,Weight_gm,FingerSize,FingerSizeMinRange,FingerSizeMaxRange,FingerSizeIncrement,GroupedProductSKUs,AllowableCenterStoneShape,AllowableCenterStoneSize,FlgISBlocked,Modified,Quantity,PriceType,DiscountLevelType1,DiscountLevelValue1,DiscountLevelType2,DiscountLevelValue2,RetailerDiscountType,RetailerDiscountValue,SelectedAttributes,CustomeAttributelabel,SecondaryMetalType,ProductType,ParentSKU,IsRingBuilder,Dimensions,HasImage,Qty1,Qty2,Qty3,Qty4,Qty5,DimensionUnitOfMeasure,ChainType,BackFinding,HasSideStones,ProgMetal,GemstoneType,NoOfGemstone,GemstoneShape,GemstoneCaratWeight,GemstoneQuality,GemstoneCarat,GemstoneColor,AllowableShapeName,AllowableMinSize,AllowableMaxSize,CustomField1Name,CustomField1,CustomField2Name,CustomField2,CustomField3Name,CustomField3,CustomField4Name,CustomField4,CustomField5Name,CustomField5,DesigenrID,CategoryID,SubCategoryID,CollectionID) values (" + input.dealerid + ",'" + input.stylenumber + "','" + input.DealerStockNumber + "','" + input.ProductName + "','" + input.ShortDescription + "','" + input.productdescription + "','" + input.DisplayOrder + "'," + input.StatusID + "," + input.MetalTypeID + "," + input.MetalColorID + "," + input.wholesaleprice + ",'" + input.Terms + "'," + input.IsStockBalancing + "," + input.RetailPriceCodeID + "," + input.retailprice + "," + input.IsCalculatedRetailPrice + "," + input.msrp + "," + input.MSRP2 + "," + input.MSRPTypeID + "," + input.IsCalculatedMSRP + ",'" + input.ImagePath + "', '" + input.videourl + "','" + input.AdditionalInformation + "','" + input.AdditionalInformation2 + "','" + input.brandname + "'," + input.GenderID + ",'" + input.PrimaryDiamondShape + "'," + input.NumberOfPrimaryDiamond + "," + input.PrimaryDiamondTotalWeight + ",'" + input.PrimaryDiamondClarity + "','" + input.PrimaryDiamondColor + "','" + input.PrimaryDiamondSecondaryColor + "','" + input.PrimaryDiamondSaturation + "','" + input.PrimaryDiamondCertificateType + "','" + input.PrimaryDiamondCertificateNo + "','" + input.SecondaryDiamondShape + "'," + input.NumberOfSecondaryDiamonds + "," + input.SecondaryDiamondTotalWeight + ",'" + input.SecondaryDiamondClarity + "','" + input.SecondaryDiamondColor + "','" + input.SecondaryDiamondSecondaryColor + "','" + input.SecondaryDiamondSaturation + "','" + input.OtherDiamondInfo + "'," + input.OtherDiamondTotalWeight + "," + input.TotalDiamondWeight + ",'" + input.PrimaryGemstoneType + "','" + input.PrimaryGemstoneShape + "'," + input.NumberOfPrimaryGemstones + "," + input.PrimaryGemstoneCaratWeight + ",'" + input.PrimaryGemstoneDimensions + "','" + input.PrimaryGemstoneOrigin + "','" + input.PrimaryGemstoneQuality + "','" + input.SecondaryGemstoneType + "','" + input.SecondaryGemstoneShape + "'," + input.NumberOfSecondaryGemstones + "," + input.SecondaryGemstoneCaratWeight + ",'" + input.SecondaryGemstoneDimensions + "','" + input.SecondaryGemstoneOrigin + "','" + input.SecondaryGemstoneQuality + "','" + input.OtherGemstoneInfo + "'," + input.OtherGemstoneCaratWeight + ",'" + input.OtherGemstoneQuality + "'," + input.TotalGemstoneWeight + "," + input.width + "," + input.thickness_mm + "," + input.Length_in + "," + input.weight + ",'" + input.FingerSize + "','" + input.FingerSizeMinRange + "','" + input.FingerSizeMaxRange + "','" + input.FingerSizeIncrement + "','" + input.groupedproductskus + "','" + input.AllowableCenterStoneShape + "','" + input.AllowableCenterStoneSize + "'," + input.FlgISBlocked + ",GETDATE()," + input.quantity + "," + input.PriceType + ",'" + input.DiscountLevelType1 + "','" + input.DiscountLevelValue1 + "','" + input.DiscountLevelType2 + "','" + input.DiscountLevelValue2 + "','" + input.RetailerDiscountType + "','" + input.RetailerDiscountValue + "','" + input.SelectedAttributes + "','" + input.CustomeAttributelabel + "','" + input.SecondaryMetalType + "'," + input.ProductType + ",'" + input.ParentSKU + "'," + input.IsRingBuilder + ",'" + input.dimensions + "'," + input.HasImage + "," + input.qty1 + "," + input.qty2 + "," + input.qty3 + "," + input.qty4 + "," + input.qty5 + ",'" + input.dimensionunitofmeasure + "','" + input.ChainType + "','" + input.backfinding + "'," + input.HasSideStones + ",'" + input.ProgMetal + "','" + input.GemstoneType + "'," + input.NoOfGemstone + ",'" + input.GemstoneShape + "'," + input.GemstoneCaratWeight + ",'" + input.GemstoneQuality + "'," + input.GemstoneCarat + ",'" + input.GemstoneColor + "','" + input.AllowableShapeName + "','" + input.AllowableMinSize + "','" + input.AllowableMaxSize + "','" + input.CustomField1Name + "','" + input.CustomField1 + "','" + input.CustomField2Name + "','" + input.CustomField2 + "','" + input.CustomField3Name + "','" + input.CustomField3 + "','" + input.CustomField4Name + "','" + input.CustomField4 + "','" + input.CustomField5Name + "','" + input.CustomField5 + "'," + input.DesigenrID + "," + input.CategoryID + "," + input.SubCategoryID + "," + input.CollectionID + ")";
        redshift.connect(function (err) {
            redshift.query(query, { raw: true }, function (err, data) {
                if (err) {
                    console.log(err);
                }
                else {
                    res.send({ status: 200, data: data });
                }
            });
        });

    } catch (e) {
        console.log(e);
    }

};

exports.allJewelryProduct = function (req, res) {
    // redshift.connect
    var skip = req.body.skip;
    var take = req.body.take;
    var query;
    console.log(req.body);
    try {
        console.log(req.body);
        var input = req.body.filter;
        if (input.flag === "Ring Builder") {

            query = "select * from Jewelry where IsRingBuilder = 1 and FlgISBlocked= 1 and DealerID=" + input.dealerid + "";
            if (req.body.filter.searchItem) {
                query = query + " and StyleNumber = '" + input.searchItem + "' ";
            }
        }
        else {
            query = "select * from Jewelry where IsRingBuilder = 0 and FlgISBlocked=1 and DealerID=" + input.dealerid + " ";
            //query = "select * from Jewelry where IsRingBuilder = 0 and FlgISBlocked= 1 ";
            if (req.body.filter.searchItem) {
                query = query + " and StyleNumber = '" + input.searchItem + "' ";
            }
        }


        if (req.body.filter.maxPrice) {
            var CategoryQuery = "categoryid = " + input.category + "";
            var MaterialColorQuery = "metalcolorid='" + input.metalcolor + "'";
            var MaterialTypeQuery = "metaltypeid='" + input.metaltype + "'";
            var GenderQuery = "genderid='" + input.gender + "'";
            var CollectionQuery = "collectionid='" + input.collection + "'";
            //var VendorQuery = "culetcondition='" + input.culetConditionStart + "'";
            var PriceQuery = "wholesaleprice BETWEEN " + input.minPrice + " AND  " + input.maxPrice + "";
            //var ImagesQuery = "culetcondition='" + input.culetConditionStart + "'";
            var ProductTypeQuery = "producttype='" + input.producttype + "'";

            if (input.category !== "") {
                query = query + (query.includes('where') ? ' and ' + CategoryQuery : 'where ' + CategoryQuery);
            }
            if (input.metalcolor !== "") {
                query = query + (query.includes('where') ? ' and ' + MaterialColorQuery : 'where ' + MaterialColorQuery);
            }
            if (input.metaltype !== "") {
                query = query + (query.includes('where') ? ' and ' + MaterialTypeQuery : 'where ' + MaterialTypeQuery);
            }
            if (input.collection !== "") {
                query = query + (query.includes('where') ? ' and ' + CollectionQuery : 'where ' + CollectionQuery);
            }
            if (input.minPrice !== "") {
                query = query + (query.includes('where') ? ' and ' + PriceQuery : 'where ' + PriceQuery);
            }
            if (input.producttype !== "") {
                query = query + (query.includes('where') ? ' and ' + ProductTypeQuery : 'where ' + ProductTypeQuery);
            }
            if (input.gender !== "") {
                query = query + (query.includes('where') ? ' and ' + GenderQuery : 'where ' + GenderQuery);
            }
        }
        query = query + " OFFSET " + skip + " LIMIT " + take;

        var query2 = query.replace("*", "COUNT(*)");


        redshift.connect(function (err) {
            redshift.query(query, { raw: true }, function (err, data) {
                redshift.query(query2, { raw: true }, function (err, data2) {
                    if (err) {
                        console.log(err);
                    }
                    else {
                        res.send({ status: 200, data: data, data2 });
                    }
                });
            });
        });

    } catch (e) {
        console.log(e);
    }

};

exports.allJewelryProductAlluser = function (req, res) {
    // redshift.connect
    var skip = req.body.skip;
    var take = req.body.take;
    var query;
    console.log(req.body);
    try {
        console.log(req.body);
        var input = req.body.filter;
        if (input.flag === "Ring Builder") {

            query = "select * from Jewelry where IsRingBuilder = 1 and FlgISBlocked= 1 ";
            if (req.body.filter.searchItem) {
                query = query + " and StyleNumber = '" + input.searchItem + "' ";
            }
        }
        else {
            if (req.body.filter.varifyFlag) {
                query = "select * from Jewelry where IsRingBuilder = 0 and FlgISBlocked=1 ";
            }
            query = "select * from Jewelry where IsRingBuilder = 0 and FlgISBlocked=1 ";
            //query = "select * from Jewelry where IsRingBuilder = 0 and FlgISBlocked= 1 ";
            if (req.body.filter.searchItem) {
                query = query + " and StyleNumber = '" + input.searchItem + "' ";
            }
        }


        if (req.body.filter.maxPrice) {
            var CategoryQuery = "categoryid = " + input.category + "";
            var MaterialColorQuery = "metalcolorid='" + input.metalcolor + "'";
            var MaterialTypeQuery = "metaltypeid='" + input.metaltype + "'";
            var GenderQuery = "genderid='" + input.gender + "'";
            var CollectionQuery = "collectionid='" + input.collection + "'";
            //var VendorQuery = "culetcondition='" + input.culetConditionStart + "'";
            var PriceQuery = "wholesaleprice BETWEEN " + input.minPrice + " AND  " + input.maxPrice + "";
            //var ImagesQuery = "culetcondition='" + input.culetConditionStart + "'";
            var ProductTypeQuery = "producttype='" + input.producttype + "'";

            if (input.category !== "") {
                query = query + (query.includes('where') ? ' and ' + CategoryQuery : 'where ' + CategoryQuery);
            }
            if (input.metalcolor !== "") {
                query = query + (query.includes('where') ? ' and ' + MaterialColorQuery : 'where ' + MaterialColorQuery);
            }
            if (input.metaltype !== "") {
                query = query + (query.includes('where') ? ' and ' + MaterialTypeQuery : 'where ' + MaterialTypeQuery);
            }
            if (input.collection !== "") {
                query = query + (query.includes('where') ? ' and ' + CollectionQuery : 'where ' + CollectionQuery);
            }
            if (input.minPrice !== "") {
                query = query + (query.includes('where') ? ' and ' + PriceQuery : 'where ' + PriceQuery);
            }
            if (input.producttype !== "") {
                query = query + (query.includes('where') ? ' and ' + ProductTypeQuery : 'where ' + ProductTypeQuery);
            }
            if (input.gender !== "") {
                query = query + (query.includes('where') ? ' and ' + GenderQuery : 'where ' + GenderQuery);
            }
        }
        query = query + " OFFSET " + skip + " LIMIT " + take;

        var query2 = query.replace("*", "COUNT(*)");


        redshift.connect(function (err) {
            redshift.query(query, { raw: true }, function (err, data) {
                redshift.query(query2, { raw: true }, function (err, data2) {
                    if (err) {
                        console.log(err);
                    }
                    else {
                        res.send({ status: 200, data: data, data2 });
                    }
                });
            });
        });

    } catch (e) {
        console.log(e);
    }

};

exports.updateJewelryProduct = function (req, res) {
    // redshift.connect
    console.log(req.body);
    try {
        console.log(req.body);
        var input = req.body;

        var query = "update Jewelry set StyleNumber='" + input.stylenumber + "',DealerStockNumber='" + input.DealerStockNumber + "',ProductName='" + input.ProductName + "',ShortDescription='" + input.ShortDescription + "',ProductDescription='" + input.productdescription + "',DisplayOrder='" + input.DisplayOrder + "',StatusID=" + input.StatusID + ",MetalTypeID=" + input.MetalTypeID + ",MetalColorID=" + input.MetalColorID + ",WholeSalePrice=" + input.wholesaleprice + ",Terms='" + input.Terms + "',IsStockBalancing=" + input.IsStockBalancing + ",RetailPriceCodeID=" + input.RetailPriceCodeID + ",RetailPrice=" + input.retailprice + ",IsCalculatedRetailPrice=" + input.IsCalculatedRetailPrice + ",MSRP=" + input.msrp + ",MSRP2=" + input.MSRP2 + ",MSRPTypeID=" + input.MSRPTypeID + ",IsCalculatedMSRP=" + input.IsCalculatedMSRP + ",ImagePath='" + input.ImagePath + "',VideoURL='" + input.videourl + "',AdditionalInformation='" + input.AdditionalInformation + "',AdditionalInformation2='" + input.AdditionalInformation2 + "',BrandName='" + input.brandname + "',GenderID=" + input.GenderID + ",PrimaryDiamondShape='" + input.PrimaryDiamondShape + "',NumberOfPrimaryDiamond=" + input.NumberOfPrimaryDiamond + ",PrimaryDiamondTotalWeight=" + input.PrimaryDiamondTotalWeight + ",PrimaryDiamondClarity='" + input.PrimaryDiamondClarity + "',PrimaryDiamondColor='" + input.PrimaryDiamondColor + "',PrimaryDiamondSecondaryColor='" + input.PrimaryDiamondSecondaryColor + "',PrimaryDiamondSaturation='" + input.PrimaryDiamondSecondaryColor + "',PrimaryDiamondCertificateType='" + input.PrimaryDiamondCertificateType + "',PrimaryDiamondCertificateNo='" + input.PrimaryDiamondCertificateNo + "',SecondaryDiamondShape='" + input.SecondaryDiamondShape + "',NumberOfSecondaryDiamonds=" + input.NumberOfSecondaryDiamonds + ",SecondaryDiamondTotalWeight=" + input.SecondaryDiamondTotalWeight + ",SecondaryDiamondClarity='" + input.SecondaryDiamondClarity + "',SecondaryDiamondColor='" + input.SecondaryDiamondColor + "',SecondaryDiamondSecondaryColor='" + input.SecondaryDiamondSecondaryColor + "',SecondaryDiamondSaturation='" + input.SecondaryDiamondSaturation + "',OtherDiamondInfo='" + input.OtherDiamondInfo + "',OtherDiamondTotalWeight=" + input.OtherDiamondTotalWeight + ",TotalDiamondWeight=" + input.TotalDiamondWeight + ",PrimaryGemstoneType='" + input.PrimaryGemstoneType + "',PrimaryGemstoneShape='" + input.PrimaryGemstoneShape + "',NumberOfPrimaryGemstones=" + input.NumberOfPrimaryGemstones + ",PrimaryGemstoneCaratWeight=" + input.PrimaryGemstoneCaratWeight + ",PrimaryGemstoneDimensions='" + input.PrimaryGemstoneDimensions + "',PrimaryGemstoneOrigin='" + input.PrimaryGemstoneOrigin + "',PrimaryGemstoneQuality='" + input.PrimaryGemstoneQuality + "',SecondaryGemstoneType='" + input.SecondaryGemstoneType + "',SecondaryGemstoneShape='" + input.SecondaryGemstoneShape + "',NumberOfSecondaryGemstones=" + input.NumberOfSecondaryGemstones + ",SecondaryGemstoneCaratWeight=" + input.SecondaryGemstoneCaratWeight + ",SecondaryGemstoneDimensions='" + input.SecondaryGemstoneDimensions + "',SecondaryGemstoneOrigin='" + input.SecondaryGemstoneOrigin + "',SecondaryGemstoneQuality='" + input.SecondaryGemstoneQuality + "',OtherGemstoneInfo='" + input.OtherGemstoneInfo + "',OtherGemstoneCaratWeight=" + input.OtherGemstoneCaratWeight + ",OtherGemstoneQuality='" + input.OtherGemstoneQuality + "',TotalGemstoneWeight=" + input.TotalGemstoneWeight + ",Width_mm=" + input.width + ",Thickness_mm=" + input.thickness_mm + ",Length_in=" + input.Length_in + ",Weight_gm=" + input.weight + ",FingerSize='" + input.FingerSize + "',FingerSizeMinRange='" + input.FingerSizeMinRange + "',FingerSizeMaxRange='" + input.FingerSizeMaxRange + "',FingerSizeIncrement='" + input.FingerSizeIncrement + "',GroupedProductSKUs='" + input.groupedproductskus + "',AllowableCenterStoneShape='" + input.AllowableCenterStoneShape + "',AllowableCenterStoneSize='" + input.AllowableCenterStoneSize + "',FlgISBlocked=" + input.FlgISBlocked + ",Modified=GETDATE(),Quantity=" + input.quantity + ",PriceType=" + input.PriceType + ",DiscountLevelType1='" + input.DiscountLevelType1 + "',DiscountLevelValue1='" + input.DiscountLevelValue1 + "',DiscountLevelType2='" + input.DiscountLevelType2 + "',DiscountLevelValue2='" + input.DiscountLevelValue2 + "',RetailerDiscountType='" + input.RetailerDiscountType + "',RetailerDiscountValue='" + input.RetailerDiscountValue + "',SelectedAttributes='" + input.SelectedAttributes + "',CustomeAttributelabel='" + input.CustomeAttributelabel + "',SecondaryMetalType='" + input.SecondaryMetalType + "',ProductType=" + input.ProductType + ",ParentSKU='" + input.ParentSKU + "',IsRingBuilder=" + input.IsRingBuilder + ",Dimensions='" + input.dimensions + "',HasImage=" + input.HasImage + ",Qty1=" + input.qty1 + ",Qty2=" + input.qty2 + ",Qty3=" + input.qty3 + ",Qty4=" + input.qty4 + ",Qty5=" + input.qty5 + ",DimensionUnitOfMeasure='" + input.dimensionunitofmeasure + "',ChainType='" + input.ChainType + "',BackFinding='" + input.backfinding + "',HasSideStones=" + input.HasSideStones + ",ProgMetal='" + input.ProgMetal + "',GemstoneType='" + input.GemstoneType + "',NoOfGemstone=" + input.NoOfGemstone + ",GemstoneShape='" + input.GemstoneShape + "',GemstoneCaratWeight=" + input.GemstoneCaratWeight + ",GemstoneQuality='" + input.GemstoneQuality + "',GemstoneCarat=" + input.GemstoneCarat + ",GemstoneColor='" + input.GemstoneColor + "',AllowableShapeName='" + input.AllowableShapeName + "',AllowableMinSize='" + input.AllowableMinSize + "',AllowableMaxSize='" + input.AllowableMaxSize + "',CustomField1Name='" + input.CustomField1Name + "',CustomField1='" + input.CustomField1 + "',CustomField2Name='" + input.CustomField2Name + "',CustomField2='" + input.CustomField2 + "',CustomField3Name='" + input.CustomField3Name + "',CustomField3='" + input.CustomField3 + "',CustomField4Name='" + input.CustomField4Name + "',CustomField4='" + input.CustomField4 + "',CustomField5Name='" + input.CustomField5Name + "',CustomField5='" + input.CustomField5 + "',DesigenrID=" + input.DesigenrID + ",CategoryID=" + input.CategoryID + ",SubCategoryID=" + input.SubCategoryID + ",CollectionID=" + input.CollectionID + " where GFInventoryID=" + input.GFInventoryID + " ";
        redshift.connect(function (err) {
            redshift.query(query, { raw: true }, function (err, data) {
                if (err) {
                    console.log(err);
                }
                else {
                    res.send({ status: 200, data: data });
                }
            });
        });

    } catch (e) {
        console.log(e);
    }

};

exports.uploadRetailerList = function (req, res) {
    try {
        //var dealerid = req.body.dealerid;

        console.log(req.body);
        var input = req.body.excelData;
        var dealerId = req.body.DealerID;

        for (var i = 0; i <= input.length; i++) {
            var query = "insert into key_gemfind.RetailerLocator(id,address,city,contactname,country,dealerid,email,enable,facebookappid,facebookappurl,phone,state,storename,vendorid,website,zipcode) values (now(),'" + input[i].Address + "','" + input[i].City + "', '" + input[i].ContactName + "','" + input[i].Country + "'," + dealerId + ",'" + input[i].Email + "','1','" + input[i].FaceBookAppID + "','" + input[i].FaceBookAppURL + "','" + input[i].Phone + "','" + input[i].State + "','" + input[i].StoreName + "',now(),'" + input[i].WebSite + "','" + input[i].Zipcode + "')";


            client.execute(query, function (err, result) {
                if (err) {
                    //console.log(err);
                    res.status(404).send({ msg: err });
                } else {
                    //    if (input.length == i){
                    //res.send({ status: 200, data: "Inserted Successfully" });
                    //}

                }
            });
        }
        res.send({ status: 200, data: "Inserted Successfully" });


    } catch (e) {
        console.log(e);
    }
};


exports.getAllRetailerList = function (req, res) {
    try {
        //var dealerid = req.body.dealerid;

        console.log(req.body);
        var input = req.body;


        var query = "select * from key_gemfind.RetailerLocator where dealerid=" + input.DealerID + " ALLOW FILTERING";


        client.execute(query, function (err, data) {
            if (err) {
                console.log(err);
                res.status(404).send({ msg: err });
            } else {

                res.send({ status: 200, data: data.rows });


            }
        });




    } catch (e) {
        console.log(e);
    }
};


exports.getAllRetailerListForUpdate = function (req, res) {
    try {
        //var dealerid = req.body.dealerid;

        console.log(req.body);
        var input = req.body;


        var query = "select * from key_gemfind.RetailerLocator where id=" + input.ID + " ALLOW FILTERING";


        client.execute(query, function (err, data) {
            if (err) {
                console.log(err);
                res.status(404).send({ msg: err });
            } else {

                res.send({ status: 200, data: data.rows });


            }
        });




    } catch (e) {
        console.log(e);
    }
};

exports.updateRetailerList = function (req, res) {
    try {
        //var dealerid = req.body.dealerid;

        console.log(req.body);
        var input = req.body;


        var query = "update key_gemfind.RetailerLocator set address='" + input.address + "',city='" + input.city + "',contactname='" + input.contactname + "',country='" + input.country + "',email='" + input.email + "',facebookappid='" + input.facebookappid + "',facebookappurl='" + input.facebookappurl + "',phone='" + input.phone + "',state='" + input.state + "',storename='" + input.storename + "',website='" + input.website + "',zipcode='" + input.zipcode + "'  where id=" + input.id + " ";


        client.execute(query, function (err, data) {
            if (err) {
                console.log(err);
                res.status(404).send({ msg: err });
            } else {

                res.send({ status: 200, data: data.rows });


            }
        });




    } catch (e) {
        console.log(e);
    }
};


exports.deleteRetailerLocator = function (req, res) {
    try {
        //var dealerid = req.body.dealerid;

        console.log(req.body);
        var input = req.body;


        var query = "delete from key_gemfind.RetailerLocator where id=" + input.id + " ";


        client.execute(query, function (err, data) {
            if (err) {
                console.log(err);
                res.status(404).send({ msg: err });
            } else {

                res.send({ status: 200, data: data.rows });


            }
        });




    } catch (e) {
        console.log(e);
    }
};


exports.allJewelleryMetalType = function (req, res) {
    // redshift.connect
    console.log(req.body);
    try {
        console.log(req.body);
        var input = req.body;
        var query = "select MetalType,MetalTypeID from jewelrymetaltype where IsActive=true";
        redshift.connect(function (err) {
            redshift.query(query, { raw: true }, function (err, data) {
                if (err) {
                    console.log(err);
                }
                else {
                    res.send({ status: 200, data: data });
                }
            });
        });

    } catch (e) {
        console.log(e);
    }

};



exports.allJewelleryMetalColor = function (req, res) {
    // redshift.connect
    console.log(req.body);
    try {
        console.log(req.body);
        var input = req.body;
        var query = "select MetalColorID,MetalColor from JewelryMetalColor";
        redshift.connect(function (err) {
            redshift.query(query, { raw: true }, function (err, data) {
                if (err) {
                    console.log(err);
                }
                else {
                    res.send({ status: 200, data: data });
                }
            });
        });

    } catch (e) {
        console.log(e);
    }

};

exports.allJewelleryCategory = function (req, res) {
    // redshift.connect
    console.log(req.body);
    try {
        console.log(req.body);
        var input = req.body;
        var query = "select CategoryName,JewelryCategoryID from JewelryCategory";
        redshift.connect(function (err) {
            redshift.query(query, { raw: true }, function (err, data) {
                if (err) {
                    console.log(err);
                }
                else {
                    res.send({ status: 200, data: data });
                }
            });
        });

    } catch (e) {
        console.log(e);
    }

};

exports.allJewelleryCollection = function (req, res) {
    // redshift.connect
    console.log(req.body);
    try {
        console.log(req.body);
        var input = req.body;
        var query = "select CollectionID,CollectionName from JewelryCollection where DealerID = " + input.DealerID + "";
        redshift.connect(function (err) {
            redshift.query(query, { raw: true }, function (err, data) {
                if (err) {
                    console.log(err);
                }
                else {
                    res.send({ status: 200, data: data });
                }
            });
        });

    } catch (e) {
        console.log(e);
    }

};


exports.addGroupList = function (req, res) {
    try {
        //var dealerid = req.body.dealerid;

        console.log(req.body);
        var input = req.body;


        var query = "insert into key_gemfind.discountlist (groupdiscountid,groupdiscountname,discountvalue,retailerid) values (now(),'" + input.groupdiscountname + "'," + input.discountvalue + "," + input.DealerID + ")";


        client.execute(query, function (err, data) {
            if (err) {
                console.log(err);
                res.status(404).send({ msg: err });
            } else {

                res.send({ status: 200, data: data.rows });
            }
        });
    } catch (e) {
        console.log(e);
    }
};

exports.allGroupList = function (req, res) {
    var skip = req.body.skip;
    var take = req.body.take;
    var query;
    console.log(req.body);
    var input = req.body;
    try {
        //var dealerid = req.body.dealerid;
        var query1 = "select * from key_gemfind.discountlist";
        var count = 0;
        var query3 = query1;
        query = query1 + " OFFSET" + skip + " LIMIT " + take;
        var query2 = query3.replace("*", "COUNT(*)");
        console.log(req.body);
        var input = req.body;

        client.execute(query2, function (err, data) {
            if (err) {
                console.log(err);
                res.status(404).send({ msg: err });
            } else {

                res.send({ status: 200, data: data.rows });


            }
        });




    } catch (e) {
        console.log(e);
    }
};

exports.getPerticularDiscountListForUpdate = function (req, res) {
    try {
        //var dealerid = req.body.dealerid;

        console.log(req.body);
        var input = req.body;


        var query = "select * from key_gemfind.discountlist where groupdiscountid=" + input.ID + " ALLOW FILTERING";


        client.execute(query, function (err, data) {
            if (err) {
                console.log(err);
                res.status(404).send({ msg: err });
            } else {

                res.send({ status: 200, data: data.rows });


            }
        });




    } catch (e) {
        console.log(e);
    }
};


exports.updateDiscountList = function (req, res) {
    try {
        //var dealerid = req.body.dealerid;

        console.log(req.body);
        var input = req.body;


        var query = "update key_gemfind.discountlist set groupdiscountname='" + input.groupdiscountname + "',discountvalue=" + input.discountvalue + "  where groupdiscountid=" + input.id + " ";


        client.execute(query, function (err, data) {
            if (err) {
                console.log(err);
                res.status(404).send({ msg: err });
            } else {

                res.send({ status: 200, data: data.rows });


            }
        });




    } catch (e) {
        console.log(e);
    }
};

exports.DeleteDiscountList = function (req, res) {
    try {
        //var dealerid = req.body.dealerid;

        console.log(req.body);
        var input = req.body;


        var query = "delete from key_gemfind.discountlist where groupdiscountid=" + input.id + " ";


        client.execute(query, function (err, data) {
            if (err) {
                console.log(err);
                res.status(404).send({ msg: err });
            } else {

                res.send({ status: 200, data: data.rows });


            }
        });




    } catch (e) {
        console.log(e);
    }
};


exports.addRingBuilder = function (req, res) {
    // redshift.connect
    console.log(req.body);
    try {
        console.log(req.body);
        var input = req.body;
        var query = "insert into Jewelry(DealerID,StyleNumber,DealerStockNumber,ProductName,ShortDescription,ProductDescription,DisplayOrder,StatusID,MetalTypeID,MetalColorID,WholeSalePrice,Terms,IsStockBalancing,RetailPriceCodeID,RetailPrice,IsCalculatedRetailPrice,MSRP,MSRP2,MSRPTypeID,IsCalculatedMSRP,ImagePath,VideoURL,AdditionalInformation,AdditionalInformation2,BrandName,GenderID,PrimaryDiamondShape,NumberOfPrimaryDiamond,PrimaryDiamondTotalWeight,PrimaryDiamondClarity,PrimaryDiamondColor,PrimaryDiamondSecondaryColor,PrimaryDiamondSaturation,PrimaryDiamondCertificateType,PrimaryDiamondCertificateNo,SecondaryDiamondShape,NumberOfSecondaryDiamonds,SecondaryDiamondTotalWeight,SecondaryDiamondClarity,SecondaryDiamondColor,SecondaryDiamondSecondaryColor,SecondaryDiamondSaturation,OtherDiamondInfo,OtherDiamondTotalWeight,TotalDiamondWeight,PrimaryGemstoneType,PrimaryGemstoneShape,NumberOfPrimaryGemstones,PrimaryGemstoneCaratWeight,PrimaryGemstoneDimensions,PrimaryGemstoneOrigin,PrimaryGemstoneQuality,SecondaryGemstoneType,SecondaryGemstoneShape,NumberOfSecondaryGemstones,SecondaryGemstoneCaratWeight,SecondaryGemstoneDimensions,SecondaryGemstoneOrigin,SecondaryGemstoneQuality,OtherGemstoneInfo,OtherGemstoneCaratWeight,OtherGemstoneQuality,TotalGemstoneWeight,Width_mm,Thickness_mm,Length_in,Weight_gm,FingerSize,FingerSizeMinRange,FingerSizeMaxRange,FingerSizeIncrement,GroupedProductSKUs,AllowableCenterStoneShape,AllowableCenterStoneSize,FlgISBlocked,Modified,Quantity,PriceType,DiscountLevelType1,DiscountLevelValue1,DiscountLevelType2,DiscountLevelValue2,RetailerDiscountType,RetailerDiscountValue,SelectedAttributes,CustomeAttributelabel,SecondaryMetalType,ProductType,ParentSKU,IsRingBuilder,Dimensions,HasImage,Qty1,Qty2,Qty3,Qty4,Qty5,DimensionUnitOfMeasure,ChainType,BackFinding,HasSideStones,ProgMetal,GemstoneType,NoOfGemstone,GemstoneShape,GemstoneCaratWeight,GemstoneQuality,GemstoneCarat,GemstoneColor,AllowableShapeName,AllowableMinSize,AllowableMaxSize,CustomField1Name,CustomField1,CustomField2Name,CustomField2,CustomField3Name,CustomField3,CustomField4Name,CustomField4,CustomField5Name,CustomField5,DesigenrID,CategoryID,SubCategoryID,CollectionID) values (" + input.dealerid + ",'" + input.stylenumber + "','" + input.DealerStockNumber + "','" + input.ProductName + "','" + input.ShortDescription + "','" + input.productdescription + "','" + input.DisplayOrder + "'," + input.StatusID + "," + input.MetalTypeID + "," + input.MetalColorID + "," + input.wholesaleprice + ",'" + input.Terms + "'," + input.IsStockBalancing + "," + input.RetailPriceCodeID + "," + input.retailprice + "," + input.IsCalculatedRetailPrice + "," + input.msrp + "," + input.MSRP2 + "," + input.MSRPTypeID + "," + input.IsCalculatedMSRP + ",'" + input.ImagePath + "', '" + input.videourl + "','" + input.AdditionalInformation + "','" + input.AdditionalInformation2 + "','" + input.brandname + "'," + input.GenderID + ",'" + input.PrimaryDiamondShape + "'," + input.NumberOfPrimaryDiamond + "," + input.PrimaryDiamondTotalWeight + ",'" + input.PrimaryDiamondClarity + "','" + input.PrimaryDiamondColor + "','" + input.PrimaryDiamondSecondaryColor + "','" + input.PrimaryDiamondSaturation + "','" + input.PrimaryDiamondCertificateType + "','" + input.PrimaryDiamondCertificateNo + "','" + input.SecondaryDiamondShape + "'," + input.NumberOfSecondaryDiamonds + "," + input.SecondaryDiamondTotalWeight + ",'" + input.SecondaryDiamondClarity + "','" + input.SecondaryDiamondColor + "','" + input.SecondaryDiamondSecondaryColor + "','" + input.SecondaryDiamondSaturation + "','" + input.OtherDiamondInfo + "'," + input.OtherDiamondTotalWeight + "," + input.TotalDiamondWeight + ",'" + input.PrimaryGemstoneType + "','" + input.PrimaryGemstoneShape + "'," + input.NumberOfPrimaryGemstones + "," + input.PrimaryGemstoneCaratWeight + ",'" + input.PrimaryGemstoneDimensions + "','" + input.PrimaryGemstoneOrigin + "','" + input.PrimaryGemstoneQuality + "','" + input.SecondaryGemstoneType + "','" + input.SecondaryGemstoneShape + "'," + input.NumberOfSecondaryGemstones + "," + input.SecondaryGemstoneCaratWeight + ",'" + input.SecondaryGemstoneDimensions + "','" + input.SecondaryGemstoneOrigin + "','" + input.SecondaryGemstoneQuality + "','" + input.OtherGemstoneInfo + "'," + input.OtherGemstoneCaratWeight + ",'" + input.OtherGemstoneQuality + "'," + input.TotalGemstoneWeight + "," + input.width + "," + input.thickness_mm + "," + input.Length_in + "," + input.weight + ",'" + input.FingerSize + "','" + input.FingerSizeMinRange + "','" + input.FingerSizeMaxRange + "','" + input.FingerSizeIncrement + "','" + input.groupedproductskus + "','" + input.AllowableCenterStoneShape + "','" + input.AllowableCenterStoneSize + "'," + input.FlgISBlocked + ",GETDATE()," + input.quantity + "," + input.PriceType + ",'" + input.DiscountLevelType1 + "','" + input.DiscountLevelValue1 + "','" + input.DiscountLevelType2 + "','" + input.DiscountLevelValue2 + "','" + input.RetailerDiscountType + "','" + input.RetailerDiscountValue + "','" + input.SelectedAttributes + "','" + input.CustomeAttributelabel + "','" + input.SecondaryMetalType + "'," + input.ProductType + ",'" + input.ParentSKU + "'," + input.IsRingBuilder + ",'" + input.dimensions + "'," + input.HasImage + "," + input.qty1 + "," + input.qty2 + "," + input.qty3 + "," + input.qty4 + "," + input.qty5 + ",'" + input.dimensionunitofmeasure + "','" + input.ChainType + "','" + input.backfinding + "'," + input.HasSideStones + ",'" + input.ProgMetal + "','" + input.GemstoneType + "'," + input.NoOfGemstone + ",'" + input.GemstoneShape + "'," + input.GemstoneCaratWeight + ",'" + input.GemstoneQuality + "'," + input.GemstoneCarat + ",'" + input.GemstoneColor + "','" + input.AllowableShapeName + "','" + input.AllowableMinSize + "','" + input.AllowableMaxSize + "','" + input.CustomField1Name + "','" + input.CustomField1 + "','" + input.CustomField2Name + "','" + input.CustomField2 + "','" + input.CustomField3Name + "','" + input.CustomField3 + "','" + input.CustomField4Name + "','" + input.CustomField4 + "','" + input.CustomField5Name + "','" + input.CustomField5 + "'," + input.DesigenrID + "," + input.CategoryID + "," + input.SubCategoryID + "," + input.CollectionID + ")";

        redshift.connect(function (err) {
            redshift.query(query, { raw: true }, function (err, data) {
                if (err) {
                    console.log(err);
                }
                else {
                    res.send({ status: 200, data: data });
                }
            });
        });

    } catch (e) {
        console.log(e);
    }

};

// deep
exports.getMyRetailer = function (req, res) {
    // redshift.connect
    console.log(req.body);
    try {
        console.log(req.body);
        var input = req.body;
        var query = "select * from key_gemfind.vendorjewelryconnectedretailers where vendordealerid  = '" + req.body.dealerid + "' and isJewelry = 1 and isaccess = 1 and isCollectionAccess = 1 and isapproved= 1 ALLOW FILTERING";

        client.execute(query, function (err, data) {
            if (err) {
                console.log(err);
                res.status(404).send({ msg: err });
            } else {

                res.send({ status: 200, data: data.rows });


            }
        });


    } catch (e) {
        console.log(e);
    }

};

exports.getAllRetailer = function (req, res) {
    // redshift.connect
    console.log(req.body);
    try {
        console.log(req.body);
        var input = req.body;
        var query = "select * from key_gemfind.company_detail where account_type = 'Retailer' ALLOW FILTERING";

        client.execute(query, function (err, data) {
            if (err) {
                console.log(err);
                res.status(404).send({ msg: err });
            } else {

                res.send({ status: 200, data: data.rows });


            }
        });


    } catch (e) {
        console.log(e);
    }

};



exports.getMyRingBuilderRetailerList = function (req, res) {
    // redshift.connect
    console.log(req.body);
    try {
        console.log(req.body);
        var input = req.body;
        var query = "select * from key_gemfind.vendorjewelryconnectedretailers where vendordealerid  = '" + req.body.dealerid + "' and isRingBuilder = 1 and isCollectionAccess = 1 and isaccess = 1 and isapproved= 1  ALLOW FILTERING";

        client.execute(query, function (err, data) {
            if (err) {
                console.log(err);
                res.status(404).send({ msg: err });
            } else {

                res.send({ status: 200, data: data.rows });


            }
        });


    } catch (e) {
        console.log(e);
    }

};


exports.getAllRingBuilderRetailerList = function (req, res) {
    // redshift.connect
    console.log(req.body);
    try {
        console.log(req.body);
        var input = req.body;
        var query = "select * from key_gemfind.company_detail where account_type = 'Retailer' ALLOW FILTERING";

        client.execute(query, function (err, data) {
            if (err) {
                console.log(err);
                res.status(404).send({ msg: err });
            } else {

                res.send({ status: 200, data: data.rows });


            }
        });


    } catch (e) {
        console.log(e);
    }

};

exports.changejewelleryRetailerAccess = function (req, res) {
    try {
        console.log(req.body);
        var id = req.body.id;
        var type = req.body.type;
        var status = req.body.status;
        var query = "";
        if (type === "isaccess")
            query = "update key_gemfind.VendorJewelryConnectedRetailers set isaccess=" + status + " where id =" + id;
        else if (type === "ishideprice")
            query = "update key_gemfind.VendorJewelryConnectedRetailers set ishideprice=" + status + " where id =" + id;
        else if (type === "isenforcemsrp")
            query = "update key_gemfind.VendorJewelryConnectedRetailers set isenforcemsrp=" + status + " where id =" + id;
        else if (type === "isautosync")
            query = "update key_gemfind.VendorJewelryConnectedRetailers set isautosync=" + status + " where id =" + id;
        else if (type === "isCollectionAccess")
            query = "update key_gemfind.VendorJewelryConnectedRetailers set isCollectionAccess=" + status + " where id =" + id;
        client.execute(query, [], function (err, result) {
            if (err) {
                res.status(404).send({ msg: err });
                console.log(err);
            } else {
                //console.log(result.rows);
                res.send({ status: 200, data: result.rows });
            }
        });
    }
    catch (e) {
        console.log(e);
    }
};

exports.changejewelleryRingBuilderRetailerAccess = function (req, res) {

};

exports.getjewelleryRingBuilderRetailerPendingRequest = function (req, res) {
    try {
        var dealerid = req.body.dealerid;
        var query = " select * from key_gemfind.VendorJewelryConnectedRetailers where vendordealerid='" + dealerid + "'and isRingBuilder= 1 and isapproved= 0  ALLOW FILTERING;";
        client.execute(query, [], function (err, result) {
            if (err) {
                res.status(404).send({ msg: err });
                console.log(err);
            } else {
                //console.log(result.rows);
                res.send({ status: 200, data: result.rows });
            }
        });
    }
    catch (e) {
        console.log(e);
    }

};

exports.getjewelleryRetailerPendingRequest = function (req, res) {
    try {
        var dealerid = req.body.dealerid;
        var query = "select * from key_gemfind.VendorJewelryConnectedRetailers where vendordealerid='" + dealerid + "'and isJewelry= 1 and isapproved= 0  ALLOW FILTERING;";
        client.execute(query, [], function (err, result) {
            if (err) {
                res.status(404).send({ msg: err });
                console.log(err);
            } else {
                //console.log(result.rows);
                res.send({ status: 200, data: result.rows });
            }
        });
    }
    catch (e) {
        console.log(e);
    }

};

/*exports.rejectjewelleryRetailer = function (req, res) {
    try {
        var dealerid = req.body.dealerid;
        var query = "select * from key_gemfind.VendorJewelryConnectedRetailers where vendordealerid='"+ dealerid +"'and isJewelry= 1 and isapproved= 0  ALLOW FILTERING;";
        client.execute(query, [], function (err, result) {
            if (err) {
                res.status(404).send({ msg: err });
                console.log(err);
            } else {
                //console.log(result.rows);
                res.send({ status: 200, data: result.rows });
            }
        });
    }
    catch (e) {
        console.log(e);
    }

};
*/

exports.approvejewelleryRingBuilderRetailer = function (req, res) {
    try {
        console.log(req.body);
        var id = req.body.id;

        var query = "update key_gemfind.VendorJewelryConnectedRetailers set isapproved = 1 and isaccess = 1 and isCollectionAccess = 1 and isRingBuilder = 1  where id=" + id + ";";
        //console.log(query);
        client.execute(query, [], function (err, result) {
            if (err) {
                res.status(404).send({ msg: err });
            } else {
                console.log(result.rows);
                res.send({ status: 200, data: result.rows });
            }
        });
    }
    catch (e) {
        console.log(e);
    }
};
exports.rejectjewelleryRingBuilderRetailer = function (req, res) {
    try {
        console.log(req.body);
        var id = req.body.id;

        var query = "delete from key_gemfind.VendorJewelryConnectedRetailers where id=" + id;
        client.execute(query, [], function (err, result) {
            if (err) {
                res.status(404).send({ msg: err });
            } else {
                console.log(result.rows);
                res.send({ status: 200, data: result.rows });
            }
        });
    }
    catch (e) {
        console.log(e);
    }
};

exports.approvejewelleryRetailer = function (req, res) {
    try {
        console.log(req.body);
        var id = req.body.id;

        var query = "update key_gemfind.VendorJewelryConnectedRetailers set isapproved = 1 and isaccess = 1 and isCollectionAccess = 1 and isJewelry = 1  where id=" + id + ";";
        //console.log(query);
        client.execute(query, [], function (err, result) {
            if (err) {
                res.status(404).send({ msg: err });
            } else {
                console.log(result.rows);
                res.send({ status: 200, data: result.rows });
            }
        });
    }
    catch (e) {
        console.log(e);
    }
};
exports.rejectjewelleryRetailer = function (req, res) {
    try {
        console.log(req.body);
        var id = req.body.id;

        var query = "delete from key_gemfind.VendorDiamondConnectedRetailers where id=" + id;
        client.execute(query, [], function (err, result) {
            if (err) {
                res.status(404).send({ msg: err });
            } else {
                console.log(result.rows);
                res.send({ status: 200, data: result.rows });
            }
        });
    }
    catch (e) {
        console.log(e);
    }
};


//end------------------------------------------

//Aniket Start 15/11/2019
exports.getParticularforUpdateJewelryProduct = function (req, res) {
    // redshift.connect
    console.log(req.body);
    try {

        console.log(req.body);
        var input = req.body;

        var query = "select * from Jewelry where GFInventoryID=" + input.ID;


        redshift.connect(function (err) {
            redshift.query(query, { raw: true }, function (err, data) {
                if (err) {
                    console.log(err);
                }
                else {
                    res.send({ status: 200, data: data });
                }
            });
        });

    } catch (e) {
        console.log(e);
    }

};


exports.sendJewelryEmail = function (req, res) {
    var transporter = nodemailer.createTransport({
        service: 'gmail',
        auth: {
            user: 'gemfindtest@gmail.com',
            pass: 'Test@123'
        }
    });
    var input = req.body;
    try {
        client.execute("select * FROM key_gemfind.email_template where email_type='Jewelry' allow filtering", [], function (err, result, fields) {
            if (err) {
                console.log('users: add err:', err);
                //res.status(404).send({ msg: err });
            } else {
                //console.log(result.rows[0]);
                var data2 = result.rows[0].email_body;
                var finalMail = data2.replace(/#name#/g, input.name);
                finalMail = finalMail.replace(/#markup#/g, input.markup);
                ///var finalMail2 = finalMail1.replace(/#description#/g, input.message);
                //console.log(input.EmailDiamond);
                var DiamondTable = "<table  width='100%' cellspacing='0' cellpadding='2' style='border: 1 solid;'> ";
                DiamondTable += " <tr align='center' style='font-weight: bold;'> <td style='border: 1 solid;'>Retail Stock # </td> <td style='border: 1 solid;'>Category </td> <td style='border: 1 solid;'>Collection </td> <td style='border: 1 solid;'>Cost </td></tr > ";
                for (var i = 0; i < input.EmailDiamond.length; i++) {
                    DiamondTable += "<tr align='center'><td style='border: 1 solid;'>" + input.EmailDiamond[i].stylenumber + "</td><td style='border: 1 solid;'>" + input.EmailDiamond[i].categoryid + "</td><td style='border: 1 solid;'>" + input.EmailDiamond[i].collectionid + "</td><td style='border: 1 solid;'>" + input.EmailDiamond[i].retailprice + "</td></tr>";
                };
                DiamondTable += "</table>";
                input.message = input.message + "" + DiamondTable;
                //console.log(DiamondTable);
                finalMail = finalMail.replace(/#description#/g, input.message);

                var mailOptions = {
                    from: 'gemfindtest@gmail.com', // sender address
                    //cc: 'hardeep.yadav@rigelnetworks.com', // list of receivers
                    to: input.email, // list of receivers
                    subject: "Jewelry Send      ", // Subject line
                    html: finalMail,
                };
                transporter.sendMail(mailOptions, function (error, info) {
                    if (error) {
                        console.log("1");
                        console.log(error);
                    } else {
                        console.log('Email sent: ' + info.response);
                    }
                });
                res.send({ status: 200, data: result.rows });
            }
        });
    } catch (e) {

    }
};


exports.allRingBuilderProduct = function (req, res) {
    // redshift.connect
    console.log(req.body);
    try {
        console.log(req.body);
        var input = req.body;
        //var query = "select stylenumber,categoryid,collectionid,retailprice,imagepath from Jewelry";
        var query = "select * from Jewelry where IsRingBuilder = 1 and FlgISBlocked=1 ";


        redshift.connect(function (err) {
            redshift.query(query, { raw: true }, function (err, data) {
                if (err) {
                    console.log(err);
                }
                else {
                    res.send({ status: 200, data: data });
                }
            });
        });

    } catch (e) {
        console.log(e);
    }

};


exports.deleteJewelryProduct = function (req, res) {
    // redshift.connect
    console.log(req.body);
    try {
        console.log(req.body);
        var input = req.body;
        //var query = "select stylenumber,categoryid,collectionid,retailprice,imagepath from Jewelry";
        var query = "update Jewelry set FlgISBlocked=0 where gfinventoryid=" + input.gfid;


        redshift.connect(function (err) {
            redshift.query(query, { raw: true }, function (err, data) {
                if (err) {
                    console.log(err);
                }
                else {
                    res.send({ status: 200, data: data });
                }
            });
        });

    } catch (e) {
        console.log(e);
    }

};
// --- End

//------------------hardeep
exports.getjewelrydashboardCounts = function (req, res) {
    // redshift.connect
    console.log(req.body);
    try {
        var input = req.body;
        console.log(req.body);
        var queryTotalJewelry = "select count(*)  from  Jewelry where IsRingBuilder = 0 and FlgISBlocked=1 and DealerID=" + input.dealerid + "";
        var queryTotalRing = "select count(*) from  Jewelry where IsRingBuilder = 1 and FlgISBlocked=1 and DealerID=" + input.dealerid + "";

        redshift.connect(function (err) {
            redshift.query(queryTotalJewelry, { raw: true }, function (err, totalJewelry) {
                redshift.query(queryTotalRing, { raw: true }, function (err, totalRing) {
                    if (err) {
                        console.log(err);
                    }
                    else {
                        res.send({ status: 200, data: totalJewelry, totalRing });
                    }
                });
            });
        });

    } catch (e) {
        console.log(e);
    }

};
//-----------end
