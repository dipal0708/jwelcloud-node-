﻿'use strict';
var express = require('express');
var router = express.Router();
var cassandra = require('cassandra-driver');

/* GET users listing. */
router.get('/', function (req, res) {
    var contactPoints = ['127.0.0.1'];
    var client = new cassandra.Client({ contactPoints: contactPoints, localDataCenter: 'datacenter1' });
    res.send('Read cluster info'+ client);
    //res.send('respond with a resource');
});

module.exports = router;
