﻿var request = require("request");
var common = require("./common");
var emailTemplate = require('./SendEmail');
var Redshift = require('node-redshift');
var fs = require('fs'),
    xml2js = require('xml2js'),
    util = require('util');
var aws = require('aws-sdk');
const csv = require('csv-parser');
var watchr = require('watchr');
var cassandra = require('cassandra-driver');
var path = require('path');
var XLSX = require('xlsx');
var _this = this;
var cron = require('node-cron');
const bodyParser = require("body-parser");
var diamondProcess = require("./diamondProcess");

var clientConfiguration = {
    user: "jewelcloudrs",
    database: "jewelcloud",
    password: "7pUHm2Qa9YsnFUV",
    port: 5439,
    host: "jewelcloud-rs.cvjykrynhxhb.us-east-1.redshift.amazonaws.com",///"jdbc:redshift://jewelcloud-rs.cvjykrynhxhb.us-east-1.redshift.amazonaws.com:5439/jewelcloud?ssl=true&sslfactory=com.amazon.redshift.ssl.NonValidatingFactory",
};
var redshift = new Redshift(clientConfiguration);
// Import the watching library
//var ftpClient = require('ftp-client'), config = {
//    host: '10.1.1.111',
//    port: 21,
//    user: 'nayan',
//    password: 'Admin@1234'
//},options = {
//        logging: 'basic'
//    }, clientftp = new ftpClient(config, options);


aws.config.update({
    secretAccessKey: "AKIAJKUH4KR3N7EOCWRA",
    accessKeyId: "n0F5Z+DgYDeysatBvpwuj0DeKic4nZQPW8hL1fEJ",
});
var accId = 'AKIAJKUH4KR3N7EOCWRA';
var secId = 'n0F5Z+DgYDeysatBvpwuj0DeKic4nZQPW8hL1fEJ';
let outputPath = 'F:\\Nayan\\API_Jewelcloud\\ModifiedFiles\\', finalOutputPath = 'F:\\Nayan\\API_Jewelcloud\\FinalOutputFiles\\';
var emailTo = 'nayan.rana@rigelnetworks.com';
var contactPoints = ['127.0.0.1'];
var client = new cassandra.Client({ contactPoints: contactPoints, localDataCenter: 'datacenter1' });
// Define our watching parameters
var fullpath = 'F:/Nayan/API_Jewelcloud/uploads'; //'http://localhost:3000/uploads/720/';/// 'F:/upload/root/inventoryFile'; //
var fileHeader = []; var mappFile = [];
var registerTrans = 'http://localhost:8080/kettle/registerTrans/?xml=Y';
var prepareExec = 'http://localhost:8080/kettle/prepareExec/';
var startExec = 'http://localhost:8080/kettle/startExec/';
var transStatus = 'http://localhost:8080/kettle/transStatus/?name=File_Format';
var allStatus = 'http://localhost:8080/kettle/status/?xml=Y';
let uploadFileCount = 0;
//clientftp.connect(function () {
//    //console.log('Connected with ftp', clientftp);
//    ///fullpath = '/root/inventoryFile';   
//});
require('events').EventEmitter.defaultMaxListeners = 1000;

// Create the stalker for the path
var stalker = watchr.create(fullpath);

// Listen to the events for the stalker/watcher
// http://rawgit.com/bevry/watchr/master/docs/index.html#watcher
stalker.on('change', listener)
//stalker.on('log', console.log)

stalker.once('close', function (reason) {
    console.log('closed', fullpath, 'because', reason)
    stalker.removeAllListeners()  // as it is closed, no need for our change or log listeners any more
})

// Set the default configuration for the stalker/watcher
// http://rawgit.com/bevry/watchr/master/docs/index.html#Watcher%23setConfig
stalker.setConfig({
    stat: null,
    interval: 500,
    persistent: true,
    catchupDelay: 2000,
    preferredMethods: ['watch', 'watchFile'],
    followLinks: true,
    ignorePaths: false,
    ignoreHiddenFiles: false,
    ignoreCommonPatterns: true,
    ignoreCustomPatterns: null
})

// Start watching
stalker.watch(next)

function listener(changeType, fullpath, currentStat, previousStat) {
    switch (changeType) {
        case 'update':
            //updateFileDetail(fullpath, currentStat, previousStat, 'the file' + fullpath + 'was updated' + currentStat);
            insertFileDetail(fullpath, currentStat, previousStat, 'the file' + fullpath + 'was created' + currentStat)
            break;
        case 'create':
            insertFileDetail(fullpath, currentStat, previousStat, 'the file' + fullpath + 'was created' + currentStat)
            break;
        case 'delete':
            console.log('the file', fullpath, 'was deleted', previousStat);
            break;
    }
}
function next(err) {
    if (err) return console.log('watch failed on', fullpath, 'with error', err)
    console.log('watch successful on', fullpath)
}


var parser = new xml2js.Parser(),
    xmlBuilder = new xml2js.Builder({ headless: true });
var configFile = 'F:/Nayan/API_Jewelcloud/uploads/File_Format.ktr';
var xlsConfigFile = 'F:/Nayan/API_Jewelcloud/uploads/File_Format_xls.ktr';
var processDiamondConfigFile = 'F:/Nayan/API_Jewelcloud/uploads/Process_Diamonds.ktr';
var mappingConfigFile = 'F:/Nayan/API_Jewelcloud/uploads/Map-Shape-Clarity-Culet-Polish.ktr';

let Uuid = require('cassandra-driver').types.Uuid;
let diamid = Uuid.random();
let uploadFilesData = [];
function insertFileDetail(fullpath, cStat, pState, log) {
    diamid = Uuid.random();
    var ext = path.basename(fullpath).split('.')[1];
    var dir = path.dirname(fullpath);
    var cust = dir.toString().split('\\');
    var custId = cust[cust.length - 1];
    var readFields = [];
    var outFields = [];
    var formulaFields = [];
    var changeColumnFields = [];
    var filePath = 'http://localhost:3000/uploads/720/' + path.basename(fullpath);
    //readFields.push(fullpath);
    // code to read file 
    var workbook = XLSX.readFile(fullpath);
    var first_sheet_name = workbook.SheetNames[0];
    var first_worksheet = workbook.Sheets[first_sheet_name];
    var data = XLSX.utils.sheet_to_json(first_worksheet, { header: 1 });
    // -- end -----------

    console.log('file process start.', readFields);
    if (ext.toLowerCase() === 'xls' || ext.toLowerCase() === 'xlsx' || ext.toLowerCase() === 'csv') {
        try {

            var querySelect = "select * from key_gemfind.diamondFileUpload where companyId='" + custId + "' and file_name='" + path.basename(fullpath) + "' allow filtering";
            console.log(querySelect);
            client.execute(querySelect, [], function (err, result) {

                if (result.rows.length > 0) {
                    //var query = "update key_gemfind.diamondFileUpload set created_date='" + new Date().toJSON().slice(0, 10) + "', created_time=toTimeStamp(now()),status='pending',updated_date=toTimeStamp(now()) where pk_id=" + result.rows[0].pk_id;
                    //const res = common.queryCassandra(query);
                } else {
                    var query = "INSERT INTO key_gemfind.diamondFileUpload (pk_id, created_date, created_time, file_name,file_path,file_type,file_extension,upload_type,status,companyId,updated_date,log,isfileupload) VALUES (" + diamid + ",'" + new Date().toJSON().slice(0, 10) + "',toTimeStamp(now()), '" + path.basename(fullpath) + "',  '" + fullpath + "', 'Replace All','" + path.basename(fullpath).split('.')[1] + "' , 'system', 'pending', '" + custId + "', toTimeStamp(now()),'" + log + "',false)";
                    const res = common.queryCassandra(query);
                }
            });
        } catch (err) {
            // handle errors here
        }

    }
}
//secondPentahoJob();
function secondPentahoJob(outFile, pk_id) {
    try {
        ///await Promise.all(outFileupload.map(async (outFile) => {
        ///let promise = new Promise((resolve, reject) => {
        console.log("Process diamond call", outFile);
        ///console.log("Process diamond call file detail", file);
        let id = 0;
        ///configFile = 'F:/Nayan/API_Jewelcloud/uploads/Process_Diamonds.ktr';
        fs.readFile(processDiamondConfigFile, function (err, data) {
            //console.log("Second Pentaho Job : ", JSON.stringify(diamid));
            //console.log("Second Pentaho Job file: ", outFile);
            parser.parseString(data, function (err, result) {
                finalOutputPath = 'F:\\Nayan\\API_Jewelcloud\\FinalOutputFiles\\';
                result.transformation.step[1].filename = outFile;/// "F:/Nayan/API_Jewelcloud/ModifiedFiles/GemFLooseDiamonds_0417PM.csv";
                //console.log("stpe 4 output", result.transformation.step[4]);
                result.transformation.step[5].file[0].name = finalOutputPath + path.basename(outFile).split('.')[0];  ///"F:/Nayan/API_Jewelcloud/ModifiedFiles/Diamond_GemFLooseDiamonds_0417PM.csv";
                result.transformation.step[3].file[0].name = finalOutputPath + "UploadReport1_" + path.basename(outFile).split('.')[0];  ///"F:/Nayan/API_Jewelcloud/ModifiedFiles/Diamond_GemFLooseDiamonds_0417PM.csv";

                //result.transformation.step[9].filename = mappingConfigFile;
                finalOutputPath = finalOutputPath + path.basename(outFile).split('.')[0] + ".csv";
                ///console.log("Diamond process output path ", finalOutputPath);
                var xml = xmlBuilder.buildObject(result);
                xml = "<transformation_configuration>" + xml + "<transformation_execution_configuration></transformation_execution_configuration></transformation_configuration>";

                var options = {
                    url: registerTrans,
                    auth: {
                        username: 'cluster',
                        password: 'cluster'
                    },
                    body: xml,
                    headers: { 'carte': 'config-xml' },
                };
                request.post(options, function (error, response, body) {
                    if (error) {
                        console.log("error :", error);
                    } else {
                        ///console.log("body registerTrans:", body);
                        parser.parseString(body, function (err, result) {
                            ///console.log("body registerTrans:", result);
                            id = result.webresult.id;
                        });
                        var optionsExe = {
                            url: prepareExec + '?name=File_Format&id=' + id + '&xml=y',
                            auth: {
                                username: 'cluster',
                                password: 'cluster'
                            }
                        };
                        request.get(optionsExe, function (error, response, body) {
                            //console.log("body :", body);
                            if (error) {
                                console.log("error :", error);
                            } else {
                                var optionsExe = {
                                    url: startExec + '?name=File_Format&id=' + id + '&xml=y',
                                    auth: {
                                        username: 'cluster',
                                        password: 'cluster'
                                    }
                                };
                                request.get(optionsExe, function (error, response, body) {
                                    ///console.log("body optionsExe:", body);
                                    if (error) {
                                        console.log("error :", error);
                                    } else {
                                        try {
                                            common.queryCassandra("update key_gemfind.diamondfileupload set pentaho_id='" + id + "',process_diamond_status='Finished' where pk_id=" + pk_id);
                                            // getFileStatusFromPentaho('', id, diamid);

                                        } catch (e) {
                                            console.log(e);
                                        }
                                    }
                                });
                            }

                        });
                    }
                });
            });
        });
        ///}));


        //let result = await promise;
    } catch (err) {
        // handle errors here
    }
}
///getFileStatusFromPentaho('', '170b926a-8302-45d8-b8f9-2e9127dd81d8')
function getFileStatusFromPentaho(id, pk_id, status, fileName) {
    try {
        ///let promise = new Promise((resolve, reject) => { 
        var optionsExe = {
            url: transStatus + '&xml=n&id=' + id,
            auth: {
                username: 'cluster',
                password: 'cluster'
            }
        };
        request.get(optionsExe, function (error, response, body) {
            if (error) {
                console.log("error :", error);
                return error.toString();
            } else {
                if (body.toString().includes('Finished (with errors)')) {
                    var obj = {
                        email: emailTo,
                        subject: 'File upload process in pentaho.',
                        body: body
                    };
                    emailTemplate.sendMail(obj);
                    common.queryCassandra("update key_gemfind.diamondfileupload set status='Rejected',file_format_status='Finished (with errors)' where pk_id=" + pk_id);
                } else {
                    //setTimeout(function () { uploadToS3(finalOutputPath, diamid); }, 1000);
                    if (status.toLowerCase() === "finished") {

                    }
                }
            }
        });

        ///});
        ///let result = await promise;
    } catch (err) {
        // handle errors here
    }
}

function updateFileDetail(fullpath, cStat, pState, log) {
    console.log('Yes i am here to update data: ');
    var ext = path.basename(fullpath).split('.')[1];
    var dir = path.dirname(fullpath);
    var cust = dir.toString().split('\\');
    var custId = cust[cust.length - 1];
    console.log('file path on update :' + dir);
    console.log('Customer id  :' + custId);
    if (ext.toLowerCase() == 'xls' || ext.toLowerCase() == 'xlsx' || ext.toLowerCase() == 'csv') {
        var pkid = '';
        client.execute("select pk_id from key_gemfind.diamondFileUpload where file_name='" + path.basename(fullpath) + "' allow filtering", [], function (err, result) {
            if (err) {
                console.log('file upload: select query line 295:', err);
            } else {
                console.log('Get pkid :' + result.rows[0].pk_id);
                pkid = result.rows[0].pk_id;
                client.execute("UPDATE key_gemfind.diamondFileUpload set updated_date='" + new Date().toJSON().slice(0, 10) + "',log='" + log + "',status='pending' where pk_id=" + pkid, [], function (err, result) {
                    if (err) {
                        console.log('file upload: update err:', err);
                    } else {
                        var workbook = XLSX.readFile(fullpath);
                        var first_sheet_name = workbook.SheetNames[0];
                        var first_worksheet = workbook.Sheets[first_sheet_name];
                        var data = XLSX.utils.sheet_to_json(first_worksheet, { header: 1 });
                        console.log(data[0]);
                        console.log('file upload: add succ:');
                        console.log('file upload: update succ:');
                    }
                });
            }
        });
    }
}
///getPendingDiamonUploadFiles();
//----------------------new code --------------start---------------------------
exports.getAlldiamond = function (req, res) {
    try {
        var query = "select  top 100 * from TempDiamonds";///"select count(*) from TempDiamonds"  /// 
        redshift.connect(function (err) {
            redshift.query(query, { raw: true }, function (err, data) {
                if (err)
                    console.log(err);
                else {

                    res.send({ status: 200, data: data });
                    // redshift.close();
                }
            });
        });
    } catch (e) {
        console.log(e);
    }
};

///// ------------ code to get pending diamond upload files ---------------------------///
exports.getPendingDiamonUploadFiles = function (req, res) {

    client.execute("select * from key_gemfind.diamondFileUpload", [], function (err, result) { /// where status='pending' allow filtering
        if (err) {
            console.log('file upload: select query line 415:', err);
            res.status(404).send({ msg: err });
        } else {
            res.send({ status: 200, data: result.rows });
            //console.log('Get pending data :' +JSON.stringify(result.rows[0]));
            ///pkid = result.rows[0].pk_id;
        }
    });
};



//getMappedData();

var lstmappedColumn = [];
var taskDiamonFileFormat = cron.schedule('*/5 * * * * *', () => {
    ///var taskDiamonFileFormat = function () {
    //var pendingFiles = "";
    //try {
    //    client.execute("select * from key_gemfind.diamondFileUpload where status='pending'  limit 1 allow filtering;", [], function (err, readFilesData) {  ///common.queryCassandra("select * from key_gemfind.diamondFileUpload where status='pending' allow filtering");
    //        if (readFilesData.rows.length > 0) {
    //            pendingFiles = readFilesData.rows;
    //            fileHeader = [];
    //            for (var i = 0; i < pendingFiles.length; i++) {

    //                var ext = path.basename(pendingFiles[i].file_path).split('.')[1];
    //                var dir = path.dirname(pendingFiles[i].file_path);
    //                var cust = dir.toString().split('\\');
    //                var custId = cust[cust.length - 1];
    //                var readFields = [];
    //                try {
    //                    var workbook = XLSX.readFile(pendingFiles[i].file_path);
    //                    var first_sheet_name = workbook.SheetNames[0];
    //                    var first_worksheet = workbook.Sheets[first_sheet_name];
    //                    var headerData = XLSX.utils.sheet_to_json(first_worksheet, { header: 1 });
    //                    fileHeader.push(headerData[0]);
    //                } catch (e) {
    //                    console.log(e);
    //                }


    //                client.execute("select * from key_gemfind.company_detail where dealerid=" + custId + " allow filtering", [], function (err, resultmailtemp) {
    //                    if (err) {
    //                        console.log('file upload: select query line 445', err);
    //                        //res.status(404).send({ msg: err });
    //                    } else {
    //                        dealerDetail = resultmailtemp.rows[0]

    //                    }
    //                });
    //                if (fileHeader[0] == undefined)
    //                    return;
    //                var dealerID = cust[cust.length - 1];
    //                ///const readFilesData = common.readFiles(ext.toLowerCase() === 'csv' ? configFile : xlsConfigFile);

    //                //------------ Read ktr file and rename file header --------------------------// 
    //                fs.readFile(ext.toLowerCase() === 'csv' ? configFile : xlsConfigFile, function (err, data) {
    //                    console.log("file read process ");
    //                    parser.parseString(data, function (err, result) {


    //                        var lstJewelColumn = [];
    //                        var lstdealerColumn = [];
    //                        lstmappedColumn = [];
    //                        var query = "select id,columnname from key_gemfind.jewelclouddiamondcoulmns allow filtering;";

    //                        client.execute(query, [], function (err, readData) {
    //                            lstJewelColumn = readData.rows;
    //                            var query2 = "select columnname,jewelcloudcolumnid from key_gemfind.dealerdiamondcolumns where dealerid='" + custId + "' allow filtering;";
    //                            client.execute(query2, [], function (err, data2) {
    //                                lstdealerColumn = data2.rows;
    //                                for (var i = 0; i < lstJewelColumn.length; i++) {
    //                                    for (var j = 0; j < lstdealerColumn.length; j++) {
    //                                        if (lstJewelColumn[i].id.toString() == lstdealerColumn[j].jewelcloudcolumnid.toString()) {
    //                                            lstmappedColumn.push({ jewelColumn: lstJewelColumn[i].columnname, mappedColumn: lstdealerColumn[j].columnname });
    //                                            //console.log(" Column name: ", lstdealerColumn[j].columnname);
    //                                        }
    //                                    }
    //                                }

    //                                //if (err) throw err;

    //                                ////console.log("file read process ", i);
    //                                outputPath = 'F:\\Nayan\\API_Jewelcloud\\ModifiedFiles\\';
    //                                // ---------------------- check cut field -----------------------
    //                                var lstmapCutIndex = lstmappedColumn.findIndex(function (v) {
    //                                    if (fileHeader[0].indexOf(v.mappedColumn) !== -1 && cutField.indexOf(v.jewelColumn.toUpperCase()) !== -1)
    //                                        return fileHeader[0].indexOf(v.mappedColumn) !== -1;
    //                                });
    //                                var fileHeadrCutIndex = fileHeader[0].findIndex(function (v) { return cutField.indexOf(v.toUpperCase()) !== -1; });
    //                                let checkCut = fileHeadrCutIndex == -1 ? lstmapCutIndex : fileHeadrCutIndex;
    //                                // ---------------------- check color field -----------------------
    //                                var lstmapColorIndex = lstmappedColumn.findIndex(function (v) {
    //                                    if (fileHeader[0].indexOf(v.mappedColumn) !== -1 && colorField.indexOf(v.jewelColumn.toUpperCase()) !== -1)
    //                                        return fileHeader[0].indexOf(v.mappedColumn) !== -1;
    //                                });
    //                                var fileHeadrColorIndex = fileHeader[0].findIndex(function (v) { return colorField.indexOf(v.toUpperCase()) !== -1; });
    //                                let checkColor = fileHeadrColorIndex == -1 ? lstmapColorIndex : fileHeadrColorIndex;  ///fileHeader[0].findIndex(function (v) { return colorField.indexOf(v.toUpperCase()) !== -1; });
    //                                // ----------------------------
    //                                // ---------------------- check clarity field -----------------------
    //                                var lstmapClarityIndex = lstmappedColumn.findIndex(function (v) {
    //                                    if (fileHeader[0].indexOf(v.mappedColumn) !== -1 && clarityField.indexOf(v.jewelColumn.toUpperCase()) !== -1)
    //                                        return fileHeader[0].indexOf(v.mappedColumn) !== -1;
    //                                });
    //                                var fileHeadrClarityIndex = fileHeader[0].findIndex(function (v) { return clarityField.indexOf(v.toUpperCase()) !== -1; });
    //                                let checkClarity = fileHeadrClarityIndex == -1 ? lstmapClarityIndex : fileHeadrClarityIndex;  ///fileHeader[0].findIndex(function (v) { return clarityField.indexOf(v.toUpperCase()) !== -1; });
    //                                // ---------------------- check size field -----------------------
    //                                var lstmapSizeIndex = lstmappedColumn.findIndex(function (v) {
    //                                    if (fileHeader[0].indexOf(v.mappedColumn) !== -1 && sizeField.indexOf(v.jewelColumn.toUpperCase()) !== -1)
    //                                        return fileHeader[0].indexOf(v.mappedColumn) !== -1;
    //                                });
    //                                var fileHeadrSizeIndex = fileHeader[0].findIndex(function (v) { return sizeField.indexOf(v.toUpperCase()) !== -1; });
    //                                let checkSize = fileHeadrSizeIndex == -1 ? lstmapSizeIndex : fileHeadrSizeIndex; //fileHeader[0].findIndex(function (v) { return sizeField.indexOf(v.toUpperCase()) !== -1; });
    //                                // ---------------------- check stock no field -----------------------
    //                                var lstmapStockNoIndex = lstmappedColumn.findIndex(function (v) {
    //                                    if (fileHeader[0].indexOf(v.mappedColumn) !== -1 && stockNumberField.indexOf(v.jewelColumn.toUpperCase()) !== -1)
    //                                        return fileHeader[0].indexOf(v.mappedColumn) !== -1;
    //                                });

    //                                var fileHeadrStockNoIndex = fileHeader[0].findIndex(function (v) { return stockNumberField.indexOf(v.toUpperCase()) !== -1; });
    //                                let checkStockNo = fileHeadrStockNoIndex == -1 ? lstmapStockNoIndex : fileHeadrStockNoIndex;  //fileHeader[0].findIndex(function (v) { return stockNumberField.indexOf(v.toUpperCase()) !== -1; });



    //                                if (checkCut < 0 || checkColor < 0 || checkClarity < 0 || checkSize < 0 || checkStockNo < 0) {
    //                                    var missing = 'Fields';
    //                                    if (checkCut < 0)
    //                                        missing = missing + " Cut,";
    //                                    if (checkClarity < 0)
    //                                        missing = missing + " Clarity, ";
    //                                    if (checkColor < 0)
    //                                        missing = missing + " Color, ";
    //                                    if (checkSize < 0)
    //                                        missing = missing + " Size, ";
    //                                    if (checkStockNo < 0)
    //                                        missing = missing + " Stock No";
    //                                    var FileName = path.basename(pendingFiles[0].file_path);
    //                                    var uploadedRecords = 0;
    //                                    var status = "Rejected";
    //                                    var DateTime = new Date().toISOString().replace(/T/, ' ').replace(/\..+/, '');
    //                                    var objReq = { "file_name": FileName, "numrecords": uploadedRecords, "status": status, "updated_date": DateTime };
    //                                    diamondProcess.getfileData(objReq);

    //                                    client.execute("select * from key_gemfind.email_template where email_type='FileUploadError' allow filtering", [], function (err, resultmailtemp) {
    //                                        if (err) {
    //                                            console.log('file upload: select template line 487', err);
    //                                            ///res.status(404).send({ msg: err });
    //                                        } else {
    //                                            emailBody = resultmailtemp.rows[0].email_body;
    //                                            emailBody = emailBody.replace('#name#', '');
    //                                            emailBody = emailBody.replace('#description#', missing + " is missing. </br> File header does not contain required fields : No diamond uploaded. <br> Cut(Shape), Size, Color, Clarity, CostPerCarat, Inventory Stock No  cannot be empty (null) otherwise line will be rejected.")
    //                                            var obj = {
    //                                                email: dealerDetail.email,
    //                                                subject: 'File format issue in ' + path.basename(pendingFiles[0].file_path),
    //                                                body: emailBody
    //                                            };
    //                                            emailTemplate.sendMail(obj);
    //                                            common.queryCassandra("update key_gemfind.diamondfileupload set status='Rejected' where pk_id=" + pendingFiles[0].pk_id);
    //                                        }
    //                                    });
    //                                    return;
    //                                }

    //                                result.transformation.step[4].filename = pendingFiles[0].file_path;
    //                                result.transformation.step[4].fields[0] = "";


    //                                var objFields = "", objOutPutFields = "", objFormula = "", objChangeColumn = "";
    //                                // --- code to generate Read CSV File fields dynamically. -------------------//
    //                                for (var j = 0; j < fileHeader[0].length; j++) {

    //                                    objFields = { field: { name: fileHeader[0][j], type: "String", format: "", currency: "$", decimal: ".", group: ",", length: "15", precision: "-1", trim_type: "none" } };

    //                                    readFields.push(objFields);
    //                                }

    //                                result.transformation.step[4].fields[0] = readFields;
    //                                //// -------------------- end -----------------------------///

    //                                // --- code to set output path of File. -------------------//

    //                                if (ext.toLowerCase() === 'csv') {
    //                                    result.transformation.step[5].file[0].name = outputPath + path.basename(pendingFiles[0].file_path).split('.')[0];
    //                                } else {
    //                                    result.transformation.step[4].file[0].name = outputPath + path.basename(pendingFiles[0].file_path).split('.')[0];
    //                                }

    //                                outputPath = outputPath + path.basename(pendingFiles[0].file_path).split('.')[0] + ".csv";
    //                                //console.log("output path before", outputPath);
    //                                //// -------------------- end -----------------------------///
    //                                if (result.transformation.step[3].formula[19].field_name[0] === 'DealerID') {
    //                                    //console.log("Dealer id is set here..", dealerID);
    //                                    result.transformation.step[3].formula[19].formula_string = [dealerID];
    //                                }
    //                                ///getMappedData();
    //                                var ind = 0;
    //                                var dealerCostRenameField = "";
    //                                var sizeRenameField = "";
    //                                var costpercaratRenameField = "";

    //                                for (var e = 0; e < result.transformation.step[0].fields[0].field.length; e++) {
    //                                    ///if (fileHeader[0][e]) {
    //                                    //cutField.indexOf(result.transformation.step[0].fields[0].field[e].name[0].toUpperCase()) !== -1 ||
    //                                    if (cutField.indexOf(result.transformation.step[0].fields[0].field[e].name[0].toUpperCase()) !== -1 || (lstmappedColumn.find(c => c.jewelColumn.toUpperCase() == result.transformation.step[0].fields[0].field[e].rename[0])) && cutField.indexOf(result.transformation.step[0].fields[0].field[e].name[0].toUpperCase()) !== -1) {
    //                                        ind = fileHeader[0].findIndex(function (v) { return cutField.indexOf(v.toUpperCase()) !== -1; })
    //                                        if (ind > 0) { result.transformation.step[0].fields[0].field[e].name = [fileHeader[0][ind]]; }
    //                                        else if (lstmappedColumn.find(c => c.jewelColumn.toUpperCase() == result.transformation.step[0].fields[0].field[e].rename[0])) {
    //                                            result.transformation.step[0].fields[0].field[e].name = [lstmappedColumn.find(c => c.jewelColumn.toUpperCase() == result.transformation.step[0].fields[0].field[e].rename[0]).mappedColumn];
    //                                        }
    //                                        else {
    //                                            result.transformation.step[3].formula.push({ field_name: [result.transformation.step[0].fields[0].field[e].name[0]], formula_string: ['""'], value_type: ["String"], value_length: ["15"], value_precision: ["2"], replace_field: [""] });
    //                                        }
    //                                    }
    //                                    else if (colorField.indexOf(result.transformation.step[0].fields[0].field[e].name[0].toUpperCase()) !== -1 || (lstmappedColumn.find(c => c.jewelColumn.toUpperCase() == result.transformation.step[0].fields[0].field[e].rename[0])) && colorField.indexOf(result.transformation.step[0].fields[0].field[e].name[0].toUpperCase()) !== -1) {
    //                                        ind = fileHeader[0].findIndex(function (v) { return colorField.indexOf(v.toUpperCase()) !== -1; })
    //                                        if (ind > 0) { result.transformation.step[0].fields[0].field[e].name = [fileHeader[0][ind]]; }
    //                                        else if (lstmappedColumn.find(c => c.jewelColumn.toUpperCase() == result.transformation.step[0].fields[0].field[e].rename[0])) {
    //                                            result.transformation.step[0].fields[0].field[e].name = [lstmappedColumn.find(c => c.jewelColumn.toUpperCase() == result.transformation.step[0].fields[0].field[e].rename[0]).mappedColumn];
    //                                        } else {
    //                                            result.transformation.step[3].formula.push({ field_name: [result.transformation.step[0].fields[0].field[e].name[0]], formula_string: ['""'], value_type: ["String"], value_length: ["15"], value_precision: ["2"], replace_field: [""] });
    //                                        }
    //                                    }
    //                                    else if (clarityField.indexOf(result.transformation.step[0].fields[0].field[e].name[0].toUpperCase()) !== -1 || (lstmappedColumn.find(c => c.jewelColumn.toUpperCase() == result.transformation.step[0].fields[0].field[e].rename[0])) && clarityField.indexOf(result.transformation.step[0].fields[0].field[e].name[0].toUpperCase()) !== -1) {
    //                                        ind = fileHeader[0].findIndex(function (v) { return clarityField.indexOf(v.toUpperCase()) !== -1; })
    //                                        if (ind > 0) { result.transformation.step[0].fields[0].field[e].name = [fileHeader[0][ind]]; }
    //                                        else if (lstmappedColumn.find(c => c.jewelColumn.toUpperCase() == result.transformation.step[0].fields[0].field[e].rename[0])) {
    //                                            result.transformation.step[0].fields[0].field[e].name = [lstmappedColumn.find(c => c.jewelColumn.toUpperCase() == result.transformation.step[0].fields[0].field[e].rename[0]).mappedColumn];
    //                                        }
    //                                        else {
    //                                            result.transformation.step[3].formula.push({ field_name: [result.transformation.step[0].fields[0].field[e].name[0]], formula_string: ['""'], value_type: ["String"], value_length: ["15"], value_precision: ["2"], replace_field: [""] });
    //                                        }
    //                                    }
    //                                    else if (sizeField.indexOf(result.transformation.step[0].fields[0].field[e].name[0].toUpperCase()) !== -1 || (lstmappedColumn.find(c => c.jewelColumn.toUpperCase() == result.transformation.step[0].fields[0].field[e].rename[0])) && sizeField.indexOf(result.transformation.step[0].fields[0].field[e].name[0].toUpperCase()) !== -1) {
    //                                        ind = fileHeader[0].findIndex(function (v) { return sizeField.indexOf(v.toUpperCase()) !== -1; })
    //                                        if (ind > 0) {
    //                                            sizeRenameField = [fileHeader[0][ind]];
    //                                            result.transformation.step[0].fields[0].field[e].name = [fileHeader[0][ind]];
    //                                            result.transformation.step[2].compare[0].condition[0].conditions[0].condition[0].leftvalue[0] = fileHeader[0][ind].toString();
    //                                            var form = [];
    //                                            form = result.transformation.step[3].formula[0].formula_string.toString().split('/');
    //                                            if (form[0] !== "0")
    //                                                result.transformation.step[3].formula[0].formula_string[0] = form[0] + "/[" + fileHeader[0][ind].toString() + "]"; ///[form[0]] + '/' + [fileHeader[0][ind].toString()];
    //                                        } else if (lstmappedColumn.find(c => c.jewelColumn.toUpperCase() == result.transformation.step[0].fields[0].field[e].rename[0])) {
    //                                            result.transformation.step[0].fields[0].field[e].name = [lstmappedColumn.find(c => c.jewelColumn.toUpperCase() == result.transformation.step[0].fields[0].field[e].rename[0]).mappedColumn];
    //                                            result.transformation.step[2].compare[0].condition[0].conditions[0].condition[0].leftvalue[0] = lstmappedColumn.find(c => c.jewelColumn.toUpperCase() == result.transformation.step[0].fields[0].field[e].rename[0]).mappedColumn.toString();
    //                                            var form = [];
    //                                            form = result.transformation.step[3].formula[0].formula_string.toString().split('/');
    //                                            if (form[0] !== "0")
    //                                                result.transformation.step[3].formula[0].formula_string[0] = form[0] + "/[" + lstmappedColumn.find(c => c.jewelColumn.toUpperCase() == result.transformation.step[0].fields[0].field[e].rename[0]).mappedColumn.toString() + "]";
    //                                        }
    //                                        else {
    //                                            result.transformation.step[3].formula.push({ field_name: [result.transformation.step[0].fields[0].field[e].name[0]], formula_string: ['""'], value_type: ["String"], value_length: ["15"], value_precision: ["2"], replace_field: [""] });
    //                                        }
    //                                    }
    //                                    else if (cutgradeField.indexOf(result.transformation.step[0].fields[0].field[e].name[0].toUpperCase()) !== -1 || (lstmappedColumn.find(c => c.jewelColumn.toUpperCase() == result.transformation.step[0].fields[0].field[e].rename[0])) && cutgradeField.indexOf(result.transformation.step[0].fields[0].field[e].name[0].toUpperCase()) !== -1) {
    //                                        ind = fileHeader[0].findIndex(function (v) { return cutgradeField.indexOf(v.toUpperCase()) !== -1; })
    //                                        if (ind > 0) { result.transformation.step[0].fields[0].field[e].name = [fileHeader[0][ind]]; } else if (lstmappedColumn.find(c => c.jewelColumn.toUpperCase() == result.transformation.step[0].fields[0].field[e].rename[0])) {
    //                                            result.transformation.step[0].fields[0].field[e].name = [lstmappedColumn.find(c => c.jewelColumn.toUpperCase() == result.transformation.step[0].fields[0].field[e].rename[0]).mappedColumn];
    //                                        } else {
    //                                            result.transformation.step[3].formula.push({ field_name: [result.transformation.step[0].fields[0].field[e].name[0]], formula_string: ['""'], value_type: ["String"], value_length: ["15"], value_precision: ["2"], replace_field: [""] });
    //                                        }
    //                                    }
    //                                    else if (totalPriceField.indexOf(result.transformation.step[0].fields[0].field[e].name[0].toUpperCase()) !== -1 || (lstmappedColumn.find(c => c.jewelColumn.toUpperCase() == result.transformation.step[0].fields[0].field[e].rename[0])) && totalPriceField.indexOf(result.transformation.step[0].fields[0].field[e].name[0].toUpperCase()) !== -1) {
    //                                        ind = fileHeader[0].findIndex(function (v) { return totalPriceField.indexOf(v.toUpperCase()) !== -1; })
    //                                        if (ind > 0) { result.transformation.step[0].fields[0].field[e].name = [fileHeader[0][ind]]; } else if (lstmappedColumn.find(c => c.jewelColumn.toUpperCase() == result.transformation.step[0].fields[0].field[e].rename[0])) {
    //                                            result.transformation.step[0].fields[0].field[e].name = [lstmappedColumn.find(c => c.jewelColumn.toUpperCase() == result.transformation.step[0].fields[0].field[e].rename[0]).mappedColumn];
    //                                        } else {
    //                                            result.transformation.step[3].formula.push({ field_name: [result.transformation.step[0].fields[0].field[e].name[0]], formula_string: ['""'], value_type: ["String"], value_length: ["15"], value_precision: ["2"], replace_field: [""] });
    //                                        }
    //                                    }
    //                                    else if (depthField.indexOf(result.transformation.step[0].fields[0].field[e].name[0].toUpperCase()) !== -1 || (lstmappedColumn.find(c => c.jewelColumn.toUpperCase() == result.transformation.step[0].fields[0].field[e].rename[0])) && depthField.indexOf(result.transformation.step[0].fields[0].field[e].name[0].toUpperCase()) !== -1) {
    //                                        ind = fileHeader[0].findIndex(function (v) { return depthField.indexOf(v.toUpperCase()) !== -1; })
    //                                        if (ind > 0) { result.transformation.step[0].fields[0].field[e].name = [fileHeader[0][ind]]; } else if (lstmappedColumn.find(c => c.jewelColumn.toUpperCase() == result.transformation.step[0].fields[0].field[e].rename[0])) {
    //                                            result.transformation.step[0].fields[0].field[e].name = [lstmappedColumn.find(c => c.jewelColumn.toUpperCase() == result.transformation.step[0].fields[0].field[e].rename[0]).mappedColumn];
    //                                        } else {
    //                                            result.transformation.step[3].formula.push({ field_name: [result.transformation.step[0].fields[0].field[e].name[0]], formula_string: ['""'], value_type: ["String"], value_length: ["15"], value_precision: ["2"], replace_field: [""] });
    //                                        }
    //                                    }
    //                                    else if (tableField.indexOf(result.transformation.step[0].fields[0].field[e].name[0].toUpperCase()) !== -1 || (lstmappedColumn.find(c => c.jewelColumn.toUpperCase() == result.transformation.step[0].fields[0].field[e].rename[0])) && tableField.indexOf(result.transformation.step[0].fields[0].field[e].name[0].toUpperCase()) !== -1) {
    //                                        ind = fileHeader[0].findIndex(function (v) { return tableField.indexOf(v.toUpperCase()) !== -1; })
    //                                        if (ind > 0) { result.transformation.step[0].fields[0].field[e].name = [fileHeader[0][ind]]; } else if (lstmappedColumn.find(c => c.jewelColumn.toUpperCase() == result.transformation.step[0].fields[0].field[e].rename[0])) {
    //                                            result.transformation.step[0].fields[0].field[e].name = [lstmappedColumn.find(c => c.jewelColumn.toUpperCase() == result.transformation.step[0].fields[0].field[e].rename[0]).mappedColumn];
    //                                        } else {
    //                                            result.transformation.step[3].formula.push({ field_name: [result.transformation.step[0].fields[0].field[e].name[0]], formula_string: ['""'], value_type: ["String"], value_length: ["15"], value_precision: ["2"], replace_field: [""] });
    //                                        }
    //                                    }
    //                                    //else if (sizeField.indexOf(result.transformation.step[0].fields[0].field[e].name[0].toUpperCase()) !== -1) {
    //                                    //    ind = fileHeader[0].findIndex(function (v) { return sizeField.indexOf(v.toUpperCase()) !== -1; })
    //                                    //    if (ind > 0) { result.transformation.step[0].fields[0].field[e].name = [fileHeader[0][ind]]; }
    //                                    //}                                        
    //                                    else if (stockNumberField.indexOf(result.transformation.step[0].fields[0].field[e].name[0].toUpperCase()) !== -1 || (lstmappedColumn.find(c => c.jewelColumn.toUpperCase() == result.transformation.step[0].fields[0].field[e].rename[0])) && stockNumberField.indexOf(result.transformation.step[0].fields[0].field[e].name[0].toUpperCase()) !== -1) {
    //                                        ind = fileHeader[0].findIndex(function (v) { return stockNumberField.indexOf(v.toUpperCase()) !== -1; })
    //                                        if (ind > 0) { result.transformation.step[0].fields[0].field[e].name = [fileHeader[0][ind]]; } else if (lstmappedColumn.find(c => c.jewelColumn.toUpperCase() == result.transformation.step[0].fields[0].field[e].rename[0])) {
    //                                            result.transformation.step[0].fields[0].field[e].name = [lstmappedColumn.find(c => c.jewelColumn.toUpperCase() == result.transformation.step[0].fields[0].field[e].rename[0]).mappedColumn];
    //                                        } else {
    //                                            result.transformation.step[3].formula.push({ field_name: [result.transformation.step[0].fields[0].field[e].name[0]], formula_string: ['""'], value_type: ["String"], value_length: ["15"], value_precision: ["2"], replace_field: [""] });
    //                                        }
    //                                    }
    //                                    else if (polishField.indexOf(result.transformation.step[0].fields[0].field[e].name[0].toUpperCase()) !== -1 || (lstmappedColumn.find(c => c.jewelColumn.toUpperCase() == result.transformation.step[0].fields[0].field[e].rename[0])) && polishField.indexOf(result.transformation.step[0].fields[0].field[e].name[0].toUpperCase()) !== -1) {
    //                                        ind = fileHeader[0].findIndex(function (v) { return polishField.indexOf(v.toUpperCase()) !== -1; })
    //                                        if (ind > 0) { result.transformation.step[0].fields[0].field[e].name = [fileHeader[0][ind]]; } else if (lstmappedColumn.find(c => c.jewelColumn.toUpperCase() == result.transformation.step[0].fields[0].field[e].rename[0])) {
    //                                            result.transformation.step[0].fields[0].field[e].name = [lstmappedColumn.find(c => c.jewelColumn.toUpperCase() == result.transformation.step[0].fields[0].field[e].rename[0]).mappedColumn];
    //                                        } else {
    //                                            result.transformation.step[3].formula.push({ field_name: [result.transformation.step[0].fields[0].field[e].name[0]], formula_string: ['""'], value_type: ["String"], value_length: ["15"], value_precision: ["2"], replace_field: [""] });
    //                                        }
    //                                    }
    //                                    else if (symmetryField.indexOf(result.transformation.step[0].fields[0].field[e].name[0].toUpperCase()) !== -1 || (lstmappedColumn.find(c => c.jewelColumn.toUpperCase() == result.transformation.step[0].fields[0].field[e].rename[0])) && symmetryField.indexOf(result.transformation.step[0].fields[0].field[e].name[0].toUpperCase()) !== -1) {
    //                                        ind = fileHeader[0].findIndex(function (v) { return symmetryField.indexOf(v.toUpperCase()) !== -1; })
    //                                        if (ind > 0) { result.transformation.step[0].fields[0].field[e].name = [fileHeader[0][ind]]; } else if (lstmappedColumn.find(c => c.jewelColumn.toUpperCase() == result.transformation.step[0].fields[0].field[e].rename[0])) {
    //                                            result.transformation.step[0].fields[0].field[e].name = [lstmappedColumn.find(c => c.jewelColumn.toUpperCase() == result.transformation.step[0].fields[0].field[e].rename[0]).mappedColumn];
    //                                        } else {
    //                                            result.transformation.step[3].formula.push({ field_name: [result.transformation.step[0].fields[0].field[e].name[0]], formula_string: ['""'], value_type: ["String"], value_length: ["15"], value_precision: ["2"], replace_field: [""] });
    //                                        }
    //                                    }
    //                                    else if (fluorescenceField.indexOf(result.transformation.step[0].fields[0].field[e].name[0].toUpperCase()) !== -1 || (lstmappedColumn.find(c => c.jewelColumn.toUpperCase() == result.transformation.step[0].fields[0].field[e].rename[0])) && fluorescenceField.indexOf(result.transformation.step[0].fields[0].field[e].name[0].toUpperCase()) !== -1) {
    //                                        ind = fileHeader[0].findIndex(function (v) { return fluorescenceField.indexOf(v.toUpperCase()) !== -1; })
    //                                        if (ind > 0) { result.transformation.step[0].fields[0].field[e].name = [fileHeader[0][ind]]; } else if (lstmappedColumn.find(c => c.jewelColumn.toUpperCase() == result.transformation.step[0].fields[0].field[e].rename[0])) {
    //                                            result.transformation.step[0].fields[0].field[e].name = [lstmappedColumn.find(c => c.jewelColumn.toUpperCase() == result.transformation.step[0].fields[0].field[e].rename[0]).mappedColumn];
    //                                        } else {
    //                                            result.transformation.step[3].formula.push({ field_name: [result.transformation.step[0].fields[0].field[e].name[0]], formula_string: ['""'], value_type: ["String"], value_length: ["15"], value_precision: ["2"], replace_field: [""] });
    //                                        }
    //                                    }
    //                                    else if (fluorescencecolorField.indexOf(result.transformation.step[0].fields[0].field[e].name[0].toUpperCase()) !== -1 || (lstmappedColumn.find(c => c.jewelColumn.toUpperCase() == result.transformation.step[0].fields[0].field[e].rename[0])) && fluorescencecolorField.indexOf(result.transformation.step[0].fields[0].field[e].name[0].toUpperCase()) !== -1) {
    //                                        ind = fileHeader[0].findIndex(function (v) { return fluorescencecolorField.indexOf(v.toUpperCase()) !== -1; })
    //                                        if (ind > 0) { result.transformation.step[0].fields[0].field[e].name = [fileHeader[0][ind]]; } else if (lstmappedColumn.find(c => c.jewelColumn.toUpperCase() == result.transformation.step[0].fields[0].field[e].rename[0])) {
    //                                            result.transformation.step[0].fields[0].field[e].name = [lstmappedColumn.find(c => c.jewelColumn.toUpperCase() == result.transformation.step[0].fields[0].field[e].rename[0]).mappedColumn];
    //                                        } else {
    //                                            result.transformation.step[3].formula.push({ field_name: [result.transformation.step[0].fields[0].field[e].name[0]], formula_string: ['""'], value_type: ["String"], value_length: ["15"], value_precision: ["2"], replace_field: [""] });
    //                                        }
    //                                    }
    //                                    else if (certificateField.indexOf(result.transformation.step[0].fields[0].field[e].name[0].toUpperCase()) !== -1 || (lstmappedColumn.find(c => c.jewelColumn.toUpperCase() == result.transformation.step[0].fields[0].field[e].rename[0])) && certificateField.indexOf(result.transformation.step[0].fields[0].field[e].name[0].toUpperCase()) !== -1) {
    //                                        ind = fileHeader[0].findIndex(function (v) { return certificateField.indexOf(v.toUpperCase()) !== -1; })
    //                                        if (ind > 0) { result.transformation.step[0].fields[0].field[e].name = [fileHeader[0][ind]]; } else if (lstmappedColumn.find(c => c.jewelColumn.toUpperCase() == result.transformation.step[0].fields[0].field[e].rename[0])) {
    //                                            result.transformation.step[0].fields[0].field[e].name = [lstmappedColumn.find(c => c.jewelColumn.toUpperCase() == result.transformation.step[0].fields[0].field[e].rename[0]).mappedColumn];
    //                                        } else {
    //                                            result.transformation.step[3].formula.push({ field_name: [result.transformation.step[0].fields[0].field[e].name[0]], formula_string: ['""'], value_type: ["String"], value_length: ["15"], value_precision: ["2"], replace_field: [""] });
    //                                        }
    //                                    }
    //                                    else if (certificatenoField.indexOf(result.transformation.step[0].fields[0].field[e].name[0].toUpperCase()) !== -1 || (lstmappedColumn.find(c => c.jewelColumn.toUpperCase() == result.transformation.step[0].fields[0].field[e].rename[0])) && certificatenoField.indexOf(result.transformation.step[0].fields[0].field[e].name[0].toUpperCase()) !== -1) {
    //                                        ind = fileHeader[0].findIndex(function (v) { return certificatenoField.indexOf(v.toUpperCase()) !== -1; })
    //                                        if (ind > 0) { result.transformation.step[0].fields[0].field[e].name = [fileHeader[0][ind]]; } else if (lstmappedColumn.find(c => c.jewelColumn.toUpperCase() == result.transformation.step[0].fields[0].field[e].rename[0])) {
    //                                            result.transformation.step[0].fields[0].field[e].name = [lstmappedColumn.find(c => c.jewelColumn.toUpperCase() == result.transformation.step[0].fields[0].field[e].rename[0]).mappedColumn];
    //                                        } else {
    //                                            result.transformation.step[3].formula.push({ field_name: [result.transformation.step[0].fields[0].field[e].name[0]], formula_string: ['""'], value_type: ["String"], value_length: ["15"], value_precision: ["2"], replace_field: [""] });
    //                                        }
    //                                    }
    //                                    else if (measurementsField.indexOf(result.transformation.step[0].fields[0].field[e].name[0].toUpperCase()) !== -1 || (lstmappedColumn.find(c => c.jewelColumn.toUpperCase() == result.transformation.step[0].fields[0].field[e].rename[0])) && measurementsField.indexOf(result.transformation.step[0].fields[0].field[e].name[0].toUpperCase()) !== -1) {
    //                                        ind = fileHeader[0].findIndex(function (v) { return measurementsField.indexOf(v.toUpperCase()) !== -1; })
    //                                        if (ind > 0) { result.transformation.step[0].fields[0].field[e].name = [fileHeader[0][ind]]; } else if (lstmappedColumn.find(c => c.jewelColumn.toUpperCase() == result.transformation.step[0].fields[0].field[e].rename[0])) {
    //                                            result.transformation.step[0].fields[0].field[e].name = [lstmappedColumn.find(c => c.jewelColumn.toUpperCase() == result.transformation.step[0].fields[0].field[e].rename[0]).mappedColumn];
    //                                        } else {
    //                                            result.transformation.step[3].formula.push({ field_name: [result.transformation.step[0].fields[0].field[e].name[0]], formula_string: ['""'], value_type: ["String"], value_length: ["15"], value_precision: ["2"], replace_field: [""] });
    //                                        }
    //                                    }
    //                                    else if (measlengthField.indexOf(result.transformation.step[0].fields[0].field[e].name[0].toUpperCase()) !== -1 || (lstmappedColumn.find(c => c.jewelColumn.toUpperCase() == result.transformation.step[0].fields[0].field[e].rename[0])) && measlengthField.indexOf(result.transformation.step[0].fields[0].field[e].name[0].toUpperCase()) !== -1) {
    //                                        ind = fileHeader[0].findIndex(function (v) { return measlengthField.indexOf(v.toUpperCase()) !== -1; })
    //                                        if (ind > 0) { result.transformation.step[0].fields[0].field[e].name = [fileHeader[0][ind]]; } else if (lstmappedColumn.find(c => c.jewelColumn.toUpperCase() == result.transformation.step[0].fields[0].field[e].rename[0])) {
    //                                            result.transformation.step[0].fields[0].field[e].name = [lstmappedColumn.find(c => c.jewelColumn.toUpperCase() == result.transformation.step[0].fields[0].field[e].rename[0]).mappedColumn];
    //                                        } else {
    //                                            result.transformation.step[3].formula.push({ field_name: [result.transformation.step[0].fields[0].field[e].name[0]], formula_string: ['""'], value_type: ["String"], value_length: ["15"], value_precision: ["2"], replace_field: [""] });
    //                                        }
    //                                    }
    //                                    else if (measheightField.indexOf(result.transformation.step[0].fields[0].field[e].name[0].toUpperCase()) !== -1 || (lstmappedColumn.find(c => c.jewelColumn.toUpperCase() == result.transformation.step[0].fields[0].field[e].rename[0])) && measheightField.indexOf(result.transformation.step[0].fields[0].field[e].name[0].toUpperCase()) !== -1) {
    //                                        ind = fileHeader[0].findIndex(function (v) { return measheightField.indexOf(v.toUpperCase()) !== -1; })
    //                                        if (ind > 0) { result.transformation.step[0].fields[0].field[e].name = [fileHeader[0][ind]]; } else if (lstmappedColumn.find(c => c.jewelColumn.toUpperCase() == result.transformation.step[0].fields[0].field[e].rename[0])) {
    //                                            result.transformation.step[0].fields[0].field[e].name = [lstmappedColumn.find(c => c.jewelColumn.toUpperCase() == result.transformation.step[0].fields[0].field[e].rename[0]).mappedColumn];
    //                                        } else {
    //                                            result.transformation.step[3].formula.push({ field_name: [result.transformation.step[0].fields[0].field[e].name[0]], formula_string: ['""'], value_type: ["String"], value_length: ["15"], value_precision: ["2"], replace_field: [""] });
    //                                        }
    //                                    }
    //                                    else if (measwidthField.indexOf(result.transformation.step[0].fields[0].field[e].name[0].toUpperCase()) !== -1 || (lstmappedColumn.find(c => c.jewelColumn.toUpperCase() == result.transformation.step[0].fields[0].field[e].rename[0])) && measwidthField.indexOf(result.transformation.step[0].fields[0].field[e].name[0].toUpperCase()) !== -1) {
    //                                        ind = fileHeader[0].findIndex(function (v) { return measwidthField.indexOf(v.toUpperCase()) !== -1; })
    //                                        if (ind > 0) { result.transformation.step[0].fields[0].field[e].name = [fileHeader[0][ind]]; } else if (lstmappedColumn.find(c => c.jewelColumn.toUpperCase() == result.transformation.step[0].fields[0].field[e].rename[0])) {
    //                                            result.transformation.step[0].fields[0].field[e].name = [lstmappedColumn.find(c => c.jewelColumn.toUpperCase() == result.transformation.step[0].fields[0].field[e].rename[0]).mappedColumn];
    //                                        } else {
    //                                            result.transformation.step[3].formula.push({ field_name: [result.transformation.step[0].fields[0].field[e].name[0]], formula_string: ['""'], value_type: ["String"], value_length: ["15"], value_precision: ["2"], replace_field: [""] });
    //                                        }
    //                                    }
    //                                    else if (girdleField.indexOf(result.transformation.step[0].fields[0].field[e].name[0].toUpperCase()) !== -1 || (lstmappedColumn.find(c => c.jewelColumn.toUpperCase() == result.transformation.step[0].fields[0].field[e].rename[0])) && girdleField.indexOf(result.transformation.step[0].fields[0].field[e].name[0].toUpperCase()) !== -1) {
    //                                        ind = fileHeader[0].findIndex(function (v) { return girdleField.indexOf(v.toUpperCase()) !== -1; })
    //                                        if (ind > 0) { result.transformation.step[0].fields[0].field[e].name = [fileHeader[0][ind]]; } else if (lstmappedColumn.find(c => c.jewelColumn.toUpperCase() == result.transformation.step[0].fields[0].field[e].rename[0])) {
    //                                            result.transformation.step[0].fields[0].field[e].name = [lstmappedColumn.find(c => c.jewelColumn.toUpperCase() == result.transformation.step[0].fields[0].field[e].rename[0]).mappedColumn];
    //                                        } else {
    //                                            result.transformation.step[3].formula.push({ field_name: [result.transformation.step[0].fields[0].field[e].name[0]], formula_string: ['""'], value_type: ["String"], value_length: ["15"], value_precision: ["2"], replace_field: [""] });
    //                                        }
    //                                    }
    //                                    else if (girdlethickField.indexOf(result.transformation.step[0].fields[0].field[e].name[0].toUpperCase()) !== -1 || (lstmappedColumn.find(c => c.jewelColumn.toUpperCase() == result.transformation.step[0].fields[0].field[e].rename[0])) && girdlethickField.indexOf(result.transformation.step[0].fields[0].field[e].name[0].toUpperCase()) !== -1) {
    //                                        ind = fileHeader[0].findIndex(function (v) { return girdlethickField.indexOf(v.toUpperCase()) !== -1; })
    //                                        if (ind > 0) { result.transformation.step[0].fields[0].field[e].name = [fileHeader[0][ind]]; } else if (lstmappedColumn.find(c => c.jewelColumn.toUpperCase() == result.transformation.step[0].fields[0].field[e].rename[0])) {
    //                                            result.transformation.step[0].fields[0].field[e].name = [lstmappedColumn.find(c => c.jewelColumn.toUpperCase() == result.transformation.step[0].fields[0].field[e].rename[0]).mappedColumn];
    //                                        } else {
    //                                            result.transformation.step[3].formula.push({ field_name: [result.transformation.step[0].fields[0].field[e].name[0]], formula_string: ['""'], value_type: ["String"], value_length: ["15"], value_precision: ["2"], replace_field: [""] });
    //                                        }
    //                                    }
    //                                    else if (girdlepercentField.indexOf(result.transformation.step[0].fields[0].field[e].name[0].toUpperCase()) !== -1 || (lstmappedColumn.find(c => c.jewelColumn.toUpperCase() == result.transformation.step[0].fields[0].field[e].rename[0])) && girdlepercentField.indexOf(result.transformation.step[0].fields[0].field[e].name[0].toUpperCase()) !== -1) {
    //                                        ind = fileHeader[0].findIndex(function (v) { return girdlepercentField.indexOf(v.toUpperCase()) !== -1; })
    //                                        if (ind > 0) { result.transformation.step[0].fields[0].field[e].name = [fileHeader[0][ind]]; } else if (lstmappedColumn.find(c => c.jewelColumn.toUpperCase() == result.transformation.step[0].fields[0].field[e].rename[0])) {
    //                                            result.transformation.step[0].fields[0].field[e].name = [lstmappedColumn.find(c => c.jewelColumn.toUpperCase() == result.transformation.step[0].fields[0].field[e].rename[0]).mappedColumn];
    //                                        } else {
    //                                            result.transformation.step[3].formula.push({ field_name: [result.transformation.step[0].fields[0].field[e].name[0]], formula_string: ['""'], value_type: ["String"], value_length: ["15"], value_precision: ["2"], replace_field: [""] });
    //                                        }
    //                                    }
    //                                    else if (pavilionField.indexOf(result.transformation.step[0].fields[0].field[e].name[0].toUpperCase()) !== -1 || (lstmappedColumn.find(c => c.jewelColumn.toUpperCase() == result.transformation.step[0].fields[0].field[e].rename[0])) && pavilionField.indexOf(result.transformation.step[0].fields[0].field[e].name[0].toUpperCase()) !== -1) {
    //                                        ind = fileHeader[0].findIndex(function (v) { return pavilionField.indexOf(v.toUpperCase()) !== -1; })
    //                                        if (ind > 0) { result.transformation.step[0].fields[0].field[e].name = [fileHeader[0][ind]]; } else if (lstmappedColumn.find(c => c.jewelColumn.toUpperCase() == result.transformation.step[0].fields[0].field[e].rename[0])) {
    //                                            result.transformation.step[0].fields[0].field[e].name = [lstmappedColumn.find(c => c.jewelColumn.toUpperCase() == result.transformation.step[0].fields[0].field[e].rename[0]).mappedColumn];
    //                                        } else {
    //                                            result.transformation.step[3].formula.push({ field_name: [result.transformation.step[0].fields[0].field[e].name[0]], formula_string: ['""'], value_type: ["String"], value_length: ["15"], value_precision: ["2"], replace_field: [""] });
    //                                        }
    //                                    }
    //                                    else if (pavillionheightField.indexOf(result.transformation.step[0].fields[0].field[e].name[0].toUpperCase()) !== -1 || (lstmappedColumn.find(c => c.jewelColumn.toUpperCase() == result.transformation.step[0].fields[0].field[e].rename[0])) && pavillionheightField.indexOf(result.transformation.step[0].fields[0].field[e].name[0].toUpperCase()) !== -1) {
    //                                        ind = fileHeader[0].findIndex(function (v) { return pavillionheightField.indexOf(v.toUpperCase()) !== -1; })
    //                                        if (ind > 0) { result.transformation.step[0].fields[0].field[e].name = [fileHeader[0][ind]]; } else if (lstmappedColumn.find(c => c.jewelColumn.toUpperCase() == result.transformation.step[0].fields[0].field[e].rename[0])) {
    //                                            result.transformation.step[0].fields[0].field[e].name = [lstmappedColumn.find(c => c.jewelColumn.toUpperCase() == result.transformation.step[0].fields[0].field[e].rename[0]).mappedColumn];
    //                                        } else {
    //                                            result.transformation.step[3].formula.push({ field_name: [result.transformation.step[0].fields[0].field[e].name[0]], formula_string: ['""'], value_type: ["String"], value_length: ["15"], value_precision: ["2"], replace_field: [""] });
    //                                        }
    //                                    }
    //                                    else if (pavilionangelField.indexOf(result.transformation.step[0].fields[0].field[e].name[0].toUpperCase()) !== -1 || (lstmappedColumn.find(c => c.jewelColumn.toUpperCase() == result.transformation.step[0].fields[0].field[e].rename[0])) && pavilionangelField.indexOf(result.transformation.step[0].fields[0].field[e].name[0].toUpperCase()) !== -1) {
    //                                        ind = fileHeader[0].findIndex(function (v) { return pavilionangelField.indexOf(v.toUpperCase()) !== -1; })
    //                                        if (ind > 0) { result.transformation.step[0].fields[0].field[e].name = [fileHeader[0][ind]]; } else if (lstmappedColumn.find(c => c.jewelColumn.toUpperCase() == result.transformation.step[0].fields[0].field[e].rename[0])) {
    //                                            result.transformation.step[0].fields[0].field[e].name = [lstmappedColumn.find(c => c.jewelColumn.toUpperCase() == result.transformation.step[0].fields[0].field[e].rename[0]).mappedColumn];
    //                                        } else {
    //                                            result.transformation.step[3].formula.push({ field_name: [result.transformation.step[0].fields[0].field[e].name[0]], formula_string: ['""'], value_type: ["String"], value_length: ["15"], value_precision: ["2"], replace_field: [""] });
    //                                        }
    //                                    }
    //                                    else if (crownangleField.indexOf(result.transformation.step[0].fields[0].field[e].name[0].toUpperCase()) !== -1 || (lstmappedColumn.find(c => c.jewelColumn.toUpperCase() == result.transformation.step[0].fields[0].field[e].rename[0])) && crownangleField.indexOf(result.transformation.step[0].fields[0].field[e].name[0].toUpperCase()) !== -1) {
    //                                        ind = fileHeader[0].findIndex(function (v) { return crownangleField.indexOf(v.toUpperCase()) !== -1; })
    //                                        if (ind > 0) { result.transformation.step[0].fields[0].field[e].name = [fileHeader[0][ind]]; } else if (lstmappedColumn.find(c => c.jewelColumn.toUpperCase() == result.transformation.step[0].fields[0].field[e].rename[0])) {
    //                                            result.transformation.step[0].fields[0].field[e].name = [lstmappedColumn.find(c => c.jewelColumn.toUpperCase() == result.transformation.step[0].fields[0].field[e].rename[0]).mappedColumn];
    //                                        } else {
    //                                            result.transformation.step[3].formula.push({ field_name: [result.transformation.step[0].fields[0].field[e].name[0]], formula_string: ['""'], value_type: ["String"], value_length: ["15"], value_precision: ["2"], replace_field: [""] });
    //                                        }
    //                                    }
    //                                    else if (crownheightField.indexOf(result.transformation.step[0].fields[0].field[e].name[0].toUpperCase()) !== -1 || (lstmappedColumn.find(c => c.jewelColumn.toUpperCase() == result.transformation.step[0].fields[0].field[e].rename[0])) && crownheightField.indexOf(result.transformation.step[0].fields[0].field[e].name[0].toUpperCase()) !== -1) {
    //                                        ind = fileHeader[0].findIndex(function (v) { return crownheightField.indexOf(v.toUpperCase()) !== -1; })
    //                                        if (ind > 0) { result.transformation.step[0].fields[0].field[e].name = [fileHeader[0][ind]]; } else if (lstmappedColumn.find(c => c.jewelColumn.toUpperCase() == result.transformation.step[0].fields[0].field[e].rename[0])) {
    //                                            result.transformation.step[0].fields[0].field[e].name = [lstmappedColumn.find(c => c.jewelColumn.toUpperCase() == result.transformation.step[0].fields[0].field[e].rename[0]).mappedColumn];
    //                                        } else {
    //                                            result.transformation.step[3].formula.push({ field_name: [result.transformation.step[0].fields[0].field[e].name[0]], formula_string: ['""'], value_type: ["String"], value_length: ["15"], value_precision: ["2"], replace_field: [""] });
    //                                        }
    //                                    }
    //                                    else if (crownField.indexOf(result.transformation.step[0].fields[0].field[e].name[0].toUpperCase()) !== -1 || (lstmappedColumn.find(c => c.jewelColumn.toUpperCase() == result.transformation.step[0].fields[0].field[e].rename[0])) && crownField.indexOf(result.transformation.step[0].fields[0].field[e].name[0].toUpperCase()) !== -1) {
    //                                        ind = fileHeader[0].findIndex(function (v) { return crownField.indexOf(v.toUpperCase()) !== -1; })
    //                                        if (ind > 0) { result.transformation.step[0].fields[0].field[e].name = [fileHeader[0][ind]]; } else if (lstmappedColumn.find(c => c.jewelColumn.toUpperCase() == result.transformation.step[0].fields[0].field[e].rename[0])) {
    //                                            result.transformation.step[0].fields[0].field[e].name = [lstmappedColumn.find(c => c.jewelColumn.toUpperCase() == result.transformation.step[0].fields[0].field[e].rename[0]).mappedColumn];
    //                                        } else {
    //                                            result.transformation.step[3].formula.push({ field_name: [result.transformation.step[0].fields[0].field[e].name[0]], formula_string: ['""'], value_type: ["String"], value_length: ["15"], value_precision: ["2"], replace_field: [""] });
    //                                        }
    //                                    }
    //                                    else if (culetField.indexOf(result.transformation.step[0].fields[0].field[e].name[0].toUpperCase()) !== -1 || (lstmappedColumn.find(c => c.jewelColumn.toUpperCase() == result.transformation.step[0].fields[0].field[e].rename[0])) && culetField.indexOf(result.transformation.step[0].fields[0].field[e].name[0].toUpperCase()) !== -1) {
    //                                        ind = fileHeader[0].findIndex(function (v) { return culetField.indexOf(v.toUpperCase()) !== -1; })
    //                                        if (ind > 0) { result.transformation.step[0].fields[0].field[e].name = [fileHeader[0][ind]]; } else if (lstmappedColumn.find(c => c.jewelColumn.toUpperCase() == result.transformation.step[0].fields[0].field[e].rename[0])) {
    //                                            result.transformation.step[0].fields[0].field[e].name = [lstmappedColumn.find(c => c.jewelColumn.toUpperCase() == result.transformation.step[0].fields[0].field[e].rename[0]).mappedColumn];
    //                                        } else {
    //                                            result.transformation.step[3].formula.push({ field_name: [result.transformation.step[0].fields[0].field[e].name[0]], formula_string: ['""'], value_type: ["String"], value_length: ["15"], value_precision: ["2"], replace_field: [""] });
    //                                        }
    //                                    }
    //                                    else if (culetconditionField.indexOf(result.transformation.step[0].fields[0].field[e].name[0].toUpperCase()) !== -1 || (lstmappedColumn.find(c => c.jewelColumn.toUpperCase() == result.transformation.step[0].fields[0].field[e].rename[0])) && culetconditionField.indexOf(result.transformation.step[0].fields[0].field[e].name[0].toUpperCase()) !== -1) {
    //                                        ind = fileHeader[0].findIndex(function (v) { return culetconditionField.indexOf(v.toUpperCase()) !== -1; })
    //                                        if (ind > 0) { result.transformation.step[0].fields[0].field[e].name = [fileHeader[0][ind]]; } else if (lstmappedColumn.find(c => c.jewelColumn.toUpperCase() == result.transformation.step[0].fields[0].field[e].rename[0])) {
    //                                            result.transformation.step[0].fields[0].field[e].name = [lstmappedColumn.find(c => c.jewelColumn.toUpperCase() == result.transformation.step[0].fields[0].field[e].rename[0]).mappedColumn];
    //                                        } else {
    //                                            result.transformation.step[3].formula.push({ field_name: [result.transformation.step[0].fields[0].field[e].name[0]], formula_string: ['""'], value_type: ["String"], value_length: ["15"], value_precision: ["2"], replace_field: [""] });
    //                                        }
    //                                    }
    //                                    else if (fancycolorField.indexOf(result.transformation.step[0].fields[0].field[e].name[0].toUpperCase()) !== -1 || (lstmappedColumn.find(c => c.jewelColumn.toUpperCase() == result.transformation.step[0].fields[0].field[e].rename[0])) && fancycolorField.indexOf(result.transformation.step[0].fields[0].field[e].name[0].toUpperCase()) !== -1) {
    //                                        ind = fileHeader[0].findIndex(function (v) { return fancycolorField.indexOf(v.toUpperCase()) !== -1; })
    //                                        if (ind > 0) { result.transformation.step[0].fields[0].field[e].name = [fileHeader[0][ind]]; } else if (lstmappedColumn.find(c => c.jewelColumn.toUpperCase() == result.transformation.step[0].fields[0].field[e].rename[0])) {
    //                                            result.transformation.step[0].fields[0].field[e].name = [lstmappedColumn.find(c => c.jewelColumn.toUpperCase() == result.transformation.step[0].fields[0].field[e].rename[0]).mappedColumn];
    //                                        } else {
    //                                            result.transformation.step[3].formula.push({ field_name: [result.transformation.step[0].fields[0].field[e].name[0]], formula_string: ['""'], value_type: ["String"], value_length: ["15"], value_precision: ["2"], replace_field: [""] });
    //                                        }
    //                                    }
    //                                    else if (fancycolorintensityField.indexOf(result.transformation.step[0].fields[0].field[e].name[0].toUpperCase()) !== -1 || (lstmappedColumn.find(c => c.jewelColumn.toUpperCase() == result.transformation.step[0].fields[0].field[e].rename[0])) && fancycolorintensityField.indexOf(result.transformation.step[0].fields[0].field[e].name[0].toUpperCase()) !== -1) {
    //                                        ind = fileHeader[0].findIndex(function (v) { return fancycolorintensityField.indexOf(v.toUpperCase()) !== -1; })
    //                                        if (ind > 0) { result.transformation.step[0].fields[0].field[e].name = [fileHeader[0][ind]]; } else if (lstmappedColumn.find(c => c.jewelColumn.toUpperCase() == result.transformation.step[0].fields[0].field[e].rename[0])) {
    //                                            result.transformation.step[0].fields[0].field[e].name = [lstmappedColumn.find(c => c.jewelColumn.toUpperCase() == result.transformation.step[0].fields[0].field[e].rename[0]).mappedColumn];
    //                                        } else {
    //                                            result.transformation.step[3].formula.push({ field_name: [result.transformation.step[0].fields[0].field[e].name[0]], formula_string: ['""'], value_type: ["String"], value_length: ["15"], value_precision: ["2"], replace_field: [""] });
    //                                        }
    //                                    }
    //                                    else if (fancycolorovertoneField.indexOf(result.transformation.step[0].fields[0].field[e].name[0].toUpperCase()) !== -1 || (lstmappedColumn.find(c => c.jewelColumn.toUpperCase() == result.transformation.step[0].fields[0].field[e].rename[0])) && fancycolorovertoneField.indexOf(result.transformation.step[0].fields[0].field[e].name[0].toUpperCase()) !== -1) {
    //                                        ind = fileHeader[0].findIndex(function (v) { return fancycolorovertoneField.indexOf(v.toUpperCase()) !== -1; })
    //                                        if (ind > 0) { result.transformation.step[0].fields[0].field[e].name = [fileHeader[0][ind]]; } else if (lstmappedColumn.find(c => c.jewelColumn.toUpperCase() == result.transformation.step[0].fields[0].field[e].rename[0])) {
    //                                            result.transformation.step[0].fields[0].field[e].name = [lstmappedColumn.find(c => c.jewelColumn.toUpperCase() == result.transformation.step[0].fields[0].field[e].rename[0]).mappedColumn];
    //                                        } else {
    //                                            result.transformation.step[3].formula.push({ field_name: [result.transformation.step[0].fields[0].field[e].name[0]], formula_string: ['""'], value_type: ["String"], value_length: ["15"], value_precision: ["2"], replace_field: [""] });
    //                                        }
    //                                    }
    //                                    else if (pairstocknoField.indexOf(result.transformation.step[0].fields[0].field[e].name[0].toUpperCase()) !== -1 || (lstmappedColumn.find(c => c.jewelColumn.toUpperCase() == result.transformation.step[0].fields[0].field[e].rename[0])) && pairstocknoField.indexOf(result.transformation.step[0].fields[0].field[e].name[0].toUpperCase()) !== -1) {
    //                                        ind = fileHeader[0].findIndex(function (v) { return pairstocknoField.indexOf(v.toUpperCase()) !== -1; })
    //                                        if (ind > 0) { result.transformation.step[0].fields[0].field[e].name = [fileHeader[0][ind]]; } else if (lstmappedColumn.find(c => c.jewelColumn.toUpperCase() == result.transformation.step[0].fields[0].field[e].rename[0])) {
    //                                            result.transformation.step[0].fields[0].field[e].name = [lstmappedColumn.find(c => c.jewelColumn.toUpperCase() == result.transformation.step[0].fields[0].field[e].rename[0]).mappedColumn];
    //                                        } else {
    //                                            result.transformation.step[3].formula.push({ field_name: [result.transformation.step[0].fields[0].field[e].name[0]], formula_string: ['""'], value_type: ["String"], value_length: ["15"], value_precision: ["2"], replace_field: [""] });
    //                                        }
    //                                    }
    //                                    else if (pairseparableField.indexOf(result.transformation.step[0].fields[0].field[e].name[0].toUpperCase()) !== -1 || (lstmappedColumn.find(c => c.jewelColumn.toUpperCase() == result.transformation.step[0].fields[0].field[e].rename[0])) && pairseparableField.indexOf(result.transformation.step[0].fields[0].field[e].name[0].toUpperCase()) !== -1) {
    //                                        ind = fileHeader[0].findIndex(function (v) { return pairseparableField.indexOf(v.toUpperCase()) !== -1; })
    //                                        if (ind > 0) { result.transformation.step[0].fields[0].field[e].name = [fileHeader[0][ind]]; } else if (lstmappedColumn.find(c => c.jewelColumn.toUpperCase() == result.transformation.step[0].fields[0].field[e].rename[0])) {
    //                                            result.transformation.step[0].fields[0].field[e].name = [lstmappedColumn.find(c => c.jewelColumn.toUpperCase() == result.transformation.step[0].fields[0].field[e].rename[0]).mappedColumn];
    //                                        } else {
    //                                            result.transformation.step[3].formula.push({ field_name: [result.transformation.step[0].fields[0].field[e].name[0]], formula_string: ['""'], value_type: ["String"], value_length: ["15"], value_precision: ["2"], replace_field: [""] });
    //                                        }
    //                                    }
    //                                    else if (certificateimageField.indexOf(result.transformation.step[0].fields[0].field[e].name[0].toUpperCase()) !== -1 || (lstmappedColumn.find(c => c.jewelColumn.toUpperCase() == result.transformation.step[0].fields[0].field[e].rename[0])) && certificateimageField.indexOf(result.transformation.step[0].fields[0].field[e].name[0].toUpperCase()) !== -1) {
    //                                        ind = fileHeader[0].findIndex(function (v) { return certificateimageField.indexOf(v.toUpperCase()) !== -1; })
    //                                        if (ind > 0) { result.transformation.step[0].fields[0].field[e].name = [fileHeader[0][ind]]; } else if (lstmappedColumn.find(c => c.jewelColumn.toUpperCase() == result.transformation.step[0].fields[0].field[e].rename[0])) {
    //                                            result.transformation.step[0].fields[0].field[e].name = [lstmappedColumn.find(c => c.jewelColumn.toUpperCase() == result.transformation.step[0].fields[0].field[e].rename[0]).mappedColumn];
    //                                        } else {
    //                                            result.transformation.step[3].formula.push({ field_name: [result.transformation.step[0].fields[0].field[e].name[0]], formula_string: ['""'], value_type: ["String"], value_length: ["15"], value_precision: ["2"], replace_field: [""] });
    //                                        }
    //                                    }
    //                                    else if (imagefilenameField.indexOf(result.transformation.step[0].fields[0].field[e].name[0].toUpperCase()) !== -1 || (lstmappedColumn.find(c => c.jewelColumn.toUpperCase() == result.transformation.step[0].fields[0].field[e].rename[0])) && imagefilenameField.indexOf(result.transformation.step[0].fields[0].field[e].name[0].toUpperCase()) !== -1) {
    //                                        ind = fileHeader[0].findIndex(function (v) { return imagefilenameField.indexOf(v.toUpperCase()) !== -1; })
    //                                        if (ind > 0) { result.transformation.step[0].fields[0].field[e].name = [fileHeader[0][ind]]; } else if (lstmappedColumn.find(c => c.jewelColumn.toUpperCase() == result.transformation.step[0].fields[0].field[e].rename[0])) {
    //                                            result.transformation.step[0].fields[0].field[e].name = [lstmappedColumn.find(c => c.jewelColumn.toUpperCase() == result.transformation.step[0].fields[0].field[e].rename[0]).mappedColumn];
    //                                        } else {
    //                                            result.transformation.step[3].formula.push({ field_name: [result.transformation.step[0].fields[0].field[e].name[0]], formula_string: ['""'], value_type: ["String"], value_length: ["15"], value_precision: ["2"], replace_field: [""] });
    //                                        }
    //                                    }
    //                                    else if (videofilenameField.indexOf(result.transformation.step[0].fields[0].field[e].name[0].toUpperCase()) !== -1 || (lstmappedColumn.find(c => c.jewelColumn.toUpperCase() == result.transformation.step[0].fields[0].field[e].rename[0])) && videofilenameField.indexOf(result.transformation.step[0].fields[0].field[e].name[0].toUpperCase()) !== -1) {
    //                                        ind = fileHeader[0].findIndex(function (v) { return videofilenameField.indexOf(v.toUpperCase()) !== -1; })
    //                                        if (ind > 0) { result.transformation.step[0].fields[0].field[e].name = [fileHeader[0][ind]]; } else if (lstmappedColumn.find(c => c.jewelColumn.toUpperCase() == result.transformation.step[0].fields[0].field[e].rename[0])) {
    //                                            result.transformation.step[0].fields[0].field[e].name = [lstmappedColumn.find(c => c.jewelColumn.toUpperCase() == result.transformation.step[0].fields[0].field[e].rename[0]).mappedColumn];
    //                                        } else {
    //                                            result.transformation.step[3].formula.push({ field_name: [result.transformation.step[0].fields[0].field[e].name[0]], formula_string: ['""'], value_type: ["String"], value_length: ["15"], value_precision: ["2"], replace_field: [""] });
    //                                        }
    //                                    }
    //                                    else if (lotnumberField.indexOf(result.transformation.step[0].fields[0].field[e].name[0].toUpperCase()) !== -1 || (lstmappedColumn.find(c => c.jewelColumn.toUpperCase() == result.transformation.step[0].fields[0].field[e].rename[0])) && lotnumberField.indexOf(result.transformation.step[0].fields[0].field[e].name[0].toUpperCase()) !== -1) {
    //                                        ind = fileHeader[0].findIndex(function (v) { return lotnumberField.indexOf(v.toUpperCase()) !== -1; })
    //                                        if (ind > 0) { result.transformation.step[0].fields[0].field[e].name = [fileHeader[0][ind]]; } else if (lstmappedColumn.find(c => c.jewelColumn.toUpperCase() == result.transformation.step[0].fields[0].field[e].rename[0])) {
    //                                            result.transformation.step[0].fields[0].field[e].name = [lstmappedColumn.find(c => c.jewelColumn.toUpperCase() == result.transformation.step[0].fields[0].field[e].rename[0]).mappedColumn];
    //                                        } else {
    //                                            result.transformation.step[3].formula.push({ field_name: [result.transformation.step[0].fields[0].field[e].name[0]], formula_string: ['""'], value_type: ["String"], value_length: ["15"], value_precision: ["2"], replace_field: [""] });
    //                                        }
    //                                    }
    //                                    else if (availabilityField.indexOf(result.transformation.step[0].fields[0].field[e].name[0].toUpperCase()) !== -1 || (lstmappedColumn.find(c => c.jewelColumn.toUpperCase() == result.transformation.step[0].fields[0].field[e].rename[0])) && availabilityField.indexOf(result.transformation.step[0].fields[0].field[e].name[0].toUpperCase()) !== -1) {
    //                                        ind = fileHeader[0].findIndex(function (v) { return availabilityField.indexOf(v.toUpperCase()) !== -1; })
    //                                        if (ind > 0) { result.transformation.step[0].fields[0].field[e].name = [fileHeader[0][ind]]; } else if (lstmappedColumn.find(c => c.jewelColumn.toUpperCase() == result.transformation.step[0].fields[0].field[e].rename[0])) {
    //                                            result.transformation.step[0].fields[0].field[e].name = [lstmappedColumn.find(c => c.jewelColumn.toUpperCase() == result.transformation.step[0].fields[0].field[e].rename[0]).mappedColumn];
    //                                        } else {
    //                                            result.transformation.step[3].formula.push({ field_name: [result.transformation.step[0].fields[0].field[e].name[0]], formula_string: ['""'], value_type: ["String"], value_length: ["15"], value_precision: ["2"], replace_field: [""] });
    //                                        }
    //                                    }
    //                                    else if (stonesField.indexOf(result.transformation.step[0].fields[0].field[e].name[0].toUpperCase()) !== -1 || (lstmappedColumn.find(c => c.jewelColumn.toUpperCase() == result.transformation.step[0].fields[0].field[e].rename[0])) && stonesField.indexOf(result.transformation.step[0].fields[0].field[e].name[0].toUpperCase()) !== -1) {
    //                                        ind = fileHeader[0].findIndex(function (v) { return stonesField.indexOf(v.toUpperCase()) !== -1; })
    //                                        if (ind > 0) { result.transformation.step[0].fields[0].field[e].name = [fileHeader[0][ind]]; } else if (lstmappedColumn.find(c => c.jewelColumn.toUpperCase() == result.transformation.step[0].fields[0].field[e].rename[0])) {
    //                                            result.transformation.step[0].fields[0].field[e].name = [lstmappedColumn.find(c => c.jewelColumn.toUpperCase() == result.transformation.step[0].fields[0].field[e].rename[0]).mappedColumn];
    //                                        } else {
    //                                            result.transformation.step[3].formula.push({ field_name: [result.transformation.step[0].fields[0].field[e].name[0]], formula_string: ['""'], value_type: ["String"], value_length: ["15"], value_precision: ["2"], replace_field: [""] });
    //                                        }
    //                                    }
    //                                    else if (locationField.indexOf(result.transformation.step[0].fields[0].field[e].name[0].toUpperCase()) !== -1 || (lstmappedColumn.find(c => c.jewelColumn.toUpperCase() == result.transformation.step[0].fields[0].field[e].rename[0])) && locationField.indexOf(result.transformation.step[0].fields[0].field[e].name[0].toUpperCase()) !== -1) {
    //                                        ind = fileHeader[0].findIndex(function (v) { return locationField.indexOf(v.toUpperCase()) !== -1; })
    //                                        if (ind > 0) { result.transformation.step[0].fields[0].field[e].name = [fileHeader[0][ind]]; } else if (lstmappedColumn.find(c => c.jewelColumn.toUpperCase() == result.transformation.step[0].fields[0].field[e].rename[0])) {
    //                                            result.transformation.step[0].fields[0].field[e].name = [lstmappedColumn.find(c => c.jewelColumn.toUpperCase() == result.transformation.step[0].fields[0].field[e].rename[0]).mappedColumn];
    //                                        } else {
    //                                            result.transformation.step[3].formula.push({ field_name: [result.transformation.step[0].fields[0].field[e].name[0]], formula_string: ['""'], value_type: ["String"], value_length: ["15"], value_precision: ["2"], replace_field: [""] });
    //                                        }
    //                                    }
    //                                    else if (cityField.indexOf(result.transformation.step[0].fields[0].field[e].name[0].toUpperCase()) !== -1 || (lstmappedColumn.find(c => c.jewelColumn.toUpperCase() == result.transformation.step[0].fields[0].field[e].rename[0])) && cityField.indexOf(result.transformation.step[0].fields[0].field[e].name[0].toUpperCase()) !== -1) {
    //                                        ind = fileHeader[0].findIndex(function (v) { return cityField.indexOf(v.toUpperCase()) !== -1; })
    //                                        if (ind > 0) { result.transformation.step[0].fields[0].field[e].name = [fileHeader[0][ind]]; } else if (lstmappedColumn.find(c => c.jewelColumn.toUpperCase() == result.transformation.step[0].fields[0].field[e].rename[0])) {
    //                                            result.transformation.step[0].fields[0].field[e].name = [lstmappedColumn.find(c => c.jewelColumn.toUpperCase() == result.transformation.step[0].fields[0].field[e].rename[0]).mappedColumn];
    //                                        } else {
    //                                            result.transformation.step[3].formula.push({ field_name: [result.transformation.step[0].fields[0].field[e].name[0]], formula_string: ['""'], value_type: ["String"], value_length: ["15"], value_precision: ["2"], replace_field: [""] });
    //                                        }
    //                                    }

    //                                    else if (stateField.indexOf(result.transformation.step[0].fields[0].field[e].name[0].toUpperCase()) !== -1 || (lstmappedColumn.find(c => c.jewelColumn.toUpperCase() == result.transformation.step[0].fields[0].field[e].rename[0])) && stateField.indexOf(result.transformation.step[0].fields[0].field[e].name[0].toUpperCase()) !== -1) {
    //                                        ind = fileHeader[0].findIndex(function (v) { return stateField.indexOf(v.toUpperCase()) !== -1; })
    //                                        if (ind > 0) { result.transformation.step[0].fields[0].field[e].name = [fileHeader[0][ind]]; } else if (lstmappedColumn.find(c => c.jewelColumn.toUpperCase() == result.transformation.step[0].fields[0].field[e].rename[0])) {
    //                                            result.transformation.step[0].fields[0].field[e].name = [lstmappedColumn.find(c => c.jewelColumn.toUpperCase() == result.transformation.step[0].fields[0].field[e].rename[0]).mappedColumn];
    //                                        } else {
    //                                            result.transformation.step[3].formula.push({ field_name: [result.transformation.step[0].fields[0].field[e].name[0]], formula_string: ['""'], value_type: ["String"], value_length: ["15"], value_precision: ["2"], replace_field: [""] });
    //                                        }
    //                                    }
    //                                    else if (countryField.indexOf(result.transformation.step[0].fields[0].field[e].name[0].toUpperCase()) !== -1 || (lstmappedColumn.find(c => c.jewelColumn.toUpperCase() == result.transformation.step[0].fields[0].field[e].rename[0])) && countryField.indexOf(result.transformation.step[0].fields[0].field[e].name[0].toUpperCase()) !== -1) {
    //                                        ind = fileHeader[0].findIndex(function (v) { return countryField.indexOf(v.toUpperCase()) !== -1; })
    //                                        if (ind > 0) { result.transformation.step[0].fields[0].field[e].name = [fileHeader[0][ind]]; } else if (lstmappedColumn.find(c => c.jewelColumn.toUpperCase() == result.transformation.step[0].fields[0].field[e].rename[0])) {
    //                                            result.transformation.step[0].fields[0].field[e].name = [lstmappedColumn.find(c => c.jewelColumn.toUpperCase() == result.transformation.step[0].fields[0].field[e].rename[0]).mappedColumn];
    //                                        } else {
    //                                            result.transformation.step[3].formula.push({ field_name: [result.transformation.step[0].fields[0].field[e].name[0]], formula_string: ['""'], value_type: ["String"], value_length: ["15"], value_precision: ["2"], replace_field: [""] });
    //                                        }
    //                                    }
    //                                    else if (originField.indexOf(result.transformation.step[0].fields[0].field[e].name[0].toUpperCase()) !== -1 || (lstmappedColumn.find(c => c.jewelColumn.toUpperCase() == result.transformation.step[0].fields[0].field[e].rename[0])) && originField.indexOf(result.transformation.step[0].fields[0].field[e].name[0].toUpperCase()) !== -1) {
    //                                        ind = fileHeader[0].findIndex(function (v) { return originField.indexOf(v.toUpperCase()) !== -1; })
    //                                        if (ind > 0) { result.transformation.step[0].fields[0].field[e].name = [fileHeader[0][ind]]; } else if (lstmappedColumn.find(c => c.jewelColumn.toUpperCase() == result.transformation.step[0].fields[0].field[e].rename[0])) {
    //                                            result.transformation.step[0].fields[0].field[e].name = [lstmappedColumn.find(c => c.jewelColumn.toUpperCase() == result.transformation.step[0].fields[0].field[e].rename[0]).mappedColumn];
    //                                        } else {
    //                                            result.transformation.step[3].formula.push({ field_name: [result.transformation.step[0].fields[0].field[e].name[0]], formula_string: ['""'], value_type: ["String"], value_length: ["15"], value_precision: ["2"], replace_field: [""] });
    //                                        }
    //                                    }
    //                                    else if (offrapaportField.indexOf(result.transformation.step[0].fields[0].field[e].name[0].toUpperCase()) !== -1 || (lstmappedColumn.find(c => c.jewelColumn.toUpperCase() == result.transformation.step[0].fields[0].field[e].rename[0])) && offrapaportField.indexOf(result.transformation.step[0].fields[0].field[e].name[0].toUpperCase()) !== -1) {
    //                                        ind = fileHeader[0].findIndex(function (v) { return offrapaportField.indexOf(v.toUpperCase()) !== -1; })
    //                                        if (ind > 0) { result.transformation.step[0].fields[0].field[e].name = [fileHeader[0][ind]]; } else if (lstmappedColumn.find(c => c.jewelColumn.toUpperCase() == result.transformation.step[0].fields[0].field[e].rename[0])) {
    //                                            result.transformation.step[0].fields[0].field[e].name = [lstmappedColumn.find(c => c.jewelColumn.toUpperCase() == result.transformation.step[0].fields[0].field[e].rename[0]).mappedColumn];
    //                                        } else {
    //                                            result.transformation.step[3].formula.push({ field_name: [result.transformation.step[0].fields[0].field[e].name[0]], formula_string: ['""'], value_type: ["String"], value_length: ["15"], value_precision: ["2"], replace_field: [""] });
    //                                        }
    //                                    }
    //                                    else if (enhancementsField.indexOf(result.transformation.step[0].fields[0].field[e].name[0].toUpperCase()) !== -1 || (lstmappedColumn.find(c => c.jewelColumn.toUpperCase() == result.transformation.step[0].fields[0].field[e].rename[0])) && enhancementsField.indexOf(result.transformation.step[0].fields[0].field[e].name[0].toUpperCase()) !== -1) {
    //                                        ind = fileHeader[0].findIndex(function (v) { return enhancementsField.indexOf(v.toUpperCase()) !== -1; })
    //                                        if (ind > 0) { result.transformation.step[0].fields[0].field[e].name = [fileHeader[0][ind]]; } else if (lstmappedColumn.find(c => c.jewelColumn.toUpperCase() == result.transformation.step[0].fields[0].field[e].rename[0])) {
    //                                            result.transformation.step[0].fields[0].field[e].name = [lstmappedColumn.find(c => c.jewelColumn.toUpperCase() == result.transformation.step[0].fields[0].field[e].rename[0]).mappedColumn];
    //                                        } else {
    //                                            result.transformation.step[3].formula.push({ field_name: [result.transformation.step[0].fields[0].field[e].name[0]], formula_string: ['""'], value_type: ["String"], value_length: ["15"], value_precision: ["2"], replace_field: [""] });
    //                                        }
    //                                    }
    //                                    else if (laserinscriptionField.indexOf(result.transformation.step[0].fields[0].field[e].name[0].toUpperCase()) !== -1 || (lstmappedColumn.find(c => c.jewelColumn.toUpperCase() == result.transformation.step[0].fields[0].field[e].rename[0])) && laserinscriptionField.indexOf(result.transformation.step[0].fields[0].field[e].name[0].toUpperCase()) !== -1) {
    //                                        ind = fileHeader[0].findIndex(function (v) { return laserinscriptionField.indexOf(v.toUpperCase()) !== -1; })
    //                                        if (ind > 0) { result.transformation.step[0].fields[0].field[e].name = [fileHeader[0][ind]]; } else if (lstmappedColumn.find(c => c.jewelColumn.toUpperCase() == result.transformation.step[0].fields[0].field[e].rename[0])) {
    //                                            result.transformation.step[0].fields[0].field[e].name = [lstmappedColumn.find(c => c.jewelColumn.toUpperCase() == result.transformation.step[0].fields[0].field[e].rename[0]).mappedColumn];
    //                                        } else {
    //                                            result.transformation.step[3].formula.push({ field_name: [result.transformation.step[0].fields[0].field[e].name[0]], formula_string: ['""'], value_type: ["String"], value_length: ["15"], value_precision: ["2"], replace_field: [""] });
    //                                        }
    //                                    }
    //                                    else if (shadesField.indexOf(result.transformation.step[0].fields[0].field[e].name[0].toUpperCase()) !== -1 || (lstmappedColumn.find(c => c.jewelColumn.toUpperCase() == result.transformation.step[0].fields[0].field[e].rename[0])) && shadesField.indexOf(result.transformation.step[0].fields[0].field[e].name[0].toUpperCase()) !== -1) {
    //                                        ind = fileHeader[0].findIndex(function (v) { return shadesField.indexOf(v.toUpperCase()) !== -1; })
    //                                        if (ind > 0) { result.transformation.step[0].fields[0].field[e].name = [fileHeader[0][ind]]; } else if (lstmappedColumn.find(c => c.jewelColumn.toUpperCase() == result.transformation.step[0].fields[0].field[e].rename[0])) {
    //                                            result.transformation.step[0].fields[0].field[e].name = [lstmappedColumn.find(c => c.jewelColumn.toUpperCase() == result.transformation.step[0].fields[0].field[e].rename[0]).mappedColumn];
    //                                        } else {
    //                                            result.transformation.step[3].formula.push({ field_name: [result.transformation.step[0].fields[0].field[e].name[0]], formula_string: ['""'], value_type: ["String"], value_length: ["15"], value_precision: ["2"], replace_field: [""] });
    //                                        }
    //                                    }
    //                                    else if (treatmentField.indexOf(result.transformation.step[0].fields[0].field[e].name[0].toUpperCase()) !== -1 || (lstmappedColumn.find(c => c.jewelColumn.toUpperCase() == result.transformation.step[0].fields[0].field[e].rename[0])) && treatmentField.indexOf(result.transformation.step[0].fields[0].field[e].name[0].toUpperCase()) !== -1) {
    //                                        ind = fileHeader[0].findIndex(function (v) { return treatmentField.indexOf(v.toUpperCase()) !== -1; })
    //                                        if (ind > 0) { result.transformation.step[0].fields[0].field[e].name = [fileHeader[0][ind]]; } else if (lstmappedColumn.find(c => c.jewelColumn.toUpperCase() == result.transformation.step[0].fields[0].field[e].rename[0])) {
    //                                            result.transformation.step[0].fields[0].field[e].name = [lstmappedColumn.find(c => c.jewelColumn.toUpperCase() == result.transformation.step[0].fields[0].field[e].rename[0]).mappedColumn];
    //                                        } else {
    //                                            result.transformation.step[3].formula.push({ field_name: [result.transformation.step[0].fields[0].field[e].name[0]], formula_string: ['""'], value_type: ["String"], value_length: ["15"], value_precision: ["2"], replace_field: [""] });
    //                                        }
    //                                    }
    //                                    else if (keytosymbolField.indexOf(result.transformation.step[0].fields[0].field[e].name[0].toUpperCase()) !== -1 || (lstmappedColumn.find(c => c.jewelColumn.toUpperCase() == result.transformation.step[0].fields[0].field[e].rename[0])) && keytosymbolField.indexOf(result.transformation.step[0].fields[0].field[e].name[0].toUpperCase()) !== -1) {
    //                                        ind = fileHeader[0].findIndex(function (v) { return keytosymbolField.indexOf(v.toUpperCase()) !== -1; })
    //                                        if (ind > 0) { result.transformation.step[0].fields[0].field[e].name = [fileHeader[0][ind]]; } else if (lstmappedColumn.find(c => c.jewelColumn.toUpperCase() == result.transformation.step[0].fields[0].field[e].rename[0])) {
    //                                            result.transformation.step[0].fields[0].field[e].name = [lstmappedColumn.find(c => c.jewelColumn.toUpperCase() == result.transformation.step[0].fields[0].field[e].rename[0]).mappedColumn];
    //                                        } else {
    //                                            result.transformation.step[3].formula.push({ field_name: [result.transformation.step[0].fields[0].field[e].name[0]], formula_string: ['""'], value_type: ["String"], value_length: ["15"], value_precision: ["2"], replace_field: [""] });
    //                                        }
    //                                    }
    //                                    else if (blackinclusionField.indexOf(result.transformation.step[0].fields[0].field[e].name[0].toUpperCase()) !== -1 || (lstmappedColumn.find(c => c.jewelColumn.toUpperCase() == result.transformation.step[0].fields[0].field[e].rename[0])) && blackinclusionField.indexOf(result.transformation.step[0].fields[0].field[e].name[0].toUpperCase()) !== -1) {
    //                                        ind = fileHeader[0].findIndex(function (v) { return blackinclusionField.indexOf(v.toUpperCase()) !== -1; })
    //                                        if (ind > 0) { result.transformation.step[0].fields[0].field[e].name = [fileHeader[0][ind]]; } else if (lstmappedColumn.find(c => c.jewelColumn.toUpperCase() == result.transformation.step[0].fields[0].field[e].rename[0])) {
    //                                            result.transformation.step[0].fields[0].field[e].name = [lstmappedColumn.find(c => c.jewelColumn.toUpperCase() == result.transformation.step[0].fields[0].field[e].rename[0]).mappedColumn];
    //                                        } else {
    //                                            result.transformation.step[3].formula.push({ field_name: [result.transformation.step[0].fields[0].field[e].name[0]], formula_string: ['""'], value_type: ["String"], value_length: ["15"], value_precision: ["2"], replace_field: [""] });
    //                                        }
    //                                    }
    //                                    else if (centralinclusionField.indexOf(result.transformation.step[0].fields[0].field[e].name[0].toUpperCase()) !== -1 || (lstmappedColumn.find(c => c.jewelColumn.toUpperCase() == result.transformation.step[0].fields[0].field[e].rename[0])) && centralinclusionField.indexOf(result.transformation.step[0].fields[0].field[e].name[0].toUpperCase()) !== -1) {
    //                                        ind = fileHeader[0].findIndex(function (v) { return centralinclusionField.indexOf(v.toUpperCase()) !== -1; })
    //                                        if (ind > 0) { result.transformation.step[0].fields[0].field[e].name = [fileHeader[0][ind]]; } else if (lstmappedColumn.find(c => c.jewelColumn.toUpperCase() == result.transformation.step[0].fields[0].field[e].rename[0])) {
    //                                            result.transformation.step[0].fields[0].field[e].name = [lstmappedColumn.find(c => c.jewelColumn.toUpperCase() == result.transformation.step[0].fields[0].field[e].rename[0]).mappedColumn];
    //                                        } else {
    //                                            result.transformation.step[3].formula.push({ field_name: [result.transformation.step[0].fields[0].field[e].name[0]], formula_string: ['""'], value_type: ["String"], value_length: ["15"], value_precision: ["2"], replace_field: [""] });
    //                                        }
    //                                    }
    //                                    else if (milkyinclusionField.indexOf(result.transformation.step[0].fields[0].field[e].name[0].toUpperCase()) !== -1 || (lstmappedColumn.find(c => c.jewelColumn.toUpperCase() == result.transformation.step[0].fields[0].field[e].rename[0])) && milkyinclusionField.indexOf(result.transformation.step[0].fields[0].field[e].name[0].toUpperCase()) !== -1) {
    //                                        ind = fileHeader[0].findIndex(function (v) { return milkyinclusionField.indexOf(v.toUpperCase()) !== -1; })
    //                                        if (ind > 0) { result.transformation.step[0].fields[0].field[e].name = [fileHeader[0][ind]]; } else if (lstmappedColumn.find(c => c.jewelColumn.toUpperCase() == result.transformation.step[0].fields[0].field[e].rename[0])) {
    //                                            result.transformation.step[0].fields[0].field[e].name = [lstmappedColumn.find(c => c.jewelColumn.toUpperCase() == result.transformation.step[0].fields[0].field[e].rename[0]).mappedColumn];
    //                                        } else {
    //                                            result.transformation.step[3].formula.push({ field_name: [result.transformation.step[0].fields[0].field[e].name[0]], formula_string: ['""'], value_type: ["String"], value_length: ["15"], value_precision: ["2"], replace_field: [""] });
    //                                        }
    //                                    }
    //                                    else if (eyecleaninclusionField.indexOf(result.transformation.step[0].fields[0].field[e].name[0].toUpperCase()) !== -1 || (lstmappedColumn.find(c => c.jewelColumn.toUpperCase() == result.transformation.step[0].fields[0].field[e].rename[0])) && eyecleaninclusionField.indexOf(result.transformation.step[0].fields[0].field[e].name[0].toUpperCase()) !== -1) {
    //                                        ind = fileHeader[0].findIndex(function (v) { return eyecleaninclusionField.indexOf(v.toUpperCase()) !== -1; })
    //                                        if (ind > 0) { result.transformation.step[0].fields[0].field[e].name = [fileHeader[0][ind]]; } else if (lstmappedColumn.find(c => c.jewelColumn.toUpperCase() == result.transformation.step[0].fields[0].field[e].rename[0])) {
    //                                            result.transformation.step[0].fields[0].field[e].name = [lstmappedColumn.find(c => c.jewelColumn.toUpperCase() == result.transformation.step[0].fields[0].field[e].rename[0]).mappedColumn];
    //                                        } else {
    //                                            result.transformation.step[3].formula.push({ field_name: [result.transformation.step[0].fields[0].field[e].name[0]], formula_string: ['""'], value_type: ["String"], value_length: ["15"], value_precision: ["2"], replace_field: [""] });
    //                                        }
    //                                    }
    //                                    else if (commentsField.indexOf(result.transformation.step[0].fields[0].field[e].name[0].toUpperCase()) !== -1 || (lstmappedColumn.find(c => c.jewelColumn.toUpperCase() == result.transformation.step[0].fields[0].field[e].rename[0])) && commentsField.indexOf(result.transformation.step[0].fields[0].field[e].name[0].toUpperCase()) !== -1) {
    //                                        ind = fileHeader[0].findIndex(function (v) { return commentsField.indexOf(v.toUpperCase()) !== -1; })
    //                                        if (ind > 0) { result.transformation.step[0].fields[0].field[e].name = [fileHeader[0][ind]]; } else if (lstmappedColumn.find(c => c.jewelColumn.toUpperCase() == result.transformation.step[0].fields[0].field[e].rename[0])) {
    //                                            result.transformation.step[0].fields[0].field[e].name = [lstmappedColumn.find(c => c.jewelColumn.toUpperCase() == result.transformation.step[0].fields[0].field[e].rename[0]).mappedColumn];
    //                                        } else {
    //                                            result.transformation.step[3].formula.push({ field_name: [result.transformation.step[0].fields[0].field[e].name[0]], formula_string: ['""'], value_type: ["String"], value_length: ["15"], value_precision: ["2"], replace_field: [""] });
    //                                        }
    //                                    }
    //                                    else if (isactiveField.indexOf(result.transformation.step[0].fields[0].field[e].name[0].toUpperCase()) !== -1 || (lstmappedColumn.find(c => c.jewelColumn.toUpperCase() == result.transformation.step[0].fields[0].field[e].rename[0])) && isactiveField.indexOf(result.transformation.step[0].fields[0].field[e].name[0].toUpperCase()) !== -1) {
    //                                        ind = fileHeader[0].findIndex(function (v) { return isactiveField.indexOf(v.toUpperCase()) !== -1; })
    //                                        if (ind > 0) { result.transformation.step[0].fields[0].field[e].name = [fileHeader[0][ind]]; } else if (lstmappedColumn.find(c => c.jewelColumn.toUpperCase() == result.transformation.step[0].fields[0].field[e].rename[0])) {
    //                                            result.transformation.step[0].fields[0].field[e].name = [lstmappedColumn.find(c => c.jewelColumn.toUpperCase() == result.transformation.step[0].fields[0].field[e].rename[0]).mappedColumn];
    //                                        } else {
    //                                            result.transformation.step[3].formula.push({ field_name: [result.transformation.step[0].fields[0].field[e].name[0]], formula_string: ['""'], value_type: ["String"], value_length: ["15"], value_precision: ["2"], replace_field: [""] });
    //                                        }
    //                                    }

    //                                    else if (price1Field.indexOf(result.transformation.step[0].fields[0].field[e].name[0].toUpperCase()) !== -1 || (lstmappedColumn.find(c => c.jewelColumn.toUpperCase() == result.transformation.step[0].fields[0].field[e].rename[0])) && price1Field.indexOf(result.transformation.step[0].fields[0].field[e].name[0].toUpperCase()) !== -1) {
    //                                        ind = fileHeader[0].findIndex(function (v) { return price1Field.indexOf(v.toUpperCase()) !== -1; })
    //                                        if (ind > 0) { result.transformation.step[0].fields[0].field[e].name = [fileHeader[0][ind]]; } else if (lstmappedColumn.find(c => c.jewelColumn.toUpperCase() == result.transformation.step[0].fields[0].field[e].rename[0])) {
    //                                            result.transformation.step[0].fields[0].field[e].name = [lstmappedColumn.find(c => c.jewelColumn.toUpperCase() == result.transformation.step[0].fields[0].field[e].rename[0]).mappedColumn];
    //                                        } else {
    //                                            result.transformation.step[3].formula.push({ field_name: [result.transformation.step[0].fields[0].field[e].name[0]], formula_string: ['""'], value_type: ["String"], value_length: ["15"], value_precision: ["2"], replace_field: [""] });
    //                                        }
    //                                    }
    //                                    else if (price2Field.indexOf(result.transformation.step[0].fields[0].field[e].name[0].toUpperCase()) !== -1 || (lstmappedColumn.find(c => c.jewelColumn.toUpperCase() == result.transformation.step[0].fields[0].field[e].rename[0])) && price2Field.indexOf(result.transformation.step[0].fields[0].field[e].name[0].toUpperCase()) !== -1) {
    //                                        ind = fileHeader[0].findIndex(function (v) { return price2Field.indexOf(v.toUpperCase()) !== -1; })
    //                                        if (ind > 0) { result.transformation.step[0].fields[0].field[e].name = [fileHeader[0][ind]]; } else if (lstmappedColumn.find(c => c.jewelColumn.toUpperCase() == result.transformation.step[0].fields[0].field[e].rename[0])) {
    //                                            result.transformation.step[0].fields[0].field[e].name = [lstmappedColumn.find(c => c.jewelColumn.toUpperCase() == result.transformation.step[0].fields[0].field[e].rename[0]).mappedColumn];
    //                                        } else {
    //                                            result.transformation.step[3].formula.push({ field_name: [result.transformation.step[0].fields[0].field[e].name[0]], formula_string: ['""'], value_type: ["String"], value_length: ["15"], value_precision: ["2"], replace_field: [""] });
    //                                        }
    //                                    }
    //                                    else if (ratioField.indexOf(result.transformation.step[0].fields[0].field[e].name[0].toUpperCase()) !== -1 || (lstmappedColumn.find(c => c.jewelColumn.toUpperCase() == result.transformation.step[0].fields[0].field[e].rename[0])) && ratioField.indexOf(result.transformation.step[0].fields[0].field[e].name[0].toUpperCase()) !== -1) {
    //                                        ind = fileHeader[0].findIndex(function (v) { return ratioField.indexOf(v.toUpperCase()) !== -1; })
    //                                        if (ind > 0) { result.transformation.step[0].fields[0].field[e].name = [fileHeader[0][ind]]; } else if (lstmappedColumn.find(c => c.jewelColumn.toUpperCase() == result.transformation.step[0].fields[0].field[e].rename[0])) {
    //                                            result.transformation.step[0].fields[0].field[e].name = [lstmappedColumn.find(c => c.jewelColumn.toUpperCase() == result.transformation.step[0].fields[0].field[e].rename[0]).mappedColumn];
    //                                        } else {
    //                                            result.transformation.step[3].formula.push({ field_name: [result.transformation.step[0].fields[0].field[e].name[0]], formula_string: ['""'], value_type: ["String"], value_length: ["15"], value_precision: ["2"], replace_field: [""] });
    //                                        }
    //                                    }
    //                                    else if (thirdpartysellernameField.indexOf(result.transformation.step[0].fields[0].field[e].name[0].toUpperCase()) !== -1 || (lstmappedColumn.find(c => c.jewelColumn.toUpperCase() == result.transformation.step[0].fields[0].field[e].rename[0])) && thirdpartysellernameField.indexOf(result.transformation.step[0].fields[0].field[e].name[0].toUpperCase()) !== -1) {
    //                                        ind = fileHeader[0].findIndex(function (v) { return thirdpartysellernameField.indexOf(v.toUpperCase()) !== -1; })
    //                                        if (ind > 0) { result.transformation.step[0].fields[0].field[e].name = [fileHeader[0][ind]]; } else if (lstmappedColumn.find(c => c.jewelColumn.toUpperCase() == result.transformation.step[0].fields[0].field[e].rename[0])) {
    //                                            result.transformation.step[0].fields[0].field[e].name = [lstmappedColumn.find(c => c.jewelColumn.toUpperCase() == result.transformation.step[0].fields[0].field[e].rename[0]).mappedColumn];
    //                                        } else {
    //                                            result.transformation.step[3].formula.push({ field_name: [result.transformation.step[0].fields[0].field[e].name[0]], formula_string: ['""'], value_type: ["String"], value_length: ["15"], value_precision: ["2"], replace_field: [""] });
    //                                        }
    //                                    }
    //                                    else if (customfield1nameField.indexOf(result.transformation.step[0].fields[0].field[e].name[0].toUpperCase()) !== -1 || (lstmappedColumn.find(c => c.jewelColumn.toUpperCase() == result.transformation.step[0].fields[0].field[e].rename[0])) && customfield1nameField.indexOf(result.transformation.step[0].fields[0].field[e].name[0].toUpperCase()) !== -1) {
    //                                        ind = fileHeader[0].findIndex(function (v) { return customfield1nameField.indexOf(v.toUpperCase()) !== -1; })
    //                                        if (ind > 0) { result.transformation.step[0].fields[0].field[e].name = [fileHeader[0][ind]]; } else if (lstmappedColumn.find(c => c.jewelColumn.toUpperCase() == result.transformation.step[0].fields[0].field[e].rename[0])) {
    //                                            result.transformation.step[0].fields[0].field[e].name = [lstmappedColumn.find(c => c.jewelColumn.toUpperCase() == result.transformation.step[0].fields[0].field[e].rename[0]).mappedColumn];
    //                                        } else {
    //                                            result.transformation.step[3].formula.push({ field_name: [result.transformation.step[0].fields[0].field[e].name[0]], formula_string: ['""'], value_type: ["String"], value_length: ["15"], value_precision: ["2"], replace_field: [""] });
    //                                        }
    //                                    }
    //                                    else if (customfield1Field.indexOf(result.transformation.step[0].fields[0].field[e].name[0].toUpperCase()) !== -1 || (lstmappedColumn.find(c => c.jewelColumn.toUpperCase() == result.transformation.step[0].fields[0].field[e].rename[0])) && customfield1Field.indexOf(result.transformation.step[0].fields[0].field[e].name[0].toUpperCase()) !== -1) {
    //                                        ind = fileHeader[0].findIndex(function (v) { return customfield1Field.indexOf(v.toUpperCase()) !== -1; })
    //                                        if (ind > 0) { result.transformation.step[0].fields[0].field[e].name = [fileHeader[0][ind]]; } else if (lstmappedColumn.find(c => c.jewelColumn.toUpperCase() == result.transformation.step[0].fields[0].field[e].rename[0])) {
    //                                            result.transformation.step[0].fields[0].field[e].name = [lstmappedColumn.find(c => c.jewelColumn.toUpperCase() == result.transformation.step[0].fields[0].field[e].rename[0]).mappedColumn];
    //                                        } else {
    //                                            result.transformation.step[3].formula.push({ field_name: [result.transformation.step[0].fields[0].field[e].name[0]], formula_string: ['""'], value_type: ["String"], value_length: ["15"], value_precision: ["2"], replace_field: [""] });
    //                                        }
    //                                    }
    //                                    else if (customfield2nameField.indexOf(result.transformation.step[0].fields[0].field[e].name[0].toUpperCase()) !== -1 || (lstmappedColumn.find(c => c.jewelColumn.toUpperCase() == result.transformation.step[0].fields[0].field[e].rename[0])) && customfield2nameField.indexOf(result.transformation.step[0].fields[0].field[e].name[0].toUpperCase()) !== -1) {
    //                                        ind = fileHeader[0].findIndex(function (v) { return customfield2nameField.indexOf(v.toUpperCase()) !== -1; })
    //                                        if (ind > 0) { result.transformation.step[0].fields[0].field[e].name = [fileHeader[0][ind]]; } else if (lstmappedColumn.find(c => c.jewelColumn.toUpperCase() == result.transformation.step[0].fields[0].field[e].rename[0])) {
    //                                            result.transformation.step[0].fields[0].field[e].name = [lstmappedColumn.find(c => c.jewelColumn.toUpperCase() == result.transformation.step[0].fields[0].field[e].rename[0]).mappedColumn];
    //                                        } else {
    //                                            result.transformation.step[3].formula.push({ field_name: [result.transformation.step[0].fields[0].field[e].name[0]], formula_string: ['""'], value_type: ["String"], value_length: ["15"], value_precision: ["2"], replace_field: [""] });
    //                                        }
    //                                    }
    //                                    else if (customfield2Field.indexOf(result.transformation.step[0].fields[0].field[e].name[0].toUpperCase()) !== -1 || (lstmappedColumn.find(c => c.jewelColumn.toUpperCase() == result.transformation.step[0].fields[0].field[e].rename[0])) && customfield2Field.indexOf(result.transformation.step[0].fields[0].field[e].name[0].toUpperCase()) !== -1) {
    //                                        ind = fileHeader[0].findIndex(function (v) { return customfield2Field.indexOf(v.toUpperCase()) !== -1; })
    //                                        if (ind > 0) { result.transformation.step[0].fields[0].field[e].name = [fileHeader[0][ind]]; } else if (lstmappedColumn.find(c => c.jewelColumn.toUpperCase() == result.transformation.step[0].fields[0].field[e].rename[0])) {
    //                                            result.transformation.step[0].fields[0].field[e].name = [lstmappedColumn.find(c => c.jewelColumn.toUpperCase() == result.transformation.step[0].fields[0].field[e].rename[0]).mappedColumn];
    //                                        } else {
    //                                            result.transformation.step[3].formula.push({ field_name: [result.transformation.step[0].fields[0].field[e].name[0]], formula_string: ['""'], value_type: ["String"], value_length: ["15"], value_precision: ["2"], replace_field: [""] });
    //                                        }
    //                                    }
    //                                    else if (customfield3nameField.indexOf(result.transformation.step[0].fields[0].field[e].name[0].toUpperCase()) !== -1 || (lstmappedColumn.find(c => c.jewelColumn.toUpperCase() == result.transformation.step[0].fields[0].field[e].rename[0])) && customfield3nameField.indexOf(result.transformation.step[0].fields[0].field[e].name[0].toUpperCase()) !== -1) {
    //                                        ind = fileHeader[0].findIndex(function (v) { return customfield3nameField.indexOf(v.toUpperCase()) !== -1; })
    //                                        if (ind > 0) { result.transformation.step[0].fields[0].field[e].name = [fileHeader[0][ind]]; } else if (lstmappedColumn.find(c => c.jewelColumn.toUpperCase() == result.transformation.step[0].fields[0].field[e].rename[0])) {
    //                                            result.transformation.step[0].fields[0].field[e].name = [lstmappedColumn.find(c => c.jewelColumn.toUpperCase() == result.transformation.step[0].fields[0].field[e].rename[0]).mappedColumn];
    //                                        } else {
    //                                            result.transformation.step[3].formula.push({ field_name: [result.transformation.step[0].fields[0].field[e].name[0]], formula_string: ['""'], value_type: ["String"], value_length: ["15"], value_precision: ["2"], replace_field: [""] });
    //                                        }
    //                                    }
    //                                    else if (customfield3Field.indexOf(result.transformation.step[0].fields[0].field[e].name[0].toUpperCase()) !== -1 || (lstmappedColumn.find(c => c.jewelColumn.toUpperCase() == result.transformation.step[0].fields[0].field[e].rename[0])) && customfield3Field.indexOf(result.transformation.step[0].fields[0].field[e].name[0].toUpperCase()) !== -1) {
    //                                        ind = fileHeader[0].findIndex(function (v) { return customfield3Field.indexOf(v.toUpperCase()) !== -1; })
    //                                        if (ind > 0) { result.transformation.step[0].fields[0].field[e].name = [fileHeader[0][ind]]; } else if (lstmappedColumn.find(c => c.jewelColumn.toUpperCase() == result.transformation.step[0].fields[0].field[e].rename[0])) {
    //                                            result.transformation.step[0].fields[0].field[e].name = [lstmappedColumn.find(c => c.jewelColumn.toUpperCase() == result.transformation.step[0].fields[0].field[e].rename[0]).mappedColumn];
    //                                        } else {
    //                                            result.transformation.step[3].formula.push({ field_name: [result.transformation.step[0].fields[0].field[e].name[0]], formula_string: ['""'], value_type: ["String"], value_length: ["15"], value_precision: ["2"], replace_field: [""] });
    //                                        }
    //                                    }
    //                                    else if (customfield4nameField.indexOf(result.transformation.step[0].fields[0].field[e].name[0].toUpperCase()) !== -1 || (lstmappedColumn.find(c => c.jewelColumn.toUpperCase() == result.transformation.step[0].fields[0].field[e].rename[0])) && customfield4nameField.indexOf(result.transformation.step[0].fields[0].field[e].name[0].toUpperCase()) !== -1) {
    //                                        ind = fileHeader[0].findIndex(function (v) { return customfield4nameField.indexOf(v.toUpperCase()) !== -1; })
    //                                        if (ind > 0) { result.transformation.step[0].fields[0].field[e].name = [fileHeader[0][ind]]; } else if (lstmappedColumn.find(c => c.jewelColumn.toUpperCase() == result.transformation.step[0].fields[0].field[e].rename[0])) {
    //                                            result.transformation.step[0].fields[0].field[e].name = [lstmappedColumn.find(c => c.jewelColumn.toUpperCase() == result.transformation.step[0].fields[0].field[e].rename[0]).mappedColumn];
    //                                        } else {
    //                                            result.transformation.step[3].formula.push({ field_name: [result.transformation.step[0].fields[0].field[e].name[0]], formula_string: ['""'], value_type: ["String"], value_length: ["15"], value_precision: ["2"], replace_field: [""] });
    //                                        }
    //                                    }
    //                                    else if (customfield4Field.indexOf(result.transformation.step[0].fields[0].field[e].name[0].toUpperCase()) !== -1 || (lstmappedColumn.find(c => c.jewelColumn.toUpperCase() == result.transformation.step[0].fields[0].field[e].rename[0])) && customfield4Field.indexOf(result.transformation.step[0].fields[0].field[e].name[0].toUpperCase()) !== -1) {
    //                                        ind = fileHeader[0].findIndex(function (v) { return customfield4Field.indexOf(v.toUpperCase()) !== -1; })
    //                                        if (ind > 0) { result.transformation.step[0].fields[0].field[e].name = [fileHeader[0][ind]]; } else if (lstmappedColumn.find(c => c.jewelColumn.toUpperCase() == result.transformation.step[0].fields[0].field[e].rename[0])) {
    //                                            result.transformation.step[0].fields[0].field[e].name = [lstmappedColumn.find(c => c.jewelColumn.toUpperCase() == result.transformation.step[0].fields[0].field[e].rename[0]).mappedColumn];
    //                                        } else {
    //                                            result.transformation.step[3].formula.push({ field_name: [result.transformation.step[0].fields[0].field[e].name[0]], formula_string: ['""'], value_type: ["String"], value_length: ["15"], value_precision: ["2"], replace_field: [""] });
    //                                        }
    //                                    }
    //                                    else if (customfield5nameField.indexOf(result.transformation.step[0].fields[0].field[e].name[0].toUpperCase()) !== -1 || (lstmappedColumn.find(c => c.jewelColumn.toUpperCase() == result.transformation.step[0].fields[0].field[e].rename[0])) && customfield5nameField.indexOf(result.transformation.step[0].fields[0].field[e].name[0].toUpperCase()) !== -1) {
    //                                        ind = fileHeader[0].findIndex(function (v) { return customfield5nameField.indexOf(v.toUpperCase()) !== -1; })
    //                                        if (ind > 0) { result.transformation.step[0].fields[0].field[e].name = [fileHeader[0][ind]]; } else if (lstmappedColumn.find(c => c.jewelColumn.toUpperCase() == result.transformation.step[0].fields[0].field[e].rename[0])) {
    //                                            result.transformation.step[0].fields[0].field[e].name = [lstmappedColumn.find(c => c.jewelColumn.toUpperCase() == result.transformation.step[0].fields[0].field[e].rename[0]).mappedColumn];
    //                                        } else {
    //                                            result.transformation.step[3].formula.push({ field_name: [result.transformation.step[0].fields[0].field[e].name[0]], formula_string: ['""'], value_type: ["String"], value_length: ["15"], value_precision: ["2"], replace_field: [""] });
    //                                        }
    //                                    }
    //                                    else if (customfield5Field.indexOf(result.transformation.step[0].fields[0].field[e].name[0].toUpperCase()) !== -1 || (lstmappedColumn.find(c => c.jewelColumn.toUpperCase() == result.transformation.step[0].fields[0].field[e].rename[0])) && customfield5Field.indexOf(result.transformation.step[0].fields[0].field[e].name[0].toUpperCase()) !== -1) {
    //                                        ind = fileHeader[0].findIndex(function (v) { return customfield5Field.indexOf(v.toUpperCase()) !== -1; })
    //                                        if (ind > 0) { result.transformation.step[0].fields[0].field[e].name = [fileHeader[0][ind]]; } else if (lstmappedColumn.find(c => c.jewelColumn.toUpperCase() == result.transformation.step[0].fields[0].field[e].rename[0])) {
    //                                            result.transformation.step[0].fields[0].field[e].name = [lstmappedColumn.find(c => c.jewelColumn.toUpperCase() == result.transformation.step[0].fields[0].field[e].rename[0]).mappedColumn];
    //                                        } else {
    //                                            result.transformation.step[3].formula.push({ field_name: [result.transformation.step[0].fields[0].field[e].name[0]], formula_string: ['""'], value_type: ["String"], value_length: ["15"], value_precision: ["2"], replace_field: [""] });
    //                                        }
    //                                    }
    //                                    else if (dealercostField.indexOf(result.transformation.step[0].fields[0].field[e].name[0].toUpperCase()) !== -1 || (lstmappedColumn.find(c => c.jewelColumn.toUpperCase() == result.transformation.step[0].fields[0].field[e].rename[0])) && dealercostField.indexOf(result.transformation.step[0].fields[0].field[e].name[0].toUpperCase()) !== -1) {
    //                                        ind = fileHeader[0].findIndex(function (v) { return dealercostField.indexOf(v.toUpperCase()) !== -1; });
    //                                        if (ind > 0) {
    //                                            dealerCostRenameField = [fileHeader[0][ind]];
    //                                            result.transformation.step[0].fields[0].field[e].name = [fileHeader[0][ind]];
    //                                            //var formf = [];
    //                                            //formf = result.transformation.step[3].formula[0].formula_string.toString().split('/');
    //                                            //result.transformation.step[3].formula[0].formula_string[0] = "[" + fileHeader[0][ind].toString() + "]/[" + formf[0] + "]";
    //                                        } else if (lstmappedColumn.find(c => c.jewelColumn.toUpperCase() == result.transformation.step[0].fields[0].field[e].rename[0])) {
    //                                            result.transformation.step[0].fields[0].field[e].name = [lstmappedColumn.find(c => c.jewelColumn.toUpperCase() == result.transformation.step[0].fields[0].field[e].rename[0]).mappedColumn];
    //                                        }
    //                                        else {
    //                                            result.transformation.step[3].formula.push({ field_name: ["DealerCost"], formula_string: [""], value_type: ["Number"], value_length: ["5"], value_precision: ["2"], replace_field: [""] });
    //                                            //result.transformation.step[3].formula[0].formula_string = [0];
    //                                        }
    //                                    }
    //                                    else if (costpercaratField.indexOf(result.transformation.step[0].fields[0].field[e].name[0].toUpperCase()) !== -1 || (lstmappedColumn.find(c => c.jewelColumn.toUpperCase() == result.transformation.step[0].fields[0].field[e].rename[0])) && costpercaratField.indexOf(result.transformation.step[0].fields[0].field[e].name[0].toUpperCase()) !== -1) {
    //                                        ind = fileHeader[0].findIndex(function (v) { return costpercaratField.indexOf(v.toUpperCase()) !== -1; })
    //                                        if (ind > 0) {
    //                                            costpercaratRenameField = [fileHeader[0][ind]];
    //                                            result.transformation.step[0].fields[0].field[e].name = [fileHeader[0][ind]];
    //                                            result.transformation.step[2].compare[0].condition[0].conditions[0].condition[1].leftvalue[0] = fileHeader[0][ind].toString();
    //                                            result.transformation.step[3].formula[0].formula_string = [0];///['""']; [fileHeader[0][ind]];
    //                                        } else if (lstmappedColumn.find(c => c.jewelColumn.toUpperCase() == result.transformation.step[0].fields[0].field[e].rename[0])) {
    //                                            costpercaratRenameField = lstmappedColumn.find(c => c.jewelColumn.toUpperCase() == result.transformation.step[0].fields[0].field[e].rename[0]).mappedColumn;
    //                                            result.transformation.step[0].fields[0].field[e].name = [lstmappedColumn.find(c => c.jewelColumn.toUpperCase() == result.transformation.step[0].fields[0].field[e].rename[0]).mappedColumn];
    //                                            result.transformation.step[3].formula.push({ field_name: [result.transformation.step[0].fields[0].field[e].name[0]], formula_string: ['""'], value_type: ["Number"], value_length: ["5"], value_precision: ["2"], replace_field: [""] });
    //                                        } else {
    //                                            result.transformation.step[3].formula.push({ field_name: [result.transformation.step[0].fields[0].field[e].name[0]], formula_string: ['""'], value_type: ["Number"], value_length: ["5"], value_precision: ["2"], replace_field: [""] });
    //                                        }
    //                                    }
    //                                    else {
    //                                        var chkFormula = 0;
    //                                        for (var p = 0; p < result.transformation.step[3].formula.length; p++) {
    //                                            if (result.transformation.step[0].fields[0].field[e].name[0] == (result.transformation.step[3].formula[p].field_name[0])) {
    //                                                chkFormula = -1;
    //                                            }
    //                                        }
    //                                        if (chkFormula == 0) { result.transformation.step[3].formula.push({ field_name: [result.transformation.step[0].fields[0].field[e].name[0]], formula_string: ['""'], value_type: ["String"], value_length: ["15"], value_precision: ["2"], replace_field: [""] }); }
    //                                    }
    //                                }
    //                                ///result.transformation.step[3].formula[0].formula_string[0] = "[" + (dealerCostRenameField === "" ? "DealerCost" : dealerCostRenameField) + "]/[" + sizeRenameField + "]";

    //                                for (var i = 0; i < result.transformation.step[3].formula.length; i++) {
    //                                    if (result.transformation.step[3].formula[i].field_name[0] == "DealerCost") {
    //                                        result.transformation.step[3].formula[i].formula_string[0] = "[" + costpercaratRenameField + "]*[" + sizeRenameField + "]";
    //                                    }
    //                                }

    //                                var xml = xmlBuilder.buildObject(result);
    //                                xml = "<transformation_configuration>" + xml + "<transformation_execution_configuration></transformation_execution_configuration></transformation_configuration>";
    //                                let id = 0;
    //                                //console.log(xml);
    //                                var options = {
    //                                    url: registerTrans,
    //                                    auth: {
    //                                        username: 'cluster',
    //                                        password: 'cluster'
    //                                    },
    //                                    body: xml,
    //                                    headers: { 'carte': 'config-xml' },
    //                                };
    //                                request.post(options, function (error, response, body) {
    //                                    if (error) {
    //                                        console.log("error :", error);
    //                                    } else {
    //                                        parser.parseString(body, function (err, result) {
    //                                            console.log("body registerTrans:", result.webresult.id);
    //                                            id = result.webresult.id;
    //                                        });
    //                                        var optionsExe = {
    //                                            //method: 'GET',
    //                                            url: prepareExec + '?name=File_Format&id=' + id + '&xml=y',
    //                                            auth: {
    //                                                username: 'cluster',
    //                                                password: 'cluster'
    //                                            }
    //                                        };
    //                                        request.get(optionsExe, function (error, response, body) {
    //                                            //console.log("body :", body);
    //                                            if (error) {
    //                                                console.log("error :", error);
    //                                            } else {
    //                                                var optionsExecut = {
    //                                                    url: startExec + '?name=File_Format&id=' + id + '&xml=y',
    //                                                    auth: {
    //                                                        username: 'cluster',
    //                                                        password: 'cluster'
    //                                                    }
    //                                                };
    //                                                request.get(optionsExecut, function (error, response, body) {
    //                                                    //console.log("body :", body);
    //                                                    if (error) {
    //                                                        console.log("error :", error);
    //                                                    } else {
    //                                                        common.queryCassandra("update key_gemfind.diamondfileupload set pentaho_id='" + id + "',file_format_status='Finished',status='wait' where pk_id=" + pendingFiles[0].pk_id);
    //                                                    }
    //                                                });

    //                                            }
    //                                        });
    //                                        //rp(optionsExe)
    //                                        //    .then(function (response) {
    //                                        //        // resolved
    //                                        //        var optionsExe = {
    //                                        //            url: startExec + '?name=File_Format&id=' + id + '&xml=y',
    //                                        //            auth: {
    //                                        //                username: 'cluster',
    //                                        //                password: 'cluster'
    //                                        //            }
    //                                        //        };
    //                                        //        rp(optionsExe)
    //                                        //            .then(function (respons) {
    //                                        //                console.log("File format job completed: ");
    //                                        //                common.queryCassandra("update key_gemfind.diamondfileupload set pentaho_id='" + id + "',file_format_status='Finished',status='wait' where pk_id=" + pendingFiles[0].pk_id);
    //                                        //            })
    //                                        //            .catch(function (err) {
    //                                        //                // rejected
    //                                        //            });
    //                                        //    })
    //                                        //    .catch(function (err) {
    //                                        //        // rejected
    //                                        //    });
    //                                    }
    //                                });



    //                            });
    //                        });


    //                    });

    //                });
    //            }
    //        }
    //    });
    //} catch (e) {
    //    console.log(e);
    //}
});

var taskProcessDiamondFile = cron.schedule('*/5 * * * * *', () => {

    var optionsExe = {
        url: allStatus,
        auth: {
            username: 'cluster',
            password: 'cluster'
        }
    };
    request.get(optionsExe, function (error, response, body) {
        if (response) {
            parser.parseString(body, function (err, result) {
                try {
                    if (result) {
                        const finishedFiles = result.serverstatus.transstatuslist[0].transstatus;
                        //console.log("body all status:");
                        if (finishedFiles) {
                            for (var i = 0; i < finishedFiles.length; i++) {
                                ///console.log(finishedFiles.length); 
                                let transName = finishedFiles[i].transname[0];
                                let status = finishedFiles[i].status_desc[0];
                                let pentaho_id = finishedFiles[i].id[0];
                                client.execute("select * from key_gemfind.diamondFileUpload where pentaho_id='" + pentaho_id + "'  allow filtering", [], function (err, results) {
                                    ///console.log(pentaho_id);
                                    if (results && results.rows && results.rows.length > 0) {
                                        ///console.log(" IN " + results.rows.length);
                                        outputPath = 'F:\\Nayan\\API_Jewelcloud\\ModifiedFiles\\'; finalOutputPath = 'F:\\Nayan\\API_Jewelcloud\\FinalOutputFiles\\';
                                        var fileResult = results.rows;
                                        var file_path = fileResult[0].file_path;
                                        var file_type = fileResult[0].file_type;
                                        var isUploaded = fileResult[0].isfileupload;
                                        var pentahoInputFile = outputPath + path.basename(file_path).split('.')[0] + ".csv";
                                        var s3InputFile = finalOutputPath + path.basename(file_path).split('.')[0] + ".csv";
                                        if (transName === "File_Format" && status === "Finished" && fileResult[0].status === "wait" && fileResult[0].file_format_status === 'Finished') {
                                            secondPentahoJob(pentahoInputFile, fileResult[0].pk_id);
                                        } else if (transName === "Process_Diamonds" && status === "Finished" && fileResult[0].process_diamond_status === 'Finished' && fileResult[0].status === 'wait') {
                                            //if (fileResult[0].status === "wait")
                                            //    common.queryCassandra("update key_gemfind.diamondFileUpload set status='inprogress',updated_date= toTimeStamp(now())  where pk_id in (" + fileResult[0].pk_id.toString() + ")");
                                            if (isUploaded == false || isUploaded == null)
                                                uploadToS3(s3InputFile, fileResult[0].pk_id, pentaho_id, file_path, file_type);
                                            console.log("UploadToS3 In");
                                        } else {
                                            if (fileResult[0].status.toString().toLowerCase() !== 'rejected')
                                                getFileStatusFromPentaho(pentaho_id, fileResult[0].pk_id, fileResult[0].status.toString(), pentahoInputFile);
                                        }
                                    }
                                });
                            }
                        }
                    }
                } catch (e) {
                    console.log(e)
                }

            });
        } else {
            console.log(error);
        }
    });
});


function uploadToS3(file, diamid, pentaho_id, filePath, file_type) {
    //var query = "select  count(*) from TempDiamonds";///"select count(*) from TempDiamonds"  /// 
    //redshift.connect(function (err) {
    //    redshift.query(query, { raw: true }, function (err, data) {
    //        if (err) throw err;
    //        else {
    //            console.log(data);
    //            var obj = {
    //                email: 'nayan.rana@rigelnetworks.com',
    //                subject: path.basename(file) + ' error message on s3 insert data by upload file',
    //                body: data
    //            };
    //            emailTemplate.sendMail(obj);
    //            // redshift.close();
    //        }
    //    });
    //});
    try {
        ///await Promise.all(fileupload.map(async (file) => {
        ///console.log(": upload to s3 :", file);
        ///console.log(": upload to s3 :", JSON.stringify(diamid));

        var dealerDetail = '';
        var dir = path.dirname(filePath);
        var cust = dir.toString().split('\\');
        var custId = cust[cust.length - 1];
        client.execute("select * from key_gemfind.company_detail where dealerid=" + custId + " allow filtering", [], function (err, resultmailtemp) {
            if (err) {
                console.log('file upload: select company line 1202', err);
                //res.status(404).send({ msg: err });
            } else {
                dealerDetail = resultmailtemp.rows[0]
            }
        });


        let s3bucket = new aws.S3({
            accessKeyId: "AKIAJKUH4KR3N7EOCWRA",
            secretAccessKey: "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",
            Bucket: "gemfind_all_backups"
        });
        ////setTimeout(function () {
        s3bucket.createBucket(function () {
            fs.readFile(file, 'utf8', (err, data) => {
                ///console.log("file stream: ", data);
                if (err) {
                    console.log("file read error: ", err);
                    var obj = {
                        email: emailTo,
                        subject: 'Error on uploaded to s3.',
                        body: err
                    };
                    emailTemplate.sendMail(obj);
                }///throw err;
                const params = {
                    Bucket: "gemfind_all_backups", // pass your bucket name
                    Key: path.basename(file), // file will be saved as testBucket/contacts.csv
                    Body: data
                };

                console.log("Top--1");
                s3bucket.upload(params, (s3Err, data) => {

                    if (s3Err) { console.log(s3Err); } //}
                    else {

                        ///var query = "select count(*) from TempDiamonds";
                        var query = "copy TempDiamonds from 's3://gemfind_all_backups/" + path.basename(file) + "' credentials 'aws_access_key_id=AKIAJKUH4KR3N7EOCWRA;aws_secret_access_key=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' FILLRECORD  delimiter \',\' IGNOREHEADER 1 removequotes DATEFORMAT AS \'MM/DD/YYYY HH:MI\'; select pg_last_copy_count();";
                        console.log("Top");
                        var loc = data.Location.replace(/^\/\/|^.*?:(\/\/)?/, ''); ///"s3.amazonaws.com//gemfind_all_backups//GemFLooseDiamonds_test.csv";
                        console.log(`File uploaded successfully at ${loc}`);

                        redshift.connect(function (err) {
                            redshift.query(query, { raw: true }, function (err, data) {
                                                            


                                if (data)
                                    uploadFileCount = data[0].pg_last_copy_count;
                                if (err) {
                                    console.log("Redshift error: ", err);
                                    common.queryCassandra("update key_gemfind.diamondfileupload set status='Rejected' where pk_id=" + diamid);
                                    var FileName = path.basename(file);
                                    var uploadedRecords = uploadFileCount;
                                    var status = "Rejected";
                                    var DateTime = new Date().toISOString().replace(/T/, ' ').replace(/\..+/, '');
                                    var objReq = { "file_name": FileName, "numrecords": uploadedRecords, "status": status, "updated_date": DateTime };
                                    diamondProcess.getfileData(objReq);

                                    var query = "select top 1* from stl_load_errors order by starttime desc";///"select count(*) from TempDiamonds"  /// 
                                    redshift.connect(function (err) {
                                        redshift.query(query, { raw: true }, function (error, data) {
                                            if (error)
                                                console.log(error);
                                            //throw error;
                                            else {
                                                // console.log(data);
                                                client.execute("select * from key_gemfind.email_template where email_type='FileUploadError' allow filtering", [], function (err, resultmailtemp) {
                                                    if (err) {
                                                        console.log('file upload: select email line 1259', err);
                                                        //res.status(404).send({ msg: err });
                                                    } else {
                                                        emailBody = resultmailtemp.rows[0].email_body;
                                                        emailBody = emailBody.replace('#name#', '');
                                                        emailBody = emailBody.replace('#description#', "File Name: " + data[0].filename + " <br /> Column name :" + data[0].colname + " <br /> Error Reason: " + data[0].err_reason + " <br /> Field Value: " + data[0].raw_field_value)
                                                        var obj = {
                                                            email: emailTo,
                                                            subject: path.basename(file) + ' error message on s3 insert data by upload file',
                                                            body: emailBody
                                                        };
                                                        emailTemplate.sendMail(obj);
                                                    }
                                                });

                                                // redshift.close();
                                            }
                                        });
                                    });
                                }
                                else {
                                    let updateQuery = ''; let deleteQuery = '';
                                    let insertQuery = '';

                                    if (file_type == "Replace all") {
                                        debugger
                                        deleteQuery = "delete from diamonds where diamonds.DealerID =" + custId;
                                        insertQuery = "insert into diamonds(Cut , Color,  Clarity, ClarityID, CutGrade, CostPerCarat, TotalPrice, Depth, TableMeasure, Size, Dealerid, DealerInventoryNo, Polish, Symmetry, Flourescence, FlourescenceColor, Certificate, CertificateNo, Measurements, MeasurementsLength, MeasurementsHeight, MeasurementsWidth, Girdle, GirdleThickest, GirdlePercentage, Pavillion, PavillionHeight, PavillionPercentage, Crown, CrownHeight, CrownPercentage, Culet, CuletCondition, FancyColorMainBody, FancyColorintensity, FancyColorOvertone , PairStockNumber, PairSeparable, CertificateImage, AdditionalImage, ImageFileName, VideoFileName, LotNumber, OutOnMemo, Stones, InventoryRegion, City, State, Country, Origin, OffRapaport, Enhancements, LaserIncription, Shade, Treatment, KeyToSymbol, BlackInclusion, CentralInclusion, MilkyInclusion, EyeCleanInclusion, Comments, Modified, IsActive, Price1, Price2, Ratio, ThirdPartySellerName, CustomField1Name, CustomField1, CustomField2Name, CustomField2, CustomField3Name, CustomField3, CustomField4Name, CustomField4, CustomField5Name, CustomField5) select Cut , Color,  Clarity, ClarityID, CutGrade, CostPerCarat, TotalPrice, Depth, TableMeasure, Size, Dealerid, DealerInventoryNo, Polish, Symmetry, Flourescence, FlourescenceColor, Certificate, CertificateNo, Measurements, MeasurementsLength, MeasurementsHeight, MeasurementsWidth, Girdle, GirdleThickest, GirdlePercentage, Pavillion, PavillionHeight, PavillionPercentage, Crown, CrownHeight, CrownPercentage, Culet, CuletCondition, FancyColorMainBody, FancyColorintensity, FancyColorOvertone , PairStockNumber, PairSeparable, CertificateImage, AdditionalImage, ImageFileName, VideoFileName, LotNumber, OutOnMemo, Stones, InventoryRegion, City, State, Country, Origin, OffRapaport, Enhancements, LaserIncription, Shade, Treatment, KeyToSymbol, BlackInclusion, CentralInclusion, MilkyInclusion, EyeCleanInclusion, Comments, Modified, IsActive, Price1, Price2, Ratio, ThirdPartySellerName, CustomField1Name, CustomField1, CustomField2Name, CustomField2, CustomField3Name, CustomField3, CustomField4Name, CustomField4, CustomField5Name, CustomField5 from TempDiamonds where TempDiamonds.DealerId=" + custId;
                                        try {
                                            redshift.connect(function (err) {
                                                redshift.query(deleteQuery, { raw: true }, function (err, data) {
                                                    debugger
                                                    if (err)
                                                        console.log(err);//throw err;
                                                    else {
                                                        console.log("IN LOOP A");
                                                        redshift.connect(function (err) {
                                                            redshift.query(insertQuery, { raw: true }, function (err, data) {
                                                                debugger
                                                                if (err)
                                                                    console.log(err);//throw err;
                                                                else {
                                                                    console.log("IN LOOP B");
                                                                    redshift.connect(function (err) {
                                                                        redshift.query("delete from TempDiamonds where TempDiamonds.DealerID =" + custId, { raw: true }, function (err, data) {
                                                                            if (err)
                                                                                console.log(err);//throw err;
                                                                            else {

                                                                            }
                                                                        });
                                                                    });
                                                                    // ------------------------ code to delete file from s3 bucket -------------------------///
                                                                    const Deleteparams = {
                                                                        Bucket: "gemfind_all_backups", // pass your bucket name
                                                                        Key: path.basename(file) // file will be saved as testBucket/contacts.csv
                                                                    };
                                                                    s3bucket.deleteObject(Deleteparams, (s3Err, data) => {
                                                                        if (s3Err) { console.log(s3Err); }
                                                                        else {
                                                                            console.log("File Deleted Successfully");
                                                                        }
                                                                    });
                                                                    // ------------------------ End -------------------------///
                                                                }
                                                            });
                                                        });
                                                        // redshift.close();
                                                    }
                                                });
                                            });
                                        } catch (e) {
                                            console.log(e);
                                        }
                                    }
                                    else {
                                        updateQuery = "update diamonds set Cut = TempDiamonds.Cut,Color = TempDiamonds.Color,Clarity = TempDiamonds.Clarity,ClarityID = TempDiamonds.ClarityID,CutGrade = TempDiamonds.CutGrade,CostPerCarat = TempDiamonds.CostPerCarat,TotalPrice = TempDiamonds.TotalPrice,Depth = TempDiamonds.Depth,TableMeasure = TempDiamonds.TableMeasure,Size = TempDiamonds.Size,Dealerid = TempDiamonds.Dealerid,Polish = TempDiamonds.Polish,Symmetry = TempDiamonds.Symmetry,Flourescence = TempDiamonds.Flourescence,FlourescenceColor = TempDiamonds.FlourescenceColor,Certificate = TempDiamonds.Certificate,CertificateNo = TempDiamonds.CertificateNo,Measurements = TempDiamonds.Measurements,MeasurementsLength = TempDiamonds.MeasurementsLength,MeasurementsHeight = TempDiamonds.MeasurementsHeight,MeasurementsWidth = TempDiamonds.MeasurementsWidth,Girdle = TempDiamonds.Girdle,GirdleThickest = TempDiamonds.GirdleThickest,GirdlePercentage = TempDiamonds.GirdlePercentage,Pavillion = TempDiamonds.Pavillion,PavillionHeight = TempDiamonds.PavillionHeight,PavillionPercentage = TempDiamonds.PavillionPercentage, Crown = TempDiamonds.Crown,CrownHeight = TempDiamonds.CrownHeight,CrownPercentage = TempDiamonds.CrownPercentage,Culet = TempDiamonds.Culet,CuletCondition = TempDiamonds.CuletCondition, FancyColorMainBody = TempDiamonds.FancyColorMainBody,FancyColorIntensity = TempDiamonds.FancyColorIntensity,FancyColorOvertone = TempDiamonds.FancyColorOvertone,PairStockNumber = TempDiamonds.PairStockNumber,PairSeparable = TempDiamonds.PairSeparable,CertificateImage = TempDiamonds.CertificateImage,AdditionalImage = TempDiamonds.AdditionalImage,ImageFileName = TempDiamonds.ImageFileName,VideoFileName = TempDiamonds.VideoFileName,LotNumber = TempDiamonds.LotNumber,OutOnMemo = TempDiamonds.OutOnMemo,Stones = TempDiamonds.Stones,InventoryRegion = TempDiamonds.InventoryRegion,City = TempDiamonds.City,State = TempDiamonds.State,Country = TempDiamonds.Country,Origin = TempDiamonds.Origin,OffRapaport = TempDiamonds.OffRapaport,Enhancements = TempDiamonds.Enhancements,LaserIncription = TempDiamonds.LaserIncription,Shade = TempDiamonds.Shade,Treatment = TempDiamonds.Treatment,KeyToSymbol = TempDiamonds.KeyToSymbol,BlackInclusion = TempDiamonds.BlackInclusion,CentralInclusion = TempDiamonds.CentralInclusion,MilkyInclusion = TempDiamonds.MilkyInclusion,EyeCleanInclusion = TempDiamonds.EyeCleanInclusion,Comments = TempDiamonds.Comments,Modified = TempDiamonds.Modified,IsActive = TempDiamonds.IsActive,Price1 = TempDiamonds.Price1,Price2 = TempDiamonds.Price2,Ratio = TempDiamonds.Ratio,ThirdPartySellerName = TempDiamonds.ThirdPartySellerName,CustomField1Name = TempDiamonds.CustomField1Name,CustomField1 = TempDiamonds.CustomField1,CustomField2Name = TempDiamonds.CustomField2Name, CustomField2 = TempDiamonds.CustomField2,CustomField3Name = TempDiamonds.CustomField3Name, CustomField3 = TempDiamonds.CustomField3,CustomField4Name = TempDiamonds.CustomField4Name,CustomField4 = TempDiamonds.CustomField4,CustomField5Name = TempDiamonds.CustomField5Name,CustomField5 = TempDiamonds.CustomField5 from TempDiamonds where diamonds.DealerID = " + custId + " and diamonds.dealerinventoryNo in (select dealerinventoryNo from diamonds where DealerID=" + custId + ")";
                                        insertQuery = "insert into diamonds(Cut , Color,  Clarity, ClarityID, CutGrade, CostPerCarat, TotalPrice, Depth, TableMeasure, Size, Dealerid, DealerInventoryNo, Polish, Symmetry, Flourescence, FlourescenceColor, Certificate, CertificateNo, Measurements, MeasurementsLength, MeasurementsHeight, MeasurementsWidth, Girdle, GirdleThickest, GirdlePercentage, Pavillion, PavillionHeight, PavillionPercentage, Crown, CrownHeight, CrownPercentage, Culet, CuletCondition, FancyColorMainBody, FancyColorintensity, FancyColorOvertone , PairStockNumber, PairSeparable, CertificateImage, AdditionalImage, ImageFileName, VideoFileName, LotNumber, OutOnMemo, Stones, InventoryRegion, City, State, Country, Origin, OffRapaport, Enhancements, LaserIncription, Shade, Treatment, KeyToSymbol, BlackInclusion, CentralInclusion, MilkyInclusion, EyeCleanInclusion, Comments, Modified, IsActive, Price1, Price2, Ratio, ThirdPartySellerName, CustomField1Name, CustomField1, CustomField2Name, CustomField2, CustomField3Name, CustomField3, CustomField4Name, CustomField4, CustomField5Name, CustomField5) select Cut , Color,  Clarity, ClarityID, CutGrade, CostPerCarat, TotalPrice, Depth, TableMeasure, Size, Dealerid, DealerInventoryNo, Polish, Symmetry, Flourescence, FlourescenceColor, Certificate, CertificateNo, Measurements, MeasurementsLength, MeasurementsHeight, MeasurementsWidth, Girdle, GirdleThickest, GirdlePercentage, Pavillion, PavillionHeight, PavillionPercentage, Crown, CrownHeight, CrownPercentage, Culet, CuletCondition, FancyColorMainBody, FancyColorintensity, FancyColorOvertone , PairStockNumber, PairSeparable, CertificateImage, AdditionalImage, ImageFileName, VideoFileName, LotNumber, OutOnMemo, Stones, InventoryRegion, City, State, Country, Origin, OffRapaport, Enhancements, LaserIncription, Shade, Treatment, KeyToSymbol, BlackInclusion, CentralInclusion, MilkyInclusion, EyeCleanInclusion, Comments, Modified, IsActive, Price1, Price2, Ratio, ThirdPartySellerName, CustomField1Name, CustomField1, CustomField2Name, CustomField2, CustomField3Name, CustomField3, CustomField4Name, CustomField4, CustomField5Name, CustomField5 from TempDiamonds where TempDiamonds.dealerinventoryNo not in (select dealerinventoryNo from diamonds where dealerid=" + custId + ") and TempDiamonds.DealerID=" + custId;
                                        try {
                                            redshift.connect(function (err) {
                                                redshift.query(updateQuery, { raw: true }, function (err, data) {
                                                    debugger
                                                    if (err) {
                                                        console.log(err);
                                                        redshift.connect(function (err) {
                                                            redshift.query("delete from TempDiamonds where TempDiamonds.DealerID =" + custId, { raw: true }, function (err, data) {
                                                                if (err)
                                                                    console.log(err);//throw err;
                                                                else {

                                                                }
                                                            });
                                                        });
                                                    }
                                                    else {
                                                        // console.log(data);
                                                        //var deleteQuery = "delete from diamonds using TempDiamonds  where (not diamonds.DealerInventoryNo=TempDiamonds.DealerInventoryNo) and diamonds.DealerID = TempDiamonds.DealerID";
                                                        redshift.connect(function (err) {
                                                            redshift.query(insertQuery, { raw: true }, function (err, data) {
                                                                debugger
                                                                if (err) {
                                                                    console.log(err);
                                                                    redshift.connect(function (err) {
                                                                        redshift.query("delete from TempDiamonds where TempDiamonds.DealerID =" + custId, { raw: true }, function (err, data) {
                                                                            if (err)
                                                                                console.log(err);//throw err;
                                                                            else {

                                                                            }
                                                                        });

                                                                        //------ remove file ------------///
                                                                        // ------------------------ code to delete file from s3 bucket -------------------------///
                                                                        const Deleteparams = {
                                                                            Bucket: "gemfind_all_backups", // pass your bucket name
                                                                            Key: path.basename(file) // file will be saved as testBucket/contacts.csv
                                                                        };
                                                                        s3bucket.deleteObject(Deleteparams, (s3Err, data) => {
                                                                            if (s3Err) { console.log(s3Err); }
                                                                            else {
                                                                                console.log("File Deleted Successfully");
                                                                            }
                                                                        });
                                                                        // ------------------------ End -------------------------///
                                                                    });
                                                                }
                                                                else {
                                                                    // console.log(data);
                                                                    redshift.connect(function (err) {
                                                                        redshift.query("delete from TempDiamonds where TempDiamonds.DealerID =" + custId, { raw: true }, function (err, data) {
                                                                            if (err)
                                                                                console.log(err);//throw err;
                                                                            else {

                                                                            }
                                                                        });
                                                                    });
                                                                    // redshift.close();
                                                                }
                                                            });
                                                        });
                                                        // redshift.close();
                                                    }
                                                });
                                            });
                                        } catch (e) {
                                            console.log(e);
                                        }
                                    }


                                    var optionsExe1 = {
                                        url: transStatus + '&xml=Y&id=' + pentaho_id,
                                        auth: {
                                            username: 'cluster',
                                            password: 'cluster'
                                        }
                                    };
                                    request.get(optionsExe1, function (error, response, body) {
                                        parser.parseString(body, function (err, result) {
                                            let emailBody = '';
                                            client.execute("select * from key_gemfind.email_template where email_type='FileUploadSuccess' allow filtering", [], function (err, resultmailtemp) {
                                                if (err) {
                                                    console.log('file upload: select email line 1334', err);
                                                    //res.status(404).send({ msg: err });
                                                } else {
                                                    emailBody = resultmailtemp.rows[0].email_body;
                                                    var readTotalData = result.transstatus.stepstatuslist[0].stepstatus[0].linesRead[0];
                                                    var readData = result.transstatus.stepstatuslist[0].stepstatus[18].linesRead[0];
                                                    console.log("Testing by Arbaz");
                                                    console.log(readTotalData);
                                                    console.log(readData);
                                                    var records = readData + " of " + readTotalData; //parseInt(readTotalData) - 
                                                    console.log(records);
                                                    debugger
                                                    common.queryCassandra("update key_gemfind.diamondFileUpload set status='Completed',isfileupload=true,updated_date= toTimeStamp(now()),numrecords='" + records.toString() + "'  where pk_id in (" + diamid + ")");
                                                    //common.queryCassandra("update key_gemfind.diamondFileUpload set status='Completed',updated_date='" + new Date().toJSON().slice(0, 10) + "',numrecords='" + records.toString() + "'  where pk_id in (" + diamid + ")");

                                                    

                                                    var FileName = path.basename(file);
                                                    var uploadedRecords = uploadFileCount;
                                                    var status = "Completed";
                                                    var DateTime = new Date().toISOString().replace(/T/, ' ').replace(/\..+/, '');
                                                    var objReq = { "file_name": FileName, "numrecords": uploadedRecords, "status": status, "updated_date": DateTime };
                                                    diamondProcess.getfileData(objReq);

                                                    emailBody = emailBody.replace('#name#', dealerDetail.name).replace('#totalDiamonds#', readTotalData).replace('#addedDiamonds#', uploadFileCount).replace('#updatedDiamonds#', 0).replace('#rejectedDiamonds#', (parseInt(readTotalData) - parseInt(readData)).toString());

                                                    var obj = {
                                                        email: dealerDetail.email,
                                                        subject: 'Status of Diamond Inventory Upload for ' + path.basename(file),
                                                        body: emailBody,
                                                        attachments: [{ filename: "FileIssues.csv", path: './FinalOutputFiles/' + "error_" + path.basename(file) }]
                                                    };
                                                    emailTemplate.sendMail(obj);
                                                }
                                            });
                                        });
                                    });



                                }
                            });
                        });
                    }
                });
               
            });
        });
        ///}, 1000);
        ///}));
        //let result = await promise;
    } catch (err) {
        // handle errors here
    }
}


let outputFields = ['CUT', 'COLOR', 'CLARITY', 'CUTGRADE', 'COSTPERCARAT', 'TOTALPRICE', 'DEPTH', 'TABLE', 'SIZE', 'DEALERID', 'STOCKNUMBER', 'POLISH', 'SYMMETRY', 'FLUORESCENCE', 'FLUORESCENCECOLOR', 'CERTIFICATE', 'CERTIFICATENO', 'MEASUREMENTS', 'MEASLENGTH', 'MEASHEIGHT', 'MEASWIDTH', 'GIRDLE', 'GIRDLETHICK', 'GIRDLEPERCENT', 'PAVILION', 'PAVILLIONHEIGHT', 'PAVILIONANGEL', 'CROWNANGLE', 'CROWNHEIGHT', 'CROWN', 'CULET', 'CULETCONDITION', 'FANCYCOLOR', 'FANCYCOLORINTENSITY', 'FANCYCOLOROVERTONE', 'PAIRSTOCKNO', 'PAIRSEPARABLE', 'CERTIFICATEIMAGE', 'ADDITIONALIMAGE', 'IMAGEFILENAME', 'VIDEOFILENAME', 'LOTNUMBER', 'AVAILABILITY', 'STONES', 'LOCATION', 'CITY', 'STATE', 'COUNTRY', 'ORIGIN', 'OFFRAPAPORT', 'ENHANCEMENTS', 'LASERINSCRIPTION', 'SHADES', 'TREATMENT', 'KEYTOSYMBOL', 'BLACKINCLUSION', 'CENTRALINCLUSION', 'MILKYINCLUSION', 'EYECLEANINCLUSION', 'COMMENTS', 'ISACTIVE', 'PRICE1', 'PRICE2', 'RATIO', 'THIRDPARTYSELLERNAME', 'CUSTOMFIELD1NAME', 'CUSTOMFIELD1', 'CUSTOMFIELD2NAME', 'CUSTOMFIELD2', 'CUSTOMFIELD3NAME', 'CUSTOMFIELD3', 'CUSTOMFIELD4NAME', 'CUSTOMFIELD4', 'CUSTOMFIELD5NAME', 'CUSTOMFIELD5'];




let cutField = ['CUT', 'SHAPE', 'CUT(SHAPE)', 'CUTSHAPE', 'SHP', 'CUTShape', 'SHP'];
let colorField = ['COLOR', 'COLR', 'COL'];
let clarityField = ['CLARITY', 'CLAR', 'CLR'];
let cutgradeField = ['CUT GRADE', 'CUTGRADE',];
let costpercaratField = ['COSTPERCARAT', 'PRICE PER CARAT', 'PRICEPERCARAT', 'COST PER CARAT', 'PRICE', 'ASKINGPRICE', 'PRICE CT', 'PRICE CARAT', 'COST CARAT', 'PRICECARAT', 'COSTCARAT', 'PRICE/CT', '$CT', '$/CT', '$/CT', 'PRICE/CARAT', 'COST/', 'AMOUNT U$', 'STINVCOSTEACH', 'PR CRT', 'RAPNET PRICE', 'RAPNETPRICE', 'PRICE $/CT.', 'RAP VLU'];// 
let totalPriceField = ['TOTALPRICE'];
let depthField = ['DEPTH', 'DEPTH %', 'DEPTH%', 'DEPT', 'DEPTHPERCENT', 'DPTH'];
let tableField = ['TABLE %', 'TABLE%', 'TABLE', 'TBLE', 'TABLEPERCENT'];
let sizeField = ['WEIGHT', 'SIZE', 'CARAT WEIGHT', 'CARATWEIGHT', 'CARAT', 'CT', 'CARATS', 'STWEIGHT', 'CTS'];
let stockNumberField = ['STOCK #', 'STOCK#', 'STOCKNUMBER', 'STOCK NUMBER', 'VENDOR STOCK #', 'VENDORSTOCK', 'INVENTORY STOCK #', 'INVENTORYSTOCK', 'STOCK NO', 'VENDOR STOCK NO', 'INVENTORY STOCK NO', 'STOCKNO', 'SKU #', 'STOCK', 'VENDORSTOCKNO', 'VENDORSTOCKNUMBER', 'VENDOR STOCK NUMBER', 'INVENTORYSTOCKNO', 'INVENTORY STOCK NUMBER', 'INVENTORYSTOCKNUMBER', 'INVENTORYNO', 'RAPNETLOT', 'STOCL_NO', 'STONE ID', 'DEALERINVENTORYNO', 'LOT NUMBER', 'LOTID', 'LOT #', 'LOT NO', 'LOT NO.', 'LOTNO.', 'LOTNUMBER', 'LOT', 'LOTNO', 'SKU', 'LOT#'];
let polishField = ['POLISH', 'POL'];
let symmetryField = ['SYMMETRY', 'SYM'];
let fluorescenceField = ['FL', 'FLUORESCENCEINTENSITY', 'FLUORESCENCE INTENSITY', 'FLUOR INTENSITY', 'FLUORINTENSITY', 'FLR', 'FLUOR', 'FLO'];
let fluorescencecolorField = ['FLUORESCENCE', 'FLUORESCENCECOLOR', 'FLUORESCENCE COLOR', 'FLUOR COLOR', 'FLUORCOLOR', 'FLRCOLOR'];
let certificateField = ['LAB', 'CERT', 'CERTIFICATE', 'CERTIFICATE TYPE', 'CERTIFICATETYPE', 'CERT TYPE', 'CERTTYPE', 'ONL. CERT'];
let certificatenoField = ['CERTIFICATE NO', 'CER NUMBER', 'CERTIFICATE #', 'CERTIFICATE#', 'CERT #', 'CERT#', 'CERTIFICATENO', 'CERTIFICATE ID', 'CERTNO', 'CERT.NO', 'CERTIFICATE NUMBER'];
let measurementsField = ['DIMENSIONS', 'MEASUREMENTS', 'MEASUREMENT', 'MEAS'];
let measlengthField = ['MEASLENGTH', 'M1', 'MAX', 'LENGTH'];
let measheightField = ['MEASHEIGHT', 'M3', 'HGT', 'MEASDEPTH'];
let measwidthField = ['MEASWIDTH', 'M2', 'MIN', 'WIDTH'];
let girdleField = ['GIRDLE', 'GIRDLE-MIN', 'GIRDLE MIN', 'GIRDLEMIN', 'GIRDLETHIN', 'GIRDLE THIN', 'GIRDLE(THINNEST)', 'GIRDLETHINNEST'];
let girdlethickField = ['GIRDLETHICK', 'GIRDLE-MAX', 'GIRDLE MAX', 'GIRDLEMAX', 'GIRDLE THICK', 'GIRDLE(THICKEST)', 'GIRDLETHICKEST', 'GIRDLE(THICKNEST)', 'GIRDLETHICKNEST'];
let girdlepercentField = ['GIRDLE %', 'GIRDLEPERCENT'];
let pavilionField = ['PAVILION', 'PAVILION %', 'AVILION %', 'PAVILLION'];
let pavillionheightField = ['PAVILLION HEIGHT', 'PAVILIONDEPTH', 'PAVILION DEPTH', 'PAVILLIONDEPTH', 'PAVILION HEIGHT', 'PAVILLIONHEIGHT', 'PAVILIONHEIGHT', 'PAV HEIGHT'];
let pavilionangelField = ['PAVILION ANGEL', 'PAVILION ANGLE', 'PAVILIONANGEL', 'PAVILIONANGLE', 'PAVILLION ANGEL', 'PAVILLION ANGLE', 'PAVILLIONANGEL', 'PAVILLIONANGLE', 'PAV ANG'];
let crownangleField = ['CROWN ANGLE', 'CROWN ANGLE', 'CROWNANGLE', 'CROWNANGEL', 'CROWN ANG'];
let crownheightField = ['CROWNHEIGHT', 'CROWN HEIGHT'];
let crownField = ['CROWN', 'CROWN %'];
let culetField = ['CULET', 'CUL', 'CULETSIZE', 'CULET SIZE'];
let culetconditionField = ['CULETCONFITION', 'CULET CONDITION'];
let fancycolorField = ['FANCY COLOR', 'FANCY COLOR MAIN', 'FANCYCOLORMAIN', 'FANCYCOLOR', 'FANCYCOLORMAINBODY', 'FANCY COLOR MAIN BODY', 'FC- MAIN BODY', 'FC-MAIN BODY', 'FC-MAINBODY'];
let fancycolorintensityField = ['FANCY COLOR INTENSITY', 'FANCYCOLORINTENSITY', 'FC- INTENSITY', 'FC-INTENSITY', 'FCINTENSITY', 'FANCY INTENSITY', 'FANCYINTENSITY'];
let fancycolorovertoneField = ['FANCY COLOR OVERTONE', 'FANCYCOLOROVERTONE', 'FC- OVERTONE', 'FC-OVERTONE', 'FCOVERTONE', 'FANCY OVERTONE', 'FANCYOVERTONE', 'FANCY OVERTON'];
let pairstocknoField = ['PAIR STOCK NO', 'PAIRSTOCKNO', 'PAIR STOCK #', 'PAIRSTOCKNUMBER', 'PAIR STOCK NUMBER', 'MATCHING STOCK #', 'MATCHING STONE STOCK #', 'MATCHING STOCK NO', 'MATCHINGSTOCKNO', 'MATCHING STOCK NUMBER', 'MATCHINGSTOCKNUMBER', 'MATCHEDPAIRSTOCKNUMBER', 'PAIR VENDOR STOCK NUMBER', 'PAIR', 'PAIRSTOCK_NO'];
let pairseparableField = ['PAIR SEPARABLE', 'ISMATCHEDPAIRSEPARABLE', 'IS MATCHED PAIR SEPARABLE', 'PAIRSEPARABLE', 'SEPARABLE'];
let certificateimageField = ['CERTIFICATE IMAGE', 'CERTIFICATEIMAGE', 'CERT IMAGE', 'CERTIMAGE', 'CERTFILENAME', 'CERTIFICATE URL', 'CERTIFICATEURL'];
let imagefilenameField = ['IMAGEFILENAME', 'IMAGENAME', 'IMAGE NAME', 'ADDITIONAL IMAGE', 'ADDITIONALIMAGE'];
let videofilenameField = ['VIDEOFILENAME', 'VIDEO URL', 'VIDEO'];
let lotnumberField = ['LOT NUMBER', 'LOTID', 'LOT #', 'LOT NO', 'LOT NO.', 'LOTNO.', 'LOTNUMBER', 'LOT', 'LOTNO', 'SKU', 'Lot#'];
let availabilityField = ['AVAILABILITY', 'GUARANTEED AVAILABILITY', 'GUARANTEEDAVAILABILITY', 'ONMEMO', 'OUTONMEMO', 'ON MEMO', 'OUT ON MEMO', 'MEMO', 'MEMO STATUS'];
let stonesField = ['STONES', 'STONE'];///,'Stone ID'
let locationField = ['LOCATION', 'INVENTORYLOCATION', 'INVENTORY LOCATION', 'INVENTORYREGION', 'INVENTORY REGION', 'REGION'];
let cityField = ['CITY'];
let stateField = ['STATE', 'STATE/REGION', 'STATE / REGION'];
let countryField = ['COUNTRY'];
let originField = ['ORIGIN'];
let offrapaportField = ['OFFRAPAPORT', 'OFF RAPAPORT', 'OFF%', 'OFF %', 'OFF', 'DISCOUNT', 'DISC %', '% OFF RAP'];
let enhancementsField = ['ENHANCEMENTS', 'ENHANCEMENT TYPES', 'ENHANCEMENTTYPES'];
let laserinscriptionField = ['LASERINSCRIPTION', ' LASER INSCRIPTION', ' LASERINCRIPTION', ' LASER INCRIPTION', ' INCRIPTION#', ' INSCRIPTION'];
let shadesField = ['SHADES'];
let treatmentField = ['TREATMENT'];
let keytosymbolField = ['KEYTOSYMBOL', 'KEY TO SYMBOLS'];
let blackinclusionField = ['BLACKINCLUSION', 'BLACK INCLUSION', 'BLACK'];
let centralinclusionField = ['CENTRALINCLUSION', 'CENTRAL INCLUSION', 'CENTRAL'];
let milkyinclusionField = ['MILKYINCLUSION', 'MILKY INCLUSION', 'MILKY'];
let eyecleaninclusionField = ['EYECLEANINCLUSION', 'EYE CLEAN INCLUSION', 'EYE CLEAN'];
let commentsField = ['COMMENTS', 'REMARKS', 'COMMENT', 'REMARK'];
let isactiveField = ['ISACTIVE', 'ACTIVE', 'IS ACTIVE'];
let price1Field = ['PRICE1', 'LISTPRICE'];
let price2Field = ['PRICE2', 'SELLINGPRICE', 'MARKETSALEPRICE'];
let ratioField = ['RATIO'];
let thirdpartysellernameField = ['THIRDPARTYSELLERNAME'];
let customfield1nameField = ['CUSTOMFIELD1NAME'];
let customfield1Field = ['CUSTOMFIELD1'];
let customfield2nameField = ['CUSTOMFIELD2NAME'];
let customfield2Field = ['CUSTOMFIELD2'];
let customfield3nameField = ['CUSTOMFIELD3NAME'];
let customfield3Field = ['CUSTOMFIELD3'];
let customfield4nameField = ['CUSTOMFIELD4NAME'];
let customfield4Field = ['CUSTOMFIELD4'];
let customfield5nameField = ['CUSTOMFIELD5NAME'];
let customfield5Field = ['CUSTOMFIELD5'];
let dealercostField = ['DEALERCOST'];


