﻿var express = require('express');
var app = express();
var router = express.Router();
var bodyParser = require('body-parser');
var filessystem = require('fs');
const nodemailer = require("nodemailer");
app.use(bodyParser.urlencoded({ extended: 'false' }));
app.use(bodyParser.json());

var cassandra = require('cassandra-driver');
const util = require('util');
//var client = new cassandra.Client({contactPoints: [process.env.CASSANDRA_IP || 'cassandra']});
var contactPoints = ['127.0.0.1'];
var client = new cassandra.Client({ contactPoints: contactPoints, localDataCenter: 'datacenter1' });
client.connect(function(err, result){
	console.log('user detail: cassandra connected');
});


/*
 * GET users listing.
 */
exports.list = function (req, res) {
    console.log(req.body);
	//console.log('users: list');
    client.execute('SELECT * FROM key_gemfind.user_Registration', [], function (err, result) {        
		if(err){
			console.log('users: list err:', err);
			res.status(404).send({msg: err});
		} else {
            //console.log('users: list succ:', result.rows);                        
            //res.render('users', { page_title: "users - Node.js", data: result.rows })
            res.send({ status: 200, data: result.rows });
		}
	});
};

//exports.add = function(req, res){
//  res.render('add_customer',{page_title:"Add users - Node.js"});
//};

exports.edit = function (req, res) {
    console.log(req);
    var id = req.params.email;


    console.log('customers: edit');

    client.execute("SELECT * from key_gemfind.user_Registration WHERE email='" + id + "'  ALLOW FILTERING", [], function (err, result) {
        if (err) {
            console.log('customers: edit err:', err);
            res.status(404).send({ msg: err });
        } else {
            console.log('customers: edit succ:');
            res.send({ status: 200, data: result.rows });
        }
    });

};

exports.save = function (req, res) {
    const Uuid = require('cassandra-driver').types.Uuid;
    const id = Uuid.random();
    const id2 = Uuid.random();

    console.log(id, id2);
    console.log(req.body);

    var input = req.body;
    //client.execute("INSERT INTO key_gemfind.user_registration (pk_id, accesstoken, account_type, address,city,company_name,contact_no,country,created_date,currency,email,image_name,is_deleted,is_emailverify,is_enable,language,firstname,lastname,password,refreshtoken,roles,state,updated_date,user_name,zip_code,name) VALUES (" + id + ", '" + input.accesstoken + "', '" + input.account_type + "', '" + input.address + "','" + input.city + "', '" + input.company_name + "', '" + input.contact_no + "','" + input.country + "', '" + input.created_date + "', '" + input.currency + "','" + input.email + "',null, false, true,true, '" + input.language + "', '" + input.firstname + "','" + input.lastname + "','" + input.password + "', '" + input.refreshtoken + "', '" + input.roles + "','" + input.state + "', '" + input.updated_date + "','" + input.user_name + "','" + input.zip_code + "','" + input.firstname + "')", [], function (err, result) {
    //    console.log("1");
    //    if (err) {
    //        console.log("2");
    //        console.log('users: add err:', err);
    //        res.status(404).send({ msg: err });
    //    } else {
    //        var dealerId;
    //        client.execute("SELECT MAX(dealer_id) AS LargestDealerid from key_gemfind.company_detail", [], function (err, result) {
    //            if (err) {
    //                err;
    //            } else {
    //                result = result.rows[0].largestdealerid + 1;
    //                if (result === 1) {
    //                    dealerId = 1000;
    //                } else {
    //                    dealerId = result;
    //                }
    //                if (dealerId >= 1000) {

    //                    console.log("inserted id", id);
    //                    console.log(result);
    //                    client.execute("INSERT INTO key_gemfind.company_detail (pk_id,account_type,address,city,company_name,contact_no,country,created_date,currency,email,is_deleted,is_enable,language,name,state,updated_date,zip_code,created_by,dealer_id) VALUES (" + id2 + ", '" + input.account_type + "', '" + input.address + "', '" + input.city + "', '" + input.company_name + "', '" + input.contact_no + "', '" + input.country + "','" + input.created_date + "','" + input.currency + "','" + input.email + "', false, false, '" + input.language + "', '" + input.name + "', '" + input.state + "','" + input.updated_date + "','" + input.zip_code + "'," + id + "," + dealerId + ") ", [], function (err, result) {
    //                        console.log("1");
    //                        if (err) {
    //                            console.log("2");
    //                            console.log('users: add err:', err);
    //                            res.status(404).send({ msg: err });
    //                        } else {
    //                            console.log("3");
    //                            var dir = './uploads/' + dealerId;
    //                            if (!filessystem.existsSync(dir)) {
    //                                filessystem.mkdirSync(dir);
    //                            } else {
    //                                console.log("Directory already exist");
    //                            }
    //                            client.execute("INSERT INTO key_gemfind.companyuser_mapping (pk_id,company_id,user_id) VALUES (now(), " + id2 + ", " + id + ") ", [], function (err, result) {
    //                                console.log("1");
    //                                if (err) {
    //                                    console.log("2");
    //                                    console.log('users: add err:', err);
    //                                    res.status(404).send({ msg: err });
    //                                } else {
    //                                    console.log("3");

    //                                    console.log(result);
    //                                    res.send({ status: 200, data: result.rows });
    //                                }
    //                            });
    //                        }
    //                    });

    //                }
    //            };
    //        });
    //    }
    //});

};



exports.country = function (req, res) {
    console.log(req.body);   
    client.execute('SELECT * FROM key_gemfind.country', [], function (err, result) {
        if (err) {
            console.log('users: list err:', err);
            res.status(404).send({ msg: err });
        } else {
            res.send({ status: 200, data: result.rows });
        }
    });
};

//exports.save = function (req, res) {
//    console.log(req);
//    var input = req.body;
//    console.log(util.inspect(input, { showHidden: false, depth: null }));
//    console.log("my query:" + input.address);

//    client.execute("INSERT INTO key_gemfind.user_Registration (pk_id, accesstoken, account_type, address,city,company_name,contact_no,country,created_date,currency,email,image_name,is_deleted,is_emailverify,is_enable,language,name,password,refreshtoken,roles,state,updated_date,user_name,zip_code) VALUES (now(), '" + input.accesstoken + "', '" + input.account_type + "', '" + input.address + "','" + input.city + "', '" + input.company_name + "', '" + input.contact_no + "','" + input.country + "', '" + input.created_date + "', '" + input.currency + "','" + input.email + "','" + input.image_name + "', false, true,true, '" + input.language + "', '" + input.name + "','" + input.password + "', '" + input.refreshtoken + "', '" + input.roles + "','" + input.state + "', '" + input.updated_date + "','" + input.user_name + "','" + input.zip_code + "')", [], function (err, result) {
//        if (err) {
//            console.log('users: add err:', err);
//            res.status(404).send({ msg: err });
//        } else {
//            console.log('users: add succ:');
//            res.send({ status: 200, data: result.rows })
//        }
//    });
//};

/*Save the customer*/
//exports.save = function (req, res) {
//    console.log(req);
//    var input = req.body;
//    console.log(util.inspect(input, { showHidden: false, depth: null }))
//    console.log("my query:" + input.address);
//    client.execute("INSERT INTO key_gemfind.user_Registration (pk_id, accesstoken, account_type, address,city,company_name,contact_no,country,created_date,currency,email,is_deleted,is_emailverify,is_enable,language,name,password,refreshtoken,roles,state,updated_date,user_name,zip_code) VALUES (now(), '" + input.accesstoken + "', '" + input.account_type + "', '" + input.address + "','" + input.city + "', '" + input.company_name + "', '" + input.contact_no + "','"+input.country+"', '" + input.created_date + "', '" + input.currency + "','" + input.email + "', false, true,true, '" + input.language + "', '" + input.name + "','" + input.password + "', '" + input.refreshtoken + "', '" + input.roles + "','" + input.state + "', '" + input.updated_date + "','" + input.user_name + "','" + input.zip_code + "')", [], function (err, result) {
//		if(err){
//			console.log('users: add err:', err);
//			res.status(404).send({msg: err});
//		} else {
//            console.log('users: add succ:');
//            res.send({ status: 200, data: result.rows })
//		}
//	});
//};

exports.save_edit = function(req,res){
    console.log(req.body);    // var input = JSON.parse(JSON.stringify(req.body));
    // var id = req.params.id;
	var input = (req.body);
    var id = req.body.pk_id;

    

   
    client.execute("UPDATE key_gemfind.user_registration set account_type='" + input.account_type + "', address='" + input.address + "',city='" + input.city + "',company_name='" + input.company_name + "',contact_no='" + input.contact_no + "',country='" + input.country + "',currency='" + input.currency + "',language='" + input.language + "',firstname='" + input.firstname + "',lastname='" + input.lastname + "',roles='" + input.roles + "',state='" + input.state + "',updated_date='" + input.updated_date + "',user_name='" + input.user_name + "',zip_code='" + input.zip_code + "' WHERE pk_id = " + id, [], function (err, result) {
		if(err){
			console.log('users: save_edit err:', err);
			res.status(404).send({msg: err});
		} else {
			console.log('users: save_edit succ:');
            res.send({ status: 200, data: result.rows });
		}
	});
};
exports.update_password = function (req, res) {
    var input = (req.body);
    var id = req.body.pk_id;
    console.log('customers: update password');
    client.execute("UPDATE key_gemfind.user_registration set password='" + input.password + "' WHERE pk_id in ( " + id + ")", [], function (err, result) {
        if (err) {
            console.log('customers: save_edit err:', err);
            res.status(404).send({ msg: err });
        } else {
            console.log('customers: save_edit succ:');
            res.send({ status: 200, data: result.rows })
            //res.redirect('/customers');
        }
    });
};

exports.delete_customer = function(req,res){

    var id = req.params.id;

	console.log('users: delete');

	client.execute("DELETE FROM key_gemfind.user_Registration WHERE id = " + id,[], function(err, result){
		if(err){
			console.log('users: delete err:', err);
			res.status(404).send({msg: err});
		} else {
			console.log('users: delete succ:');
			//res.redirect('/users');
		}
	});

};


//email template api

//exports.saveemail = function (req, res) {
//exports.saveemail = function (req, res) {
//    console.log("insert sussceesss");
//    console.log(req.body);
    
//    //console.log(util.inspect(input, { showHidden: false, depth: null }))
//    //console.log("my query:" + input.address);


//    //client.execute("INSERT INTO key_gemfind.email_template (pk_id, email_body,email_subject,email_type) VALUES (now(), '" + input.email_body + "','" + input.email_subject + "','" + input.email_type + "')", [], function (err, result) {

//    //    if (err) {
//    //        console.log('users: add err:', err);
//    //        res.status(404).send({ msg: err });
//    //    } else {
//    //        console.log('users: add succ:');
          
//    //        res.send({ status: 200, data: result.rows })
//    //    }
//    //});
//};
////---------------------------------------------------------------------------------------- get All company List

exports.userbyemail = function (req, res) {
    var str = req.originalUrl;
    var str2 = str.split("?");
    var id = str2[1];
    console.log(id);

    client.execute("select * from key_gemfind.user_registration WHERE email = '" + id +"' ALLOW FILTERING", [], function (err, result) {
        if (err) {
            console.log('users: add err:', err);
            res.status(404).send({ msg: err });
        } else {
            console.log('users: add succ:');
            res.send({ status: 200, data: result.rows[0] });
        }
    });
};
//--------------------get company on load
exports.getcompanysonly = function (req, res) {
    let FinalArray = [];
    var xyz = false;
    var counter = 0;
    var str = req.originalUrl;
    var str2 = str.split("?");
    var id = str2[1];
    console.log(id);
    client.execute("select * FROM key_gemfind.user_registration WHERE pk_id =" + id, [], function (err, result, fields) {
        if (err) {
            console.log('users: add err:', err);
            res.status(404).send({ msg: err });
        } else {
            var role = result.rows[0].roles;
            if (role === '2') {
                client.execute("select * from key_gemfind.company_detail", [], function (err, result) {
                    if (err) {
                        console.log('users: add err:', err);
                        res.status(404).send({ msg: err });
                    } else {
                        console.log('Admin:Get all');
                        res.send({ status: 200, data: result.rows });
                    }
                });
            }
            else {
                client.execute("select * from key_gemfind.company_detail WHERE is_enable = false AND created_by = " + id + " ALLOW FILTERING", [], function (err, result) {
                    if (err) {
                        console.log('users: add err:', err);
                        res.status(404).send({ msg: err });
                    } else {
                        console.log("Data by pkid");
                        console.log('users: Get all');
                        console.log(result.rows);
                        res.send({ status: 200, data: result.rows });
                    }
                });
            }
        }
    });
};
//-----------------------------------------get company on tab
exports.getcompanyall = function (req, res) {
    let FinalArray = [];
    var xyz = false;
    var counter = 0;
    var str = req.originalUrl;
    var str2 = str.split("?");
    var id = str2[1];
    console.log(id);
    client.execute("select * FROM key_gemfind.user_registration WHERE pk_id =" + id , [], function (err, result, fields) {
        if (err) {
            console.log('users: add err:', err);
            res.status(404).send({ msg: err });
        } else {
            var role = result.rows[0].roles;
            if (role === '2') {
                client.execute("select * from key_gemfind.company_detail", [], function (err, result) {
                    if (err) {
                        console.log('users: add err:', err);
                        res.status(404).send({ msg: err });
                    } else {
                        console.log('Admin:Get all');
                        for (let i = 0; i < result.rows.length; i++) {
                            
                            //client.execute("select * from key_gemfind.user_registration", [], function (err, result1) {
                             client.execute("select * from key_gemfind.user_registration", [], function (err, result1) {
                                if (err) {
                                    console.log('users: add err:', err);
                                    res.status(404).send({ msg: err });
                                } else {
                                    var data1 = result.rows[i];
                                    data1.description = result1.rows;
                                    FinalArray.push(data1);
                                    if (counter === result.rows.length - 1) {
                                        res.send({ status: 200, data: FinalArray });
                                    }
                                    counter++;
                                }
                            });
                        }
                    }
                });
            }
            else {
                client.execute("select * from key_gemfind.company_detail WHERE is_enable = false AND created_by = " + id  +" ALLOW FILTERING", [], function (err, result) {
                    if (err) {
                        console.log('users: add err:', err);
                        res.status(404).send({ msg: err });
                    } else {
                        console.log("Data by pkid");
                        console.log('users: Get all');
                        console.log(result.rows);
                        res.send({ status: 200, data: result.rows });
                    }
                });
            }

        }
    });  
};
////---------------------------------------------------------------------------------------- Update user Password by ID

exports.updateuserpassword = function (req, res) {
    console.log(req.body);
    var input = (req.body);
    var id = req.body.pk_id;
    client.execute("UPDATE key_gemfind.user_registration set password='" + input.password + "' WHERE pk_id = " + id, [], function (err, result) {
        if (err) {
            console.log('users: add err:', err);
            res.status(404).send({ msg: err });
        } else {
            console.log(result);
            var transporter = nodemailer.createTransport({
                service: 'gmail',
                auth: {
                    user: 'gemfindtest@gmail.com',
                    pass: 'Test@123'
                }
            });
            console.log('created');
            client.execute("select * FROM key_gemfind.user_registration WHERE pk_id = " + id, [], function (err, result, fields) {
                if (err) {
                    console.log('users: add err:', err);
                    res.status(404).send({ msg: err });
                } else {
                    var data = result.rows[0].firstname;

                    console.log(data);
                    client.execute("select * FROM key_gemfind.email_template WHERE pk_id =" + 'b4bd07f0-81e2-11e9-a502-13da67316383', [], function (err, result, fields) {
                        if (err) {
                            console.log('users: add err:', err);
                            res.status(404).send({ msg: err });
                        } else {
                            var data2 = result.rows[0].email_body;
                            var finalMail = data2.replace(/%name%/g, data);
                            //var data2 = result.rows[0].email_body;
                            //var s = data2.split("#");
                            //var data3 = data2.replace(s[1], data);
                            //var data4 = data3.replace('#', "");
                            //var data5 = data4.replace('#', "");
                            var mailOptions = {
                                from: 'gemfindtest@gmail.com', // sender address
                                cc: 'hardeep.yadav@rigelnetworks.com', // list of receivers
                                to: input.email, // list of receivers
                                subject: "Password Change", // Subject line
                                html: finalMail,
                            };
                            transporter.sendMail(mailOptions, function (error, info) {
                                if (error) {
                                    console.log("1");
                                    console.log(error);
                                } else {
                                    console.log('Email sent: ' + info.response);
                                }
                            });
                            res.send({ status: 200, data: result.rows });
                        }
                    });
                }
            });
        }
    });
};
////---------------------------------------------------------------------------------------- get All Users List
exports.getusersall= function (req, res) {
    console.log("user");
    client.execute("select * from key_gemfind.user_registration", [], function (err, result) {
        if (err) {
            console.log('users: add err:', err);
            res.status(404).send({ msg: err });
        } else {
            console.log('users: add succ:');
            res.send({ status: 200, data: result.rows });
        }
    });
};
////---------------------------------------------------------------------------------------- Update User disable by ID
exports.userdisable = function (req, res) {
    console.log(req.params);
    console.log(req.originalUrl);
    var str = req.originalUrl;
    var str2 = str.split("?");
    var str3 = str2[1];
    console.log(str3);
    client.execute("update  key_gemfind.user_registration set is_enable = true  WHERE pk_id=" + str3, [], function (err, result) {
        if (err) {
            console.log('users: add err:', err);
            res.status(404).send({ msg: err });
        } else {
            console.log('users: add succ:');
            res.send({ status: 200, data: result.rows });
        }
    });
};
////---------------------------------------------------------------------------------------- Update User enable by ID
exports.userenable = function (req, res) {
    console.log(req.params);
    console.log(req.originalUrl);
    var str = req.originalUrl;
    var str2 = str.split("?");
    var str3 = str2[1];
    console.log(str3);
    client.execute("update key_gemfind.user_registration set is_enable = false  WHERE pk_id=" + str3, [], function (err, result) {
        if (err) {
            console.log('users: add err:', err);
            res.status(404).send({ msg: err });
        } else {
            console.log('users: add succ:');
            res.send({ status: 200, data: result.rows });
        }
    });
};
////---------------------------------------------------------------------------------------- Get company by ID
exports.companyedit= function (req, res) {
    console.log(req.params);
    console.log(req.originalUrl);
    var str = req.originalUrl;
    var str2 = str.split("?");
    var str3 = str2[1];
    console.log(str3);
    client.execute("SELECT * from key_gemfind.company_detail WHERE pk_id=" + str3, [], function (err, result) {
        if (err) {
            console.log('users: add err:', err);
            res.status(404).send({ msg: err });
        } else {
            console.log('users: add succ:');
            res.send({ status: 200, data: result.rows });
        }
    });
};
////---------------------------------------------------------------------------------------- Update companydetails by ID
exports.companyDetailupdate = function (req, res) {
    console.log(req.body);
    var input = (req.body);
    var id = req.body.pk_id;
    client.execute("UPDATE key_gemfind.company_detail set account_type='" + input.account_type + "', address='" + input.address + "',city='" + input.city + "',company_name='" + input.company_name + "',contact_no='" + input.contact_no + "',country='" + input.country + "',created_date='" + input.created_date + "',currency='" + input.currency + "',email='" + input.email + "',is_deleted= false ,is_enable=" + input.is_enable + ",language='" + input.language + "',name='" + input.name + "',state='" + input.state + "',updated_date='" + input.updated_date + "',zip_code='" + input.zip_code + "',created_by=" + input.created_by + " WHERE pk_id = " + id, [], function (err, result) {
        if (err) {
            console.log('users: add err:', err);
            res.status(404).send({ msg: err });
        } else {
            console.log('users: add succ:');
            res.send({ status: 200, data: result.rows });
        }
    });
};
////---------------------------------------------------------------------------------------- Add New Company

exports.addnewcompany = function (req, res) {
    console.log(req.body);
    console.log("4");
    var input = req.body; 

    client.execute("SELECT * from key_gemfind.company_detail WHERE company_name = '" + input.company_name + "' ALLOW FILTERING", [], function (err, result) {
        if (err) {
            console.log('users: add err:', err);
            res.status(404).send({ msg: err });
        } else {
            if (result.rowLength === 0) {
                console.log('users: add succ:');
                client.execute("INSERT INTO key_gemfind.company_detail (pk_id,account_type,address,city,company_name,contact_no,country,created_date,currency,email,is_deleted,is_enable,language,name,state,updated_date,zip_code,created_by,invite) VALUES (now(), '" + input.account_type + "', '" + input.address + "', '" + input.city + "', '" + input.company_name + "', '" + input.contact_no + "', '" + input.country + "','" + input.created_date + "','" + input.currency + "','" + input.email + "', false, false, '" + input.language + "', '" + input.name + "', '" + input.state + "','" + input.updated_date + "','" + input.zip_code + "'," + input.created_by + ",false) ", [], function (err, result) {
                    console.log("1");
                    if (err) {
                        console.log('users: add err:', err);
                        res.status(404).send({ msg: err });
                    } else {
                        console.log('users: add succ:');
                        console.log(result);

                    }
                });
                res.send({ status: 200, data: result.rows });
            }
            else {
               res.send({ status: 202, data: 'Company Already Exists' });
            }      
        }
    });


    //client.execute("INSERT INTO key_gemfind.company_detail (pk_id,account_type,address,city,company_name,contact_no,country,created_date,currency,email,is_deleted,is_enable,language,name,state,updated_date,zip_code,created_by) VALUES (now(), '" + input.account_type + "', '" + input.address + "', '" + input.city + "', '" + input.company_name + "', '" + input.contact_no + "', '" + input.country + "','" + input.created_date + "','" + input.currency + "','" + input.email + "', false, false, '" + input.language + "', '" + input.name + "', '" + input.state + "','" + input.updated_date + "','" + input.zip_code + "'," + input.created_by + ") ", [], function (err, result) {
    //    console.log("1");
    //    if (err) {
    //        console.log('users: add err:', err);
    //        res.status(404).send({ msg: err });
    //    } else {
    //        console.log('users: add succ:');
    //        console.log(result);

    //    }
    //});
};
////---------------------------------------------------------------------------------------- Update Company disable by ID
exports.compaydisable = function (req, res) {
    console.log(req.params);
    console.log(req.originalUrl);
    var str = req.originalUrl;
    var str2 = str.split("?");
    var str3 = str2[1];
    console.log(str3);
    client.execute("update  key_gemfind.company_detail set is_enable = true  WHERE pk_id=" + str3, [], function (err, result) {
        if (err) {
            console.log('users: add err:', err);
            res.status(404).send({ msg: err });
        } else {
            console.log('users: add succ:');
            res.send({ status: 200, data: result.rows });
        }
    });
};
////---------------------------------------------------------------------------------------- Update company enable by ID
exports.compayenable= function (req, res) {
    console.log(req.params);
    console.log(req.originalUrl);
    var str = req.originalUrl;
    var str2 = str.split("?");
    var str3 = str2[1];
    console.log(str3);
    client.execute("update key_gemfind.company_detail set is_enable = false  WHERE pk_id=" + str3, [], function (err, result) {
        if (err) {
            console.log('users: add err:', err);
            res.status(404).send({ msg: err });
        } else {
            console.log('users: add succ:');
            res.send({ status: 200, data: result.rows });
        }
    });
};
////---------------------------------------------------------------------------------------- Insert FTPupload

exports.ftpUpload = function (req, res) {
    var input = req.body;
    const folderName = "E:\gemfind\New folder\'" + input.username + "'";
    client.execute("insert into key_gemfind.FTP_Upload (pk_id,dealerID,FTP_Path,username,password,fileType) values (now(),now(),'" + input.FTP_Path + "','" + input.username + "','" + input.pass + "','" + input.fileType + "')", function (err, result) {
        if (err) {
            console.log('users: add err:', err);
            res.status(404).send({ msg: err });
        } else {
            console.log('users: add succ:');
            res.send({ status: 200, data: result.rows });
        }
    });
};
////---------------------------------------------------------------------------------------- get ftp data by username
exports.getuploadeddatabyid = function (req, res) {
    console.log(req.params);
    console.log(req.originalUrl);
    var str = req.originalUrl;
    var str2 = str.split("?");
    var str3 = str2[1];
    console.log(str3);
    client.execute("SELECT * from key_gemfind.FTP_Upload WHERE username = '" + str3 + "' ALLOW FILTERING", [], function (err, result) {
        if (err) {
            console.log('users: add err:', err);
            res.status(404).send({ msg: err });
        } else {
            console.log('users: add succ:');
            res.send({ status: 200, data: result.rows });
        }
    });
};

exports.companyDetailByEmail = function (req, res) {
    var str = req.originalUrl;
    var str2 = str.split("?");
    var id = str2[1];
    console.log(id);

    client.execute("select * from key_gemfind.company_detail WHERE email = '" + id + "' ALLOW FILTERING", [], function (err, result) {
        if (err) { 
            res.status(404).send({ msg: err });
        } else { 
            res.send({ status: 200, data: result.rows[0] });
        }
    });
};

exports.socialRegister = function (req, res) {
    var input = req.body;
    try {

        client.execute("select * from key_gemfind.user_Registration where email = '" + input.email + "' ALLOW FILTERING", [], function (err, result) {
            if (err) {
                res.status(404).send({ msg: err });
            } else {
                if (result.rowLength > 0) {
                    res.send({ status: 200, data: result.rows[0] });
                }
                else {
                    client.execute("INSERT INTO key_gemfind.user_Registration (pk_id, accesstoken, account_type, address,city,company_name,contact_no,country,created_date,currency,email,is_deleted,is_emailverify,is_enable,language,name,password,refreshtoken,roles,state,updated_date,user_name,zip_code,firstname,lastname) VALUES (now(), '" + input.accesstoken + "', '" + input.account_type + "', '" + input.address + "','" + input.city + "', '" + input.company_name + "', '" + input.contact_no + "','" + input.country + "', '" + input.created_date + "', '" + input.currency + "','" + input.email + "', false, true,true, '" + input.language + "', '" + input.name + "','" + input.password + "', '" + input.refreshtoken + "', '" + input.roles + "','" + input.state + "', '" + input.updated_date + "','" + input.user_name + "','" + input.zip_code + "','" + input.firstname + "','" + input.lastname + "')", [], function (err, result) {
                        if (err) {
                            res.status(404).send({ msg: err });
                        } else {
                            client.execute("select * from key_gemfind.user_Registration where email = '" + input.email + "' ALLOW FILTERING", [], function (err, result) {
                                if (err) {
                                    res.status(404).send({ msg: err });
                                } else {
                                    if (result.rowLength > 0) {
                                        res.send({ status: 200, data: result.rows[0] });
                                    }
                                }
                            });
                        }
                    });
                }
                
            }
        });


        
    } catch (e) {
        Console.log(e);
    }
   
};

